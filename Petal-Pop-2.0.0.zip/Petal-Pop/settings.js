(() => {
  'use strict';

  const key = 'petal_pop_studio_settings';
  const defaults = {
    enabled: true,
    cursor: {
      enabled: true, shape: 'paw-cat', size: 36, primary: '#f5a9c6',
      secondary: '#fff2ef', outline: '#482e50', stroke: 2,
      motion: 'direct', strength: 35, tilt: 0, opacity: 100
    },
    effect: {
      enabled: true, style: 'paw-trails', primary: '#ed8db2', secondary: '#a78bfa',
      size: 100, count: 8, spread: 95, duration: 850, direction: 'radial', opacity: 100
    }
  };
  const motions = [
    { id: 'direct', label: 'Direct' },
    { id: 'glide', label: 'Smooth glide' },
    { id: 'spring', label: 'Spring' },
    { id: 'float', label: 'Gentle float' },
    { id: 'trail', label: 'Afterimage trail' }
  ];
  const directions = [
    { id: 'radial', label: 'All directions' },
    { id: 'up', label: 'Up' },
    { id: 'down', label: 'Down' },
    { id: 'left', label: 'Left' },
    { id: 'right', label: 'Right' }
  ];

  const color = (value, fallback) => typeof value === 'string' && /^#[\da-f]{6}$/i.test(value) ? value : fallback;
  const number = (value, min, max, fallback) => {
    if (typeof value !== 'number' || !Number.isFinite(value)) return fallback;
    return Math.min(max, Math.max(min, Math.round(value)));
  };
  const choice = (value, options, fallback) => options?.some(option => option.id === value) ? value : fallback;

  function normalize(raw) {
    const cursor = raw?.cursor;
    const effect = raw?.effect;
    const c = defaults.cursor;
    const e = defaults.effect;
    return {
      enabled: raw?.enabled !== false,
      cursor: {
        enabled: cursor?.enabled !== false,
        shape: choice(cursor?.shape, globalThis.PetalArt?.shapes, c.shape),
        size: number(cursor?.size, 16, 96, c.size),
        primary: color(cursor?.primary, c.primary),
        secondary: color(cursor?.secondary, c.secondary),
        outline: color(cursor?.outline, c.outline),
        stroke: number(cursor?.stroke, 0, 6, c.stroke),
        motion: choice(cursor?.motion, motions, c.motion),
        strength: number(cursor?.strength, 0, 100, c.strength),
        tilt: number(cursor?.tilt, -45, 45, c.tilt),
        opacity: number(cursor?.opacity, 10, 100, c.opacity)
      },
      effect: {
        enabled: effect?.enabled !== false,
        style: choice(effect?.style, globalThis.PetalEffects?.styles, e.style),
        primary: color(effect?.primary, e.primary),
        secondary: color(effect?.secondary, e.secondary),
        size: number(effect?.size, 25, 250, e.size),
        count: number(effect?.count, 1, 32, e.count),
        spread: number(effect?.spread, 15, 260, e.spread),
        duration: number(effect?.duration, 200, 2400, e.duration),
        direction: choice(effect?.direction, directions, e.direction),
        opacity: number(effect?.opacity, 10, 100, e.opacity)
      }
    };
  }

  const oldPalettes = {
    aqua: '#92d4f5', rose: '#f5a9c6', lilac: '#ccb3f5', mint: '#a7e4cf',
    peach: '#ffbd9d', lemon: '#f6de8c', sky: '#c4e1fc', cherry: '#f5789f',
    orchid: '#cf91e3', moonlight: '#cbd7ec', cocoa: '#bd8e78', noir: '#26253b'
  };
  function read(callback) {
    chrome.storage.local.get({
      [key]: null, zenx_clicks_enabled: null, zenx_cursor_style: null, zenx_click_style: null
    }, values => {
      const error = chrome.runtime.lastError;
      if (error) { callback(normalize(), error.message); return; }
      if (values[key]) { callback(normalize(values[key])); return; }
      const previousColor = Object.hasOwn(oldPalettes, values.zenx_cursor_style) ?
        oldPalettes[values.zenx_cursor_style] : null;
      const oldEffect = values.zenx_click_style;
      const aliases = { sparkle: 'sparkles', butterflies: 'butterfly', daisies: 'petals' };
      callback(normalize({
        enabled: values.zenx_clicks_enabled !== false,
        cursor: previousColor ? { shape: 'arrow', primary: previousColor } :
          { enabled: values.zenx_cursor_style !== 'system' },
        effect: { style: Object.hasOwn(aliases, oldEffect) ? aliases[oldEffect] : oldEffect }
      }));
    });
  }

  globalThis.PetalSettings = { key, defaults, normalize, read, motions, directions };
})();
