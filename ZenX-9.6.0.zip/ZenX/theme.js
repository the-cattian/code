/* ZenX visual skin. No ticket or SLA calculations take place here. */
(() => {
  const {presets, normalize, palette, ink} = globalThis.ZenXThemes;
  let active = normalize(presets[0]);
  let enabled = true;
  let globalEnabled = true;
  // The classic darkener starts before storage/theme reapplication completes.
  // Keep the selected visual owner available even while the UI is disabled.
  globalThis.__zenxPremiumThemeSelected = active.id !== 'classic';
  const styledDocuments = new Set();

  function documents() {
    const results=[], seen=new Set();
    function descend(doc) {
      if(!doc || seen.has(doc) || !doc.documentElement) return;
      seen.add(doc); results.push(doc);
      try { doc.querySelectorAll('iframe').forEach(f=>{try {if(f.contentDocument) descend(f.contentDocument);}catch(_) {}}); } catch(_) {}
    }
    descend(document);return results;
  }
  function asWallpaper(value) { return !value?'':value.startsWith('data:image/')?value:chrome.runtime.getURL(value); }
  function setPalette(root, theme) {
    for (const mode of ['dark', 'light']) {
      for (const [role, background] of Object.entries(palette(theme, mode))) {
        root.style.setProperty('--zenx-' + role + '-' + mode, background);
        root.style.setProperty('--zenx-' + role + '-text-' + mode, ink(background));
      }
    }
  }
  function tagVirtualAssistant(doc) {
    try {
      doc.querySelectorAll('article[data-test-id="omni-log-comment-item"]').forEach(article=>{
        const sender=article.querySelector('[data-test-id="omni-log-item-sender"]');
        const msg=article.querySelector('[data-test-id="omni-log-item-message"]');
        const name=(sender?.textContent||'').trim();
        const isVA=/\b(?:virtual assistant|support bot|chatbot|ai assistant)\b/i.test(name) || msg?.getAttribute('type')==='bot';
        if(isVA)article.setAttribute('data-zenx-va','1');
        else article.removeAttribute('data-zenx-va');
      });
    } catch(_) {}
  }
  function apply(doc){
    if(doc!==document && !doc.getElementById('zenx-visual-frame-css')){
      const link=doc.createElement('link');link.id='zenx-visual-frame-css';link.rel='stylesheet';link.href=chrome.runtime.getURL('styles.css');(doc.head||doc.documentElement).appendChild(link);
    }
    const root=doc.documentElement,a=active;
    if(doc===document) globalThis.__zenxPremiumThemeSelected = a.id !== 'classic';
    root.dataset.zenxTheme=a.id;
    setPalette(root,a);
    root.style.setProperty('--zenx-bubble-radius',a.bubbleRadius+'px');
    root.style.setProperty('--zenx-scale',String(a.uiScale/100));
    root.style.setProperty('--zenx-pill-radius',a.pillShape==='square'?'6px':a.pillShape==='soft'?'14px':'999px');
    root.style.setProperty('--zenx-popup-radius',a.popupRadius+'px');
    root.style.setProperty('--zenx-wallpaper-dim',String(Math.max(0,Math.min(1,a.dim/100))));
    // Light wallpaper has a translucent white veil rather than the dark black veil.
    root.style.setProperty('--zenx-light-veil',String(Math.min(.30,Math.max(.05,a.dim/100*.20))));
    const wallpaper=asWallpaper(a.wallpaper),clean=wallpaper?wallpaper.replace(/["\\\n\r]/g,''):'';
    root.style.setProperty('--zenx-wallpaper',clean?`url("${clean}")`:'none');
    root.style.setProperty('--zenx-theme-accent',a.accent);
    // Generate both variants so switching mode immediately updates the cursor.
    for (const mode of ['dark', 'light']) {
      const light = mode === 'light';
      const accent = a.cursorColor === a.accent ? palette(a, mode).accent : a.cursorColor;
      const fill = light ? '#' + (accent.slice(1).match(/../g) || []).map(pair =>
        Math.round(parseInt(pair, 16) * .48 + 255 * .52).toString(16).padStart(2, '0')).join('') : accent;
      const stroke = light ? '#405663' : '#111318';
      const cursor = `<svg xmlns="http://www.w3.org/2000/svg" width="28" height="32" viewBox="0 0 28 32"><path d="M3 2 V27 L9.5 20 L14.5 30 L19 27.8 L13.9 18 H23 Z" fill="${fill}" stroke="${stroke}" stroke-width="2" stroke-linejoin="round"/><path d="M5.2 5.2 V21 L9.4 16.8 L18.1 16.4 Z" fill="#fff" opacity=".62"/></svg>`;
      const pointer = `<svg xmlns="http://www.w3.org/2000/svg" width="32" height="36" viewBox="0 0 32 36"><path d="M12 2 C9 2 9 5 9 8 V19 L5 15 C2 13 0 17 3 21 L11 33 H26 C29 27 30 23 29 18 C28 15 25 15 23 16 C22 13 19 12 17 14 V8 C17 4 15 2 12 2 Z" fill="${fill}" stroke="${stroke}" stroke-width="2" stroke-linejoin="round"/><path d="M12 8V23M17 15V23M22 18V23" fill="none" stroke="#fff" stroke-opacity=".38" stroke-width="1.2"/></svg>`;
      root.style.setProperty('--zenx-cursor-' + mode, `url("data:image/svg+xml,${encodeURIComponent(cursor)}") 3 2, auto`);
      root.style.setProperty('--zenx-cursor-pointer-' + mode, `url("data:image/svg+xml,${encodeURIComponent(pointer)}") 11 4, pointer`);
    }
    root.dataset.zenxEffect=a.effect;
    root.classList.toggle('zenx-wallpaper-on',enabled&&!!wallpaper);
    root.classList.toggle('zenx-wallpaper-motion',enabled&&!!wallpaper&&a.motion);
    root.classList.toggle('zenx-custom-skin',enabled&&a.id!=='classic');
    root.classList.toggle('zenx-premium',enabled&&a.id!=='classic');
    root.classList.toggle('zenx-cursor-enabled',enabled);
    tagVirtualAssistant(doc);
    styledDocuments.add(doc);
    if(doc===document){
      globalThis.__zenxSoundProfile={type:a.sound,mutedByTheme:false};
    }
  }
  function applyAll(){documents().forEach(apply);}
  function notifyOwner(){window.dispatchEvent(new Event('zenx-visual-owner-ready'));}
  function clearAll(){for(const doc of styledDocuments){try{doc.documentElement.classList.remove('zenx-wallpaper-on','zenx-wallpaper-motion','zenx-custom-skin','zenx-premium','zenx-cursor-enabled');}catch(_){}}}
  function use(a){active=normalize(a);globalThis.__zenxPremiumThemeSelected = active.id !== 'classic';applyAll();}
  // Initialize the first-run preset while retaining the previous selection for older installs.
  chrome.storage.local.get({zenx_active_theme:presets[0],zenx_enabled:true,zenx_v7_selected:false},values=>{
    globalEnabled=values.zenx_enabled!==false;
    enabled=globalEnabled && window.__zenxTabEnabled!==false;
    if(!values.zenx_v7_selected){
      active=normalize(presets[0]);
      globalThis.__zenxPremiumThemeSelected = true;
      chrome.storage.local.set({zenx_v7_selected:true,zenx_v6_previous_theme:values.zenx_active_theme,zenx_active_theme:presets[0]},()=>{applyAll();notifyOwner();});
    }else { active=normalize(values.zenx_active_theme);globalThis.__zenxPremiumThemeSelected = active.id !== 'classic';applyAll();notifyOwner(); }
  });
  chrome.storage.onChanged.addListener((changes,area)=>{
    if(area!=='local')return;
    if(changes.zenx_enabled){globalEnabled=changes.zenx_enabled.newValue!==false;enabled=globalEnabled && window.__zenxTabEnabled!==false;}
    if(changes.zenx_active_theme){active=normalize(changes.zenx_active_theme.newValue);globalThis.__zenxPremiumThemeSelected = active.id !== 'classic';}
    if(changes.zenx_enabled||changes.zenx_active_theme){if(!enabled)clearAll();applyAll();notifyOwner();}
  });
  window.addEventListener('zenx-tab-state-change',()=>{enabled=globalEnabled && window.__zenxTabEnabled!==false;if(!enabled)clearAll();applyAll();notifyOwner();});
  chrome.runtime.onMessage.addListener((request,_sender,sendResponse)=>{
    if(!request||request.type!=='SET_DESIGN_THEME')return false;
    active=normalize(request.theme);
    globalThis.__zenxPremiumThemeSelected = active.id !== 'classic';
    chrome.storage.local.set({zenx_active_theme:active},()=>{
      if(chrome.runtime.lastError){sendResponse({success:false,error:chrome.runtime.lastError.message});return;}
      applyAll();notifyOwner();sendResponse({success:true,theme:active});
    });return true;
  });
  // Zendesk replaces panels when switching tabs/apps; reapply to the new DOM.
  let applying=false;
  function schedule(){if(applying)return;applying=true;setTimeout(()=>{applying=false;applyAll();},180);}
  const observer=new MutationObserver(muts=>{if(muts.some(m=>m.type==='childList'&&m.addedNodes.length))schedule();});
  if(document.documentElement)observer.observe(document.documentElement,{childList:true,subtree:true});
  const scan=setInterval(applyAll,1800);
  window.addEventListener('pagehide',()=>{clearInterval(scan);observer.disconnect();},{once:true});
})();
