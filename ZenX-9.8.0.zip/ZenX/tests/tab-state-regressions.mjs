import {strict as assert} from 'node:assert';
import {readFileSync} from 'node:fs';
import vm from 'node:vm';
const src=readFileSync(new URL('../service-worker.js',import.meta.url),'utf8');
const map=new Map(),listeners={}, tabs={messages:[]};
const chrome={
  storage:{session:{
    async get(key){return {[key]:map.get(key)};},
    async set(obj){Object.entries(obj).forEach(([key,val])=>map.set(key,val));},
    async remove(key){map.delete(key);}
  }},
  runtime:{onMessage:{addListener(fn){listeners.message=fn;}}},
  tabs:{onRemoved:{addListener(fn){listeners.removed=fn;}},
    async sendMessage(id,message){tabs.messages.push({id,message});return {success:true};}}
};
vm.runInNewContext(src,{chrome,Number,Promise,String});
function call(message,sender={}){return new Promise(r=>{const returned=listeners.message(message,sender,r);assert.equal(returned,true);});}
assert.equal((await call({type:'ZENX_GET_TAB_STATE'},{tab:{id:41}})).enabled,true);
assert.equal((await call({type:'ZENX_GET_TAB_STATE'},{tab:{id:42}})).enabled,true);
assert.equal((await call({type:'ZENX_SET_TAB_STATE',tabId:41,enabled:false})).success,true);
assert.equal((await call({type:'ZENX_GET_TAB_STATE'},{tab:{id:41}})).enabled,false);
assert.equal((await call({type:'ZENX_GET_TAB_STATE'},{tab:{id:42}})).enabled,true);
assert.equal(map.get('zenx_tab_off_41'),true);
assert.equal(tabs.messages.length,1);
assert.equal(tabs.messages[0].id,41);
// Reload preserves session overrides; no global/local change is made.
assert.equal((await call({type:'ZENX_GET_TAB_STATE'},{tab:{id:41}})).enabled,false);
assert.equal((await call({type:'ZENX_SET_TAB_STATE',tabId:41,enabled:true})).success,true);
assert.equal((await call({type:'ZENX_GET_TAB_STATE'},{tab:{id:41}})).enabled,true);
assert.equal(map.size,0);
await call({type:'ZENX_SET_TAB_STATE',tabId:42,enabled:false});
listeners.removed(42);await new Promise(r=>setTimeout(r,0));
assert.equal(map.size,0);
console.log('PASS tab state per browser tab, reload persistence, re-enable, close cleanup (8 checks)');
