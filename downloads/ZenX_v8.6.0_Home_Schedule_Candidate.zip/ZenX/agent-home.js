/* ZenX v8.5 — Agent Home surface classification (purely visual).
 * No ticket rows, statistics, controls or navigation are moved or replaced.
 */
(() => {
  'use strict';
  if (window.__zenxAgentHomeLoaded) return;
  window.__zenxAgentHomeLoaded = true;
  const html=document.documentElement;
  const MARK='data-zenx-home-surface';
  const records=new Set();
  let enabled=true,queued=false,stopped=false;
  const homeURL=()=>/^\/agent\/(?:home(?:\/|$)|dashboard(?:\/|$))/.test(location.pathname);
  const active=()=>enabled && html.classList.contains('zskin-active') && html.classList.contains('zenx-premium') && homeURL();
  function viewable(el) {
    if (!el || !el.isConnected || el.closest('[hidden],[aria-hidden="true"],[inert]')) return false;
    const style=getComputedStyle(el);
    return style.display!=='none' && style.visibility!=='hidden' && el.getBoundingClientRect().width>0;
  }
  function mark(el,value){
    if (!el) return;
    if (el.getAttribute(MARK)!==value) el.setAttribute(MARK,value);
    records.add(el);
  }
  function cleanup(){
    for(const el of records) if(el.getAttribute(MARK)) el.removeAttribute(MARK);
    records.clear();
    html.classList.remove('zenx-agent-home');
  }
  function findMain(){
    return document.querySelector('[data-test-id="nah-container"], [data-test-id="agent-home"], [data-test-id="home-page-content"], [data-test-id="agent-home-content"], [data-test-id="home-page"], main[role="main"], main, [role="main"]');
  }
  function classify(){
    queued=false;
    if(stopped)return;
    if(!active()){if(records.size||html.classList.contains('zenx-agent-home'))cleanup();return;}
    const main=findMain();
    if(!main || !viewable(main)){if(records.size)cleanup();return;}
    html.classList.add('zenx-agent-home');
    const next=new Map([[main,'main']]);
    const candidates=[...main.querySelectorAll([
      'section','[data-test-id*="card" i]','[data-test-id*="widget" i]',
      '[data-test-id*="ticket-list" i]','[data-test-id*="recent" i]',
      '[data-test-id*="home-panel" i]','[data-test-id*="summary" i]',
      '[data-test-id*="dashboard-section" i]'
    ].join(','))];
    for(const el of candidates){
      if (!viewable(el) || el===main || el.closest('[role="dialog"],[role="menu"],nav,header,article[data-test-id="omni-log-comment-item"]'))continue;
      const r=el.getBoundingClientRect();
      if (r.width<165 || r.height<70 || r.height>1500) continue;
      const id=(el.getAttribute('data-test-id')||'').toLowerCase();
      const hasHeading=!!el.querySelector('h2,h3,[role="heading"]');
      const hasTable=!!el.querySelector('table,[role="grid"],[role="table"]');
      const explicit=/\b(?:card|widget|summary|home-panel|dashboard-section|ticket-list|recent)/.test(id);
      if(!explicit && !(el.tagName==='SECTION' && (hasHeading||hasTable)))continue;
      // Avoid surrounding each item in a ticket table with its own card.
      if(el.closest('tr,[role="row"],tbody,[role="gridcell"],[role="cell"]'))continue;
      const metric=/metric|stat|summary|kpi/.test(id)&&r.width<550&&r.height<350;
      next.set(el,metric?'metric':'card');
    }
    // Some Agent Home builds render anonymous divs with dynamic CSS class names.
    // Identify a compact titled section by its real heading and content,
    // without relying on English page copy or changing the section's structure.
    for (const heading of main.querySelectorAll('h2,h3,[role="heading"][aria-level="2"],[role="heading"][aria-level="3"]')) {
      if (!viewable(heading) || heading.closest('nav,header,[role="dialog"]')) continue;
      if ([...next.keys()].some(el => el !== main && el.contains(heading))) continue;
      for (let el = heading.parentElement, depth=0; el && el!==main && depth<5; el=el.parentElement,depth++) {
        if (!viewable(el) || el.matches('nav,header,article,table,[role="row"]')) continue;
        const r=el.getBoundingClientRect();
        if (r.width<240 || r.height<100 || r.height>1500) continue;
        if (el.querySelectorAll('h2,h3,[role="heading"]').length>2) continue;
        if (!el.querySelector('table,[role="grid"],[role="table"],ul,ol,[role="list"],[data-test-id*="ticket" i],button')) continue;
        next.set(el,'card');
        break;
      }
    }
    // A native table or grid can have no outer section; style the table only.
    for(const table of main.querySelectorAll('table,[role="table"],[role="grid"]')){
      if(!viewable(table)||table.closest('[role="dialog"]'))continue;
      if([...next.keys()].some(el=>el!==main && el.contains(table)))continue;
      const r=table.getBoundingClientRect();
      if(r.width>230&&r.height>65)next.set(table,'table');
    }
    for(const el of records){
      if(!next.has(el) && el.getAttribute(MARK))el.removeAttribute(MARK);
    }
    records.clear();
    for(const [el,name] of next)mark(el,name);
  }
  function schedule(){if(!queued&&!stopped){queued=true;setTimeout(classify,180);}}
  const observer=new MutationObserver(mutations=>{
    if(mutations.some(m=>{
      if(m.type==='childList')return [...m.addedNodes,...m.removedNodes].some(el=>el.nodeType===1&&!el.matches?.('#zenx-presence-chip,#zenx-cursor-aura,.zenx-click-particle,.zenx-click-ring'));
      return m.target===html&&m.attributeName==='class';
    }))schedule();
  });
  observer.observe(html,{childList:true,subtree:true,attributes:true,attributeFilter:['class']});
  chrome.storage.local.get({zenx_enabled:true},v=>{enabled=v.zenx_enabled!==false;schedule();});
  chrome.storage.onChanged.addListener((changes,area)=>{if(area==='local'&&changes.zenx_enabled){enabled=changes.zenx_enabled.newValue!==false;schedule();}});
  window.addEventListener('popstate',schedule);
  window.addEventListener('hashchange',schedule);
  window.addEventListener('resize',schedule,{passive:true});
  const interval=setInterval(schedule,2600); // SPA navigation via pushState
  window.addEventListener('pagehide',()=>{stopped=true;clearInterval(interval);observer.disconnect();cleanup();},{once:true});
  schedule();
})();
