"""Offline regression for agent-only pill, manual tab timer, and macro composer."""
from playwright.sync_api import sync_playwright
from pathlib import Path
import re
ROOT=Path(__file__).resolve().parent.parent
with sync_playwright() as p:
  browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
  page=browser.new_page(viewport={'width':1600,'height':900})
  errors=[]
  page.on('pageerror',lambda e:errors.append(str(e)))
  fixture=(ROOT/'tests/fixtures/nested.html').read_text()
  fixture=re.sub(r'<script\b[^>]*>.*?</script>', '', fixture, flags=re.S|re.I)
  fixture=re.sub(r'<link\b[^>]*rel="stylesheet"[^>]*>', '', fixture, flags=re.I)
  fixture=fixture.replace('<base href="/tester/">','')
  page.set_content(fixture)
  for css in ['tester/mock.css','styles.css','premium.css']:
   page.add_style_tag(content=(ROOT/css).read_text())
  for script in ['tester/mock-shim.js','editor-bridge.js','content.js','themes.js','theme.js','workspace.js','app-frames.js','chrome-glass.js','effects.js','tester/mock.js']:
   js=(ROOT/script).read_text()
   if script=='tester/mock-shim.js': js=js.replace("new URL('../'+path,location.href).href", "'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVQIHWP4////fwAJ+wP+Y+9J5wAAAABJRU5ErkJggg=='")
   page.add_script_tag(content=js)
  page.wait_for_selector('#zd-floating-sla-timer')
  def send(name,extra=None):
   return page.evaluate('v=>new Promise(r=>chrome.runtime.__send({type:v.name,...v.extra},r))',{'name':name,'extra':extra or {}})
  def scenario(name): page.evaluate('name=>window.postMessage({zenxTest:true,type:"scenario",scenario:name},"*")',name);page.wait_for_timeout(200)
  # Scenario handler checks postMessage source == parent, so for same-page use direct message rather than exposed API:
  def scenario2(name):
   page.evaluate('name=>{const d=document;const root=d.querySelector("#mock-messages");root.replaceChildren();const tab=d.querySelector("#active-tab");tab.setAttribute("data-entity-id","10501");tab.lastElementChild.textContent="Ticket #10501"; const mk=(type,text,tm,id)=>{const a=d.createElement("article");a.dataset.testId="omni-log-comment-item";a.dataset.eventId=id;const sender=d.createElement("div");sender.dataset.testId="omni-log-item-sender";sender.textContent=type==="agent"?"Support Agent":"Alex Customer";const time=d.createElement("time");time.dataset.testId="timestamp-relative";time.textContent=tm;const box=d.createElement("div");box.dataset.testId="omni-log-item-message";box.setAttribute("type",type);const content=d.createElement("div");content.dataset.testId="omni-log-message-content";content.textContent=text;box.appendChild(content);a.append(sender,time,box);root.append(a);return a};mk("agent",name==="hold"?"Please allow me 3-5 minutes":"Checking your request","1 minute ago","agent-1");}',name)
   page.wait_for_timeout(200)
  scenario2('hold')
  first=send('GET_STATUS')['slaState']
  assert first['rule']=='hold' and 235 <= first['remainingSec'] <= 240,first
  page.evaluate('()=>{const a=document.createElement("article");a.dataset.testId="omni-log-comment-item";a.dataset.chatRole="customer";a.dataset.eventId="customer-2";const time=document.createElement("time");time.dataset.testId="timestamp-relative";time.textContent="just now";const b=document.createElement("div");b.dataset.testId="omni-log-item-message";b.setAttribute("type","end-user");b.textContent="Thanks";a.append(time,b);document.querySelector("#mock-messages").append(a)}')
  page.wait_for_timeout(1250)
  second=send('GET_STATUS')['slaState']
  assert second['rule']=='hold' and second['msgId']==first['msgId'] and second['remainingSec']<first['remainingSec'] and second['remainingSec']>first['remainingSec']-8, (first,second)
  print('PASS customer reply does not restart agent pill')
  # Real new agent message reanchors pill.
  page.evaluate('()=>{const a=document.createElement("article");a.dataset.testId="omni-log-comment-item";a.dataset.eventId="agent-2";const b=document.createElement("div");b.dataset.testId="omni-log-item-message";b.setAttribute("type","agent");const c=document.createElement("div");c.dataset.testId="omni-log-message-content";c.textContent="I am checking now";b.append(c);a.append(b);document.querySelector("#mock-messages").append(a)}')
  page.wait_for_timeout(350)
  third=send('GET_STATUS')['slaState']
  assert third['rule']=='general' and third['msgId']!=second['msgId'] and third['remainingSec']>=118,third
  print('PASS new agent message starts new pill cycle')
  # Top-tab timer is distinct: does not restart for incoming/agent messages; clicking it explicitly resets it.
  badge=page.locator('#active-tab > .zenx-tab-sla-badge')
  badge.wait_for(timeout=3000)
  top_before=badge.text_content()
  assert top_before
  badge.click()
  page.wait_for_timeout(150)
  top_after=badge.text_content()
  assert top_after=='1:00',(top_before,top_after)
  assert send('GET_STATUS')['slaState']['rule']=='general'
  print('PASS top tab resets on explicit click without changing pill')
  # Macro insertion prioritizes the real conversation composer over ticket fields.
  content='Please allow me a few minutes to check your request.'
  ret=send('INSERT_MACRO',{'text':content})
  assert ret['success'],ret
  editor=page.locator('[data-test-id="omni-composer-text-input"]')
  assert content in editor.inner_text(),editor.inner_text()
  assert page.locator('#native-assignee').input_value()=='Support Agent'
  print('PASS macro inserts draft in native contenteditable, not fields')
  # Re-run with textarea alternative (older Zendesk composer).
  page.evaluate('()=>{const area=document.createElement("textarea");area.dataset.testId="omni-composer-text-input";document.querySelector("[data-test-id=omni-composer-text-input]").replaceWith(area)}')
  ret=send('INSERT_MACRO',{'text':'Textarea macro text'})
  assert ret['success'],ret
  assert page.locator('textarea[data-test-id="omni-composer-text-input"]').input_value()=='Textarea macro text'
  print('PASS macro inserts draft in native textarea')
  # Actual floating countdown suggestion must use the same writer and must not send.
  page.evaluate('()=>{const last=document.querySelector("[data-event-id=agent-2]");const t=document.createElement("time");t.dataset.testId="timestamp-relative";t.textContent="2 min ago";last.append(t)}')
  page.wait_for_timeout(1350)
  options=page.locator('#zd-macro-popup-text .zd-macro-option')
  assert options.count() >= 1, ('No actionable macro suggestion',send('GET_STATUS')['slaState'])
  count_before=page.locator('article[data-test-id="omni-log-comment-item"]').count()
  page.evaluate('()=>document.querySelector("#zd-macro-popup-text .zd-macro-option").click()')
  actual=page.locator('textarea[data-test-id="omni-composer-text-input"]').input_value()
  assert 'I need a few minutes to review your account.' in actual, actual
  assert page.locator('article[data-test-id="omni-log-comment-item"]').count() == count_before
  print('PASS clicking countdown suggestion fills draft without sending')
  assert not errors,errors
  browser.close()
