/* ZenX 8.4 app-frame presentation. No app data, inputs or handlers are replaced.
   Accessible frames get the selected palette. Other origins keep their own
   luminance and receive only a mild tint, never a second dark-mode inversion. */
(() => {
  'use strict';
  // This entry is also loaded in cross-origin app frames. Its Zendesk match
  // must remain origin-wide for match_origin_as_fallback, so stop immediately
  // on top-level Help Center /hc, Admin, and all non-agent Zendesk pages.
  const zenxIsZendeskHost = /(^|\.)zendesk\.com$/i.test(location.hostname);
  if (window === window.top && zenxIsZendeskHost &&
      !/^\/agent(?:\/|$)/i.test(location.pathname)) return;
  if (globalThis.__zenxAppFramesLoaded) return;
  globalThis.__zenxAppFramesLoaded = true;
  const APP_SHELL = '[data-zenx-surface="apps"],[data-zenx-column="apps"],[data-test-id="component-type-AppsPane"],[data-test-id="ticket-apps-pane"],#apps_sidebar,[data-test-id="apps-pane"],[data-test-id="customer-context"],[data-test-id="context-panel"],[data-test-id="customer-details-pane"],[data-test-id="apps-tray"],.app_view.apps_ticket_sidebar,.app_view.apps_nav_bar,.app_view.apps_top_bar,[data-test-id="ticket-sidebar-app-element-container"],[data-test-id="nav-bar-app-pane-app-element-container"],[data-test-id="top-bar-app-pane-app-element-container"]';
  const SKIP = 'script,style,link,meta,title,svg,svg *,img,picture,video,audio,canvas,iframe,object,embed,option';
  const MESSAGE = 'zenx-app-palette-v84';
  const activeRoot = document.documentElement;
  const managed = new Map();
  const normalization=new Map(),scratch=document.createElement('span').style;
  // The embedded Oracle app uses hard-coded navy (#0C1C43) for many values and
  // icons, even after its white cards have been converted to glass surfaces.
  // Keep its information legible without rewriting any app handlers or markup.
  function isLowContrastDarkPaint(value) {
    const match=String(value||'').match(/^rgba?\(\s*([\d.]+)[,\s]+([\d.]+)[,\s]+([\d.]+)(?:[,\s/]+([\d.]+))?\s*\)$/i);
    if(!match || (match[4]!==undefined && Number(match[4])<.25))return false;
    const rgb=[1,2,3].map(i=>Number(match[i])/255);
    const linear=rgb.map(v=>v<=.04045?v/12.92:Math.pow((v+.055)/1.055,2.4));
    return linear[0]*.2126+linear[1]*.7152+linear[2]*.0722 < .24;
  }
  function installPlaceholderStyle(record) {
    if(record.placeholderStyle?.isConnected)return;
    const style=record.doc.createElement('style');
    style.id='zenx-app-readable-fields-v84';
    style.textContent=`html[data-zenx-app-document="1"].zskin-dark input::placeholder,
      html[data-zenx-app-document="1"].zskin-dark textarea::placeholder {
        color:var(--zenx-app-muted) !important;
        -webkit-text-fill-color:var(--zenx-app-muted) !important;
        opacity:1 !important;
      }`;
    (record.doc.head||record.doc.documentElement).appendChild(style);
    record.placeholderStyle=style;
  }
  let queued = false, stopped = false;
  const equal = (style, name, value) => style.getPropertyValue(name) === value && style.getPropertyPriority(name) === 'important';
  function write(record, el, name, value) {
    const key=name+'\0'+value;
    if(normalization.has(key))value=normalization.get(key);
    else{scratch.setProperty(name,value,'important');value=scratch.getPropertyValue(name);scratch.removeProperty(name);normalization.set(key,value);}
    let props = record.styles.get(el);
    if (!props) { props = new Map(); record.styles.set(el, props); }
    let property = props.get(name);
    if (!property) {
      property = {original: el.style.getPropertyValue(name), priority: el.style.getPropertyPriority(name), applied: value};
      props.set(name, property);
    } else if (el.style.getPropertyValue(name) !== property.applied) {
      // Preserve a newer native app update when the theme is later disabled.
      property.original = el.style.getPropertyValue(name);
      property.priority = el.style.getPropertyPriority(name);
    }
    property.applied = value;
    if (!equal(el.style, name, value)) el.style.setProperty(name, value, 'important');
  }
  function restore(record) {
    record.observer?.disconnect();record.observer=null;
    if(record.timer!==null)clearTimeout(record.timer);
    record.timer=null;record.queued=false;record.palette=null;
    record.placeholderStyle?.remove();record.placeholderStyle=null;
    if(record.classes)for(const [name,p] of record.classes)if(record.doc.documentElement.classList.contains(name)===p.applied)record.doc.documentElement.classList.toggle(name,p.original);
    record.classes=null;
    for (const [el, props] of record.styles) for (const [name, property] of props) {
      if (el.style.getPropertyValue(name) !== property.applied) continue;
      if (property.original) el.style.setProperty(name, property.original, property.priority);
      else el.style.removeProperty(name);
    }
    for (const el of record.marked) el.removeAttribute('data-zenx-app-surface');
    if (record.doc?.documentElement?.getAttribute('data-zenx-app-document') === '1') record.doc.documentElement.removeAttribute('data-zenx-app-document');
    record.styles.clear(); record.marked.clear();
  }
  function recordFor(doc,ownsClasses=false) { return {doc, ownsClasses, classes:null, styles:new Map(), marked:new Set(), observer:null, timer:null, queued:false, palette:null, placeholderStyle:null}; }
  function hue(hex) {
    const m = String(hex).match(/^#([\da-f]{6})$/i);
    if (!m) return 38;
    const [r,g,b] = [0,2,4].map(i => parseInt(m[1].slice(i,i+2),16)/255);
    const max=Math.max(r,g,b),min=Math.min(r,g,b),delta=max-min;
    if (!delta) return 38;
    let h=max===r?((g-b)/delta)%6:max===g?(b-r)/delta+2:(r-g)/delta+4;
    return (h*60+360)%360;
  }
  function palette() {
    const s=getComputedStyle(activeRoot), light=activeRoot.classList.contains('zskin-light');
    const value=(name,fallback) => s.getPropertyValue(name).trim() || fallback;
    return {
      enabled:activeRoot.classList.contains('zskin-active') && activeRoot.classList.contains('zenx-premium'),
      light, accent:value('--zx-accent',value('--zenx-theme-accent','#ffb549')),
      ink:value('--zx-ink',light?'#283341':'#f7f3ed'),
      muted:value('--zx-muted',light?'#596779':'#bdb5ad'),
      panel:value('--zx-panel',light?'rgba(255,255,255,.74)':'rgba(23,23,25,.68)'),
      control:value('--zx-control',light?'rgba(255,255,255,.80)':'rgba(22,22,24,.68)'),
      border:value('--zx-border',light?'rgba(70,70,80,.24)':'rgba(255,255,255,.20)')
    };
  }
  function hasPaint(background) {
    if(!background||background==='transparent')return false;
    const alpha=background.match(/^rgba\([^)]*,\s*([\d.]+)\)$/);
    return !alpha || Number(alpha[1])>0;
  }
  function ownStyleMutation(record, element) {
    const props=record.styles.get(element);
    return props && [...props].every(([name, property]) => element.style.getPropertyValue(name) === property.applied);
  }
  function themeDocument(record, p) {
    const doc=record.doc, root=doc?.documentElement, view=doc?.defaultView;
    if (!root || !doc.body || !view || view.closed) return;
    // An iframe can navigate before a queued mutation callback runs. Its old
    // document may still have nodes while its Window has already gone away.
    try { if(view.document!==doc)return; } catch(_) { return; }
    record.palette=p;
    if (!p.enabled) { restore(record); return; }
    root.setAttribute('data-zenx-app-document','1');
    installPlaceholderStyle(record);
    for(const [name,next] of [['zskin-dark',!p.light],['zskin-light',p.light]]){
      if(record.ownsClasses){
        if(!record.classes)record.classes=new Map();
        if(!record.classes.has(name))record.classes.set(name,{original:root.classList.contains(name),applied:next});
        else record.classes.get(name).applied=next;
      }
      if(root.classList.contains(name)!==next)root.classList.toggle(name,next);
    }
    for (const [key,value] of Object.entries({accent:p.accent,ink:p.ink,muted:p.muted,panel:p.panel,control:p.control,border:p.border})) write(record,root,'--zenx-app-'+key,value);
    const candidates=[root,doc.body,...doc.body.querySelectorAll('*')];
    for (const el of candidates.slice(0,6000)) {
      if (el.closest('canvas,[data-test-id="omni-log-item-message"],article')) continue;
      let cs;try { cs=view.getComputedStyle(el); } catch(_) { continue; }
      if (cs.display==='none' || cs.visibility==='hidden') continue;
      const semantic=el.closest('[role="status"],[role="alert"],[data-status],.status,.badge,.success,.error,.warning,.danger,.positive,.negative');
      if(semantic)continue;
      if(el.namespaceURI==='http://www.w3.org/2000/svg') {
        // SVG paths often use literal navy stroke/fill rather than currentColor.
        // Native status/success/error graphics are intentionally excluded above.
        const iconColor=el.closest('a[href],button,[role="button"]')?'var(--zenx-app-accent)':'var(--zenx-app-muted)';
        if(el.localName==='svg')write(record,el,'color',iconColor);
        if(!p.light)for(const paint of ['stroke','fill']) {
          if(isLowContrastDarkPaint(cs[paint]))write(record,el,paint,iconColor);
        }
        continue;
      }
      if (el.matches(SKIP) || el.closest('svg')) continue;
      const control=el.matches('input:not([type="checkbox"]):not([type="radio"]):not([type="range"]):not([type="color"]),textarea,select,button,[role="button"],[role="combobox"],[role="textbox"],[contenteditable="true"]');
      const old=record.marked.has(el);
      const painted=hasPaint(cs.backgroundColor);
      if (el===root || el===doc.body || painted || control || old) {
        const role=el===root?'root':el===doc.body?'body':control?'control':'surface';
        if (el.getAttribute('data-zenx-app-surface')!==role) el.setAttribute('data-zenx-app-surface',role);
        record.marked.add(el);
        write(record,el,'background-color',role==='root'?'transparent':control?'var(--zenx-app-control)':'var(--zenx-app-panel)');
        if (cs.borderTopStyle!=='none' || cs.borderBottomStyle!=='none' || control) write(record,el,'border-color','var(--zenx-app-border)');
        if(/(?:linear|radial|conic)-gradient\(/.test(cs.backgroundImage)&&!cs.backgroundImage.includes('url('))write(record,el,'background-image','none');
      }
      // A paragraph with a copy-icon span or an SVG isn't a leaf, so the
      // previous test silently left its hard-coded navy text on a dark card.
      // Explicitly cover every node that has its own visible text, regardless
      // of its child elements, without restyling unrelated layout wrappers.
      const hasDirectText=[...el.childNodes].some(n=>n.nodeType===3 && !!n.textContent.trim());
      if (control || hasDirectText || el===doc.body || el.matches('label,h1,h2,h3,h4,h5,h6,legend,summary,header,nav,main,section')) {
        const color=el.closest('a[href],[role="link"]')?'var(--zenx-app-accent)':'var(--zenx-app-ink)';
        write(record,el,'color',color);
        if (control) write(record,el,'-webkit-text-fill-color',color);
      }
    }
    for (const [el] of record.styles) if (!el.isConnected) { record.styles.delete(el); record.marked.delete(el); }
    if (!record.observer) {
      record.observer=new MutationObserver(changes=>{
        if (record.queued || stopped) return;
        const nativeChange=changes.some(change=>change.type==='childList' ? [...change.addedNodes].some(n=>n.nodeType===1) : change.attributeName==='class' || !ownStyleMutation(record,change.target));
        if (!nativeChange) return;
        record.queued=true;
        record.timer=setTimeout(()=>{record.timer=null;record.queued=false;if(record.palette?.enabled)themeDocument(record,record.palette);},80);
      });
      record.observer.observe(root,{childList:true,subtree:true,attributes:true,attributeFilter:['class','style']});
    }
  }
  function appFrame(frame) {
    // Native Zendesk keeps inactive ticket apps mounted and some are <180px.
    // App identity, not geometry, determines whether the palette is applied.
    if (frame.closest('.apps_background,[data-test-id="background-app-view-wrapper"]')) return false;
    if (frame.closest(APP_SHELL)) return true;
    const r=frame.getBoundingClientRect();
    return r.width>160 && r.height>180 && r.left>innerWidth*.5 && !!frame.closest('aside,[role="complementary"],[data-test-id*="app"],[data-test-id*="sidebar"]');
  }
  function restoreFrame(frame, rec) {
    frame.removeAttribute('data-zenx-frame-managed');
    frame.removeAttribute('data-zenx-frame-mode');
    if (rec.document) restore(rec.document);
    restore(rec);
  }
  function syncFrame(frame, rec, p) {
    if (!p.enabled) { restoreFrame(frame,rec); try { frame.contentWindow?.postMessage({type:MESSAGE,palette:p},'*'); } catch(_) {} return; }
    frame.setAttribute('data-zenx-frame-managed','1');
    write(rec,frame,'background-color',p.panel);
    let doc=null;
    try { doc=frame.contentDocument; if(!doc?.documentElement) doc=null; } catch(_) {}
    if (doc) {
      if(rec.document?.doc!==doc) {if(rec.document)restore(rec.document);rec.document=recordFor(doc);}
      write(rec,frame,'filter','none');
      frame.setAttribute('data-zenx-frame-mode','palette');
      // A Zendesk child content script can own this document itself. Let it
      // be the sole writer once it has acknowledged the palette message.
      if (rec.remote) { if (rec.document) restore(rec.document); rec.document=null; }
      else themeDocument(rec.document,p);
    } else {
      if(rec.document){restore(rec.document);rec.document=null;}
      // A foreign-origin app cannot be styled internally with Zendesk-only
      // permissions. One reversible frame-level dark fallback avoids a white
      // app panel on first load; never stack it with a child-owned palette.
      const fallback=p.light?'none':'invert(.9) hue-rotate(180deg) saturate(.85)';
      write(rec,frame,'filter',rec.remote?'none':fallback);
      frame.setAttribute('data-zenx-frame-mode',rec.remote?'palette':'fallback');
    }
    try { frame.contentWindow?.postMessage({type:MESSAGE,palette:p},'*'); } catch(_) {}
  }
  function scan() {
    queued=false;if(stopped)return;
    const p=palette(), frames=[...document.querySelectorAll('iframe')].filter(appFrame);
    for (const [frame,rec] of managed) if(!frame.isConnected || !frames.includes(frame)) {restoreFrame(frame,rec);frame.removeEventListener('load',rec.load);managed.delete(frame);}
    for (const frame of frames) {
      let rec=managed.get(frame);
      if(!rec){
        rec=recordFor(null);rec.remote=false;rec.document=null;
        if(frame.hasAttribute('data-zs-panel-dark')&&/invert\(/.test(frame.style.getPropertyValue('filter'))){
          // The old darkener wrote this inversion without preserving an
          // original. It must not return when ZenX is disabled or on reload.
          const props=new Map();
          for(const name of ['filter','background-color'])props.set(name,{original:'',priority:'',applied:frame.style.getPropertyValue(name)});
          rec.styles.set(frame,props);frame.removeAttribute('data-zs-panel-dark');
        }
        rec.load=()=>{rec.remote=false;schedule();};managed.set(frame,rec);frame.addEventListener('load',rec.load);
      }
      syncFrame(frame,rec,p);
    }
  }
  function schedule() {if(queued||stopped)return;queued=true;setTimeout(scan,50);}
  function trustedParent(event) {
    if(event.source!==parent)return false;
    try {const host=new URL(event.origin).hostname;return host==='zendesk.com'||host.endsWith('.zendesk.com');}catch(_){return false;}
  }
  // On the provider's own website (not embedded in Zendesk), do nothing.
  if(window===top && !/(^|\.)zendesk\.com$/.test(location.hostname) && !globalThis.ZenXTestMode) return;
  if(window!==top) {
    // Optional same-permission child entry: only a parent-confirmed app frame
    // is themed. This never loads the timer/SLA content script in a child.
    const child=recordFor(document,true);
    window.addEventListener('message',event=>{
      if(event.data?.type!==MESSAGE || !trustedParent(event))return;
      const p=event.data.palette;
      if(!p || typeof p.enabled!=='boolean' || typeof p.light!=='boolean')return;
      themeDocument(child,p);
      try{parent.postMessage({type:MESSAGE+'-ready'},event.origin);}catch(_){}
    });
    try{parent.postMessage({type:MESSAGE+'-ready'},'*');}catch(_){}
    window.addEventListener('pagehide',()=>{stopped=true;restore(child);},{once:true});
    return;
  }
  window.addEventListener('message',event=>{
    if(event.data?.type!==MESSAGE+'-ready')return;
    for(const [frame,rec] of managed) {
      if(event.source!==frame.contentWindow)continue;
      let host='';try{host=new URL(event.origin).hostname;}catch(_){}
      // A ready acknowledgment comes FROM the embedded app origin, not from
      // Zendesk. Checking for a Zendesk origin here prevented every cross-
      // origin app from ever becoming remote-owned, so the parent kept its
      // inversion filter on top of the app's directly themed content.
      // Verify both the sending Window AND the exact iframe URL origin.
      let expected='';
      try{expected=new URL(frame.getAttribute('src')||'',document.baseURI).origin;}catch(_){}
      if(expected && event.origin===expected && !rec.remote){
        rec.remote=true;
        // Drop the parent inversion immediately; a scan will install the
        // native child palette if this is a newly activated frame.
        schedule();
      }
      break;
    }
  });
  const observer=new MutationObserver(changes=>{
    if(changes.some(c=>c.type==='childList' ? [...c.addedNodes,...c.removedNodes].some(n=>n.nodeType===1) : c.target===activeRoot || (c.target.tagName==='IFRAME'&&['src','srcdoc'].includes(c.attributeName))))schedule();
  });
  observer.observe(activeRoot,{childList:true,subtree:true,attributes:true,attributeFilter:['class','style','src','srcdoc']});
  const interval=setInterval(schedule,1800);
  window.addEventListener('resize',schedule,{passive:true});
  window.addEventListener('pagehide',()=>{stopped=true;observer.disconnect();clearInterval(interval);for(const [frame,rec] of managed){restoreFrame(frame,rec);frame.removeEventListener('load',rec.load);}managed.clear();},{once:true});
  schedule();
})();
