/* Click-scene adaptations from the QAHelm and Index ThemeFX collection. */
(() => {
  'use strict';

  const entries = new Map();
  globalThis.PetalReferenceEffects = {
    register(id, label, defaults, draw) {
      entries.set(id, { id, label, ...defaults, draw });
    },
    get(id) { return entries.get(id); },
    get styles() { return [...entries.values()]; }
  };
})();
(() => {
  'use strict';

  const { register } = globalThis.PetalReferenceEffects;
  const TAU = Math.PI * 2;
  const FRAME = 1000 / 60;
  const WHITE = '#ffffff';
  const extraParticles = new WeakMap();
  const clamp = value => Math.max(0, Math.min(1, value));

  const channels = hex => [1, 3, 5].map(offset => parseInt(hex.slice(offset, offset + 2), 16));
  const rgba = (color, alpha) => 'rgba(' + channels(color).join(',') + ',' + clamp(alpha) + ')';
  const mix = (a, b, amount) => {
    const end = channels(b);
    return '#' + channels(a).map((value, i) =>
      Math.round(value + (end[i] - value) * amount).toString(16).padStart(2, '0')).join('');
  };

  function circle(ctx, x, y, radius) {
    ctx.beginPath();
    ctx.arc(x, y, Math.max(0, radius), 0, TAU);
  }

  function glow(ctx, x, y, radius, ink, alpha) {
    if (radius <= 0 || alpha <= 0) return;
    const gradient = ctx.createRadialGradient(x, y, 0, x, y, radius);
    gradient.addColorStop(0, rgba(ink, alpha));
    gradient.addColorStop(.35, rgba(ink, alpha * .45));
    gradient.addColorStop(1, rgba(ink, 0));
    ctx.fillStyle = gradient;
    ctx.fillRect(x - radius, y - radius, radius * 2, radius * 2);
  }

  function wave(ctx, burst, radius, width, alpha) {
    const start = burst.angle === null ? 0 : burst.angle - Math.PI / 3;
    const end = burst.angle === null ? TAU : burst.angle + Math.PI / 3;
    ctx.strokeStyle = rgba(burst.primary, alpha);
    ctx.lineWidth = width * burst.size;
    ctx.beginPath();
    ctx.arc(0, 0, radius, start, end);
    ctx.stroke();
  }

  function drawNova(ctx, burst, t) {
    // Create a small click-local star field for the original Nova wave to push.
    const span = burst.spread / 95;
    const ring = Math.max(.1, t * 520 * span);
    const stars = burst.particles.map((particle, index) => {
      const distance = particle.distance * 2.2;
      const passed = clamp((ring - distance + 40 * span) / (95 * span));
      const push = 17 * span * passed * (1 - .55 * t);
      const heading = particle.angle;
      return { x: Math.cos(heading) * (distance + push), y: Math.sin(heading) * (distance + push), passed, particle, index };
    });
    const fade = Math.min(1, t * 12.5) * (1 - t);
    const linkRange = 110 * span;
    ctx.lineWidth = .6 * burst.size;
    for (let i = 0; i < stars.length; i++) {
      const a = stars[i];
      for (let j = i + 1; j < stars.length; j++) {
        const b = stars[j];
        const separation = Math.hypot(a.x - b.x, a.y - b.y);
        if (separation >= linkRange) continue;
        ctx.strokeStyle = rgba(burst.primary, (1 - separation / linkRange) * fade * .38);
        ctx.beginPath();
        ctx.moveTo(a.x, a.y);
        ctx.lineTo(b.x, b.y);
        ctx.stroke();
      }
    }
    for (const item of stars) {
      const { x, y, passed, particle, index } = item;
      const twinkle = .55 + .45 * Math.sin(particle.phase + t * 3.6);
      const alpha = fade * (.29 + twinkle * .56 + passed * .2);
      const size = (.55 + particle.scale * 1.3) * burst.size;
      const ink = index % 2 === 0 ? burst.secondary : mix(burst.secondary, WHITE, .5);
      glow(ctx, x, y, size * 3.1, ink, alpha * .35);
      ctx.fillStyle = rgba(ink, alpha);
      circle(ctx, x, y, size);
      ctx.fill();
    }
    wave(ctx, burst, ring, 1.5, (1 - t) * .5);
  }

  // Closed-form version of the original fixed-timestep damped spark velocity.
  function launch(particle, frames, drag, gravity, velocity, upward) {
    const friction = drag ** frames;
    const travel = (1 - friction) / (1 - drag);
    const vx = Math.cos(particle.angle) * velocity;
    const vy = Math.sin(particle.angle) * velocity - upward;
    const acceleration = gravity / (1 - drag);
    return {
      x: vx * drag * travel,
      y: vy * drag * travel + acceleration * (frames - drag * travel),
      vx: vx * friction,
      vy: vy * friction + acceleration * (1 - friction)
    };
  }

  function particlesAtDensity(burst, referenceCount) {
    if (extraParticles.has(burst)) return extraParticles.get(burst);
    const length = Math.round(burst.count / 8 * referenceCount);
    let state = burst.seed ^ 0x6d2b79f5;
    const random = () => {
      state = (Math.imul(state, 1664525) + 1013904223) >>> 0;
      return state / 2 ** 32;
    };
    const particles = Array.from({ length }, () => ({
      angle: burst.angle === null ? random() * TAU : burst.angle + (random() - .5) * 1.55,
      distance: burst.spread * (.45 + random() * .55),
      scale: .48 + random() * .54,
      delay: random() * .12
    }));
    extraParticles.set(burst, particles);
    return particles;
  }

  function drawEmbers(ctx, burst, t) {
    const span = burst.spread / 95;
    const hot = mix(burst.secondary, '#ffd696', .55);
    const elapsed = t * 1350;
    const flash = elapsed / 600;
    if (flash < 1) glow(ctx, 0, 0, 120 * span * burst.size * (1 + flash), hot, (1 - flash) * .6);
    const frames = elapsed / FRAME;
    ctx.lineCap = 'round';
    ctx.lineWidth = 1.5 * burst.size;
    for (const particle of particlesAtDensity(burst, 46)) {
      const decay = .012 + particle.delay / .12 * .013;
      const life = 1 - frames * decay;
      if (life <= 0) continue;
      const strength = 2.4 + (particle.distance / burst.spread - .45) / .55 * 3.6;
      const spark = launch(particle, frames, .97, .04, strength, 1.5);
      ctx.strokeStyle = rgba(life > .6 ? hot : burst.primary, life);
      ctx.beginPath();
      ctx.moveTo(spark.x * span, spark.y * span);
      ctx.lineTo((spark.x - spark.vx * 3) * span, (spark.y - spark.vy * 3) * span);
      ctx.stroke();
    }
  }

  function crystal(ctx, length, ink, alpha, width) {
    ctx.strokeStyle = rgba(ink, alpha);
    ctx.lineWidth = width;
    ctx.lineCap = 'round';
    ctx.beginPath();
    for (let leg = 0; leg < 6; leg++) {
      const angle = leg * TAU / 6;
      const cos = Math.cos(angle);
      const sin = Math.sin(angle);
      const point = (x, y) => [x * cos - y * sin, x * sin + y * cos];
      ctx.moveTo(0, 0);
      ctx.lineTo(...point(0, -length));
      for (let branch = 1; branch <= 3; branch++) {
        const position = -length * branch / 4;
        const width = length * (.28 - branch * .05);
        ctx.moveTo(...point(0, position));
        ctx.lineTo(...point(-width, position - width));
        ctx.moveTo(...point(0, position));
        ctx.lineTo(...point(width, position - width));
      }
    }
    ctx.stroke();
  }

  function drawArctic(ctx, burst, t) {
    const span = burst.spread / 95;
    const frames = t * 1300 / FRAME;
    const life = 1 - frames * .015;
    if (life > 0) {
      particlesAtDensity(burst, 40).forEach((particle, index) => {
        const strength = 1 + (particle.distance / burst.spread - .45) / .55 * 4;
        const puff = launch(particle, frames, .95, .03, strength, 1);
        const radius = (1.5 + particle.scale * 3.4) * (2.5 - life) * burst.size;
        glow(ctx, puff.x * span, puff.y * span, radius, index % 2 ? burst.primary : burst.secondary, life * .8);
      });
    }

    const radius = (20 + t * 150) * span;
    const alpha = (1 - t) * .7;
    wave(ctx, burst, radius, 1.2, alpha);
    const count = Math.min(8, burst.count);
    for (let index = 0; index < count; index++) {
      const angle = burst.angle === null ? index * TAU / count + t * 1.2 :
        burst.angle + (index + .5) / count * 2 * Math.PI / 3 - Math.PI / 3 + t * .2;
      ctx.save();
      ctx.translate(Math.cos(angle) * radius, Math.sin(angle) * radius);
      ctx.rotate(angle + t * 3);
      crystal(ctx, 7.2 * (1 - t * .5) * burst.size, burst.secondary, alpha, Math.max(.35, .66 * burst.size));
      ctx.restore();
    }
  }

  function petal(ctx, width, height, ink) {
    ctx.save();
    ctx.scale(width / 40, height / 40);
    const gradient = ctx.createLinearGradient(0, -18, 0, 18);
    gradient.addColorStop(0, mix(ink, WHITE, .55));
    gradient.addColorStop(1, ink);
    ctx.fillStyle = gradient;
    ctx.beginPath();
    ctx.moveTo(0, 18);
    ctx.bezierCurveTo(-16, 6, -12, -14, 0, -18);
    ctx.bezierCurveTo(12, -14, 16, 6, 0, 18);
    ctx.fill();
    ctx.strokeStyle = rgba(WHITE, .35);
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(0, 14);
    ctx.lineTo(0, -12);
    ctx.stroke();
    ctx.restore();
  }

  function flower(ctx, burst, elapsed, amount, petals, twist) {
    const scale = clamp(elapsed / 1100);
    const opening = 1 + 2.70158 * (scale - 1) ** 3 + 1.70158 * (scale - 1) ** 2;
    const size = 72 * burst.size * amount;
    ctx.save();
    ctx.globalAlpha *= Math.min(1, elapsed / 500) * .9;
    for (const layer of [0, 1]) {
      const proportion = layer ? .62 : 1;
      const ink = layer ? mix(burst.secondary, WHITE, .26) : burst.primary;
      const width = size * .5 * opening * proportion;
      const height = size * .62 * opening * proportion;
      for (let index = 0; index < petals; index++) {
        const angle = twist * (layer ? -1 : 1) + (layer ? Math.PI / petals : 0) +
          index * TAU / petals + Math.sin(elapsed * .0015 + index) * .04;
        ctx.save();
        ctx.rotate(angle + Math.PI / 2);
        ctx.translate(0, -height * .5);
        petal(ctx, width, height, ink);
        ctx.restore();
      }
    }
    const core = size * .22 * opening;
    glow(ctx, 0, 0, core, mix(burst.secondary, '#ffdc78', .5), 1);
    ctx.fillStyle = mix(burst.secondary, '#ffe68c', .5);
    for (let index = 0; index < 6; index++) {
      const angle = index * TAU / 6 + twist;
      circle(ctx, Math.cos(angle) * core * .35, Math.sin(angle) * core * .35, 1.5 * burst.size * opening);
      ctx.fill();
    }
    ctx.restore();
  }

  function drawCandy(ctx, burst, t) {
    const elapsed = t * 4600;
    const span = burst.spread / 95;
    const petals = burst.seed % 2 ? 5 : 6;
    const twist = (burst.angle ?? burst.particles[0].phase) + Math.min(3500, elapsed) * .00012;
    if (elapsed < 3500) {
      flower(ctx, burst, elapsed, 1, petals, twist);
    } else {
      // The source switches from one bloom to small, folding petals when it sheds.
      const shed = (elapsed - 3500) / 1100;
      for (let index = 0; index < petals; index++) {
        const angle = twist + index * TAU / petals;
        const drift = (28 * burst.size + shed * 69 * span);
        const x = Math.cos(angle) * drift + Math.sin(shed * 3 + index) * shed * 6;
        const y = Math.sin(angle) * drift + shed ** 2 * 50 * span;
        ctx.save();
        ctx.globalAlpha *= (1 - shed) * .93;
        ctx.translate(x, y);
        ctx.rotate(angle + Math.PI / 2 + shed * 2);
        ctx.scale(.3 + .7 * Math.abs(Math.cos(index + shed * 5)), 1);
        petal(ctx, 25 * burst.size, 25 * burst.size, index % 2 ? burst.secondary : burst.primary);
        ctx.restore();
      }
    }

    const frames = elapsed / FRAME;
    const life = 1 - .025 * frames;
    if (life <= 0) return;
    ctx.lineWidth = burst.size;
    for (const particle of particlesAtDensity(burst, 14)) {
      const distance = frames * particle.distance / burst.spread * 3 * span;
      const x = Math.cos(particle.angle) * distance;
      const y = Math.sin(particle.angle) * distance;
      const size = (3 + particle.scale * 4) * life * 2 * burst.size;
      const ink = mix(burst.secondary, WHITE, .2);
      glow(ctx, x, y, size, ink, life);
      ctx.strokeStyle = rgba(ink, life);
      ctx.beginPath();
      ctx.moveTo(x - size, y);
      ctx.lineTo(x + size, y);
      ctx.moveTo(x, y - size);
      ctx.lineTo(x, y + size);
      ctx.stroke();
    }
  }

  register('qa-nova', 'Nova', { primary: '#3b82f6', secondary: '#9333ea', duration: 1400 }, drawNova);
  register('qa-embers', 'Charcoal Embers', { primary: '#fbbf24', secondary: '#ffd696', duration: 1350 }, drawEmbers);
  register('qa-arctic', 'Arctic Snow', { primary: '#2196f3', secondary: '#80deea', duration: 1300 }, drawArctic);
  register('qa-candy', 'Candy Bloom', { primary: '#d946ef', secondary: '#f472b6', duration: 4600 }, drawCandy);
})();
/* Click-only adaptations of QAHelm ThemeFX's Lime, Golden and Slate scenes. */
(() => {
  'use strict';

  const { register } = globalThis.PetalReferenceEffects;
  const TAU = Math.PI * 2;
  const paletteAlpha = (hex, alpha) =>
    hex + Math.round(255 * Math.min(1, Math.max(0, alpha))).toString(16).padStart(2, '0');

  // Sum the distances after successive multiplicative velocity damping.
  const dampedDistance = (factor, frames) =>
    factor * (1 - factor ** frames) / (1 - factor);

  function circle(ctx, x, y, radius) {
    ctx.beginPath();
    ctx.arc(x, y, radius, 0, TAU);
  }

  function ellipse(ctx, x, y, rx, ry, rotation) {
    ctx.beginPath();
    ctx.ellipse(x, y, rx, ry, rotation, 0, TAU);
    ctx.fill();
  }

  function rings(ctx, alpha, age, radius, innerRadius, color, width) {
    if (age >= 1) return;
    ctx.globalAlpha = alpha * .6 * (1 - age);
    ctx.strokeStyle = color;
    ctx.lineWidth = width;
    circle(ctx, 0, 0, radius * age);
    ctx.stroke();
    circle(ctx, 0, 0, innerRadius * age);
    ctx.stroke();
  }

  function fizzBubble(ctx, x, y, radius, color) {
    const gradient = ctx.createRadialGradient(x, y, radius * .6, x, y, radius);
    gradient.addColorStop(0, paletteAlpha(color, 0));
    gradient.addColorStop(.8, paletteAlpha(color, .25));
    gradient.addColorStop(1, paletteAlpha(color, 0));
    ctx.fillStyle = gradient;
    circle(ctx, x, y, radius);
    ctx.fill();
    ctx.strokeStyle = paletteAlpha(color, .8);
    ctx.lineWidth = radius / 12.8;
    circle(ctx, x, y, radius * .9);
    ctx.stroke();
    ctx.fillStyle = '#ffffffd9';
    ellipse(ctx, x - radius / 3, y - radius * .37, radius * .2, radius * .117, -.7);
  }

  function lemonadeFizz(ctx, burst, t) {
    const alpha = ctx.globalAlpha;
    const reach = burst.spread / 90;
    const frames = t * 120;
    const fizzLife = Math.max(0, 1 - .006 * frames);
    const horizontal = dampedDistance(.94, frames);
    const vertical = dampedDistance(.97, frames);
    ctx.save();
    if (burst.angle !== null) ctx.rotate(burst.angle + Math.PI / 2);

    burst.particles.forEach((particle, i) => {
      const radius = 1.2 + Math.min(1, Math.max(0, (particle.scale - .48) / .54)) * 2.8;
      const maxRise = .6 + radius * .25;
      const initialRise = 1 + Math.cos(particle.phase) ** 2 * 3;
      const frequency = .05 + particle.delay * .67;
      const wobble = .2 + Math.sin(particle.phase) ** 2 * .4;
      const sinDistance = (Math.cos(particle.phase) - Math.cos(particle.phase + frequency * frames)) / frequency;
      const side = burst.angle === null ? Math.cos(particle.angle) : Math.sin(particle.angle - burst.angle);
      const x = (Math.sin(particle.phase) * 6 + side * 2 * horizontal + wobble * sinDistance) * reach;
      const y = (Math.cos(particle.phase) * 6 - maxRise * frames - (initialRise - maxRise) * vertical) * reach;
      ctx.globalAlpha = alpha * .75 * Math.min(1, fizzLife * 2) * Math.min(1, (1 - t) * 5);
      const color = i % 3 ? burst.primary : burst.secondary;
      fizzBubble(ctx, x, y, radius * burst.size, color);
    });

    // QAHelm's pair of 90 px and 50 px rings clears after the first 900 ms.
    rings(ctx, alpha, t * 2000 / 900, 90 * reach, 50 * reach, burst.primary, 1.5 * burst.size);
    ctx.restore();
  }

  function hexagon(ctx, x, y, radius) {
    ctx.beginPath();
    for (let i = 0; i < 6; i++) {
      const angle = i * Math.PI / 3 - Math.PI / 6;
      const px = x + Math.cos(angle) * radius;
      const py = y + Math.sin(angle) * radius;
      if (i) ctx.lineTo(px, py);
      else ctx.moveTo(px, py);
    }
    ctx.closePath();
  }

  function pollenGlow(ctx, x, y, size, color) {
    const glow = ctx.createRadialGradient(x, y, 0, x, y, size);
    glow.addColorStop(0, color);
    glow.addColorStop(.35, paletteAlpha(color, .45));
    glow.addColorStop(1, paletteAlpha(color, 0));
    ctx.fillStyle = glow;
    ctx.fillRect(x - size, y - size, size * 2, size * 2);
  }

  function bananaHoneycomb(ctx, burst, t) {
    const alpha = ctx.globalAlpha;
    const radius = Math.max(9, 34 * burst.size, burst.spread / 14);
    const cellWidth = Math.sqrt(3) * radius;
    const cellHeight = radius * 1.5;
    const band = radius * 1.2;
    const wave = t * burst.spread * 1.6;
    const rows = Math.ceil((wave + band) / cellHeight);
    const columns = Math.ceil((wave + band) / cellWidth);
    ctx.save();
    if (burst.angle !== null) ctx.rotate(burst.angle);
    ctx.lineWidth = 1.4 * burst.size;
    ctx.fillStyle = ctx.strokeStyle = burst.primary;

    for (let row = -rows; row <= rows; row++) {
      const y = row * cellHeight;
      for (let column = -columns; column <= columns; column++) {
        const x = (column + (row & 1) * .5) * cellWidth;
        const radiusFromClick = Math.hypot(x, y);
        const fromWave = Math.abs(radiusFromClick - wave);
        if (fromWave >= band) continue;
        const sector = burst.angle === null || radiusFromClick === 0 ? 1 :
          Math.max(0, Math.min(1, (x / radiusFromClick - .65) * 4));
        const glow = (1 - t) * (1 - fromWave / band) * sector;
        if (glow < .02) continue;

        hexagon(ctx, x, y, radius - 3 * burst.size);
        ctx.globalAlpha = alpha * glow * .32;
        ctx.fill();
        ctx.globalAlpha = alpha * glow * .8;
        ctx.stroke();
      }
    }
    // Particle angles already include the selected direction.
    if (burst.angle !== null) ctx.rotate(-burst.angle);

    const frames = t * 96;
    const distance = dampedDistance(.98, frames) * burst.spread / 95;
    const life = Math.max(0, 1 - frames * .01) * Math.min(1, (1 - t) * 25);
    for (const particle of burst.particles) {
      const speed = 1 + 2.5 * Math.sin(particle.phase) ** 2;
      const pulse = .5 + .5 * Math.sin(t * 4.8 + particle.phase);
      const radius = (1 + 1.6 * Math.cos(particle.phase) ** 2) * 4 * burst.size;
      const x = Math.cos(particle.angle) * distance * speed;
      const y = Math.sin(particle.angle) * distance * speed - .001 * frames * frames;
      ctx.globalAlpha = alpha * .9 * pulse * life;
      pollenGlow(ctx, x, y, radius, burst.secondary);
    }
    ctx.restore();
  }

  function glassDrop(ctx, x, y, radius, stretch, primary, secondary) {
    ctx.save();
    ctx.translate(x, y);
    ctx.scale(1, stretch);

    const gradient = ctx.createRadialGradient(0, radius * .285, radius / 14, 0, 0, radius);
    gradient.addColorStop(0, paletteAlpha(secondary, .6));
    gradient.addColorStop(.6, paletteAlpha(secondary, .13));
    gradient.addColorStop(1, paletteAlpha(primary, .48));
    ctx.fillStyle = gradient;
    circle(ctx, 0, 0, radius);
    ctx.fill();

    ctx.fillStyle = '#ffffffcc';
    ellipse(ctx, -radius * .32, -radius * .36, radius * .21, radius / 7, -.6);
    ctx.strokeStyle = paletteAlpha(secondary, .7);
    ctx.lineWidth = radius * .09;
    ctx.beginPath();
    ctx.arc(0, 0, radius * .86, Math.PI * .25, Math.PI * .75);
    ctx.stroke();
    ctx.restore();
  }

  function slidingDistance(radius, frames) {
    const acceleration = .04;
    const maxSpeed = 1 + radius * .25;
    const accelerating = Math.min(frames, maxSpeed / acceleration);
    return acceleration * accelerating * (accelerating + 1) / 2 + (frames - accelerating) * maxSpeed;
  }

  function slateRain(ctx, burst, t) {
    const alpha = ctx.globalAlpha;
    const reach = burst.spread / 90;
    const fade = Math.min(1, (1 - t) * 3);
    const frames = t * 75;
    ctx.save();

    for (const particle of burst.particles) {
      const radius = (.8 + Math.sin(particle.phase) ** 2 * 2.2) * burst.size;
      const distance = particle.distance * .66;
      ctx.globalAlpha = alpha * fade;
      glassDrop(ctx, Math.cos(particle.angle) * distance, Math.sin(particle.angle) * distance, radius, 1,
        burst.primary, burst.secondary);
    }

    if (burst.angle !== null) ctx.rotate(burst.angle - Math.PI / 2);
    const drips = Math.min(2, burst.particles.length);
    for (let i = 0; i < drips; i++) {
      const { phase } = burst.particles[i];
      const radius = 4 + Math.cos(phase) ** 2 * 4;
      const x = Math.cos(phase) * (20 + i * 10) * reach;
      const y = i ? Math.sin(phase) * 10 * reach : 0;
      const distance = slidingDistance(radius, frames) * reach;
      const sway = dy => Math.sin(dy * .05 + phase) * 2;

      if (distance > 4) {
        ctx.globalAlpha = alpha * fade * .25;
        ctx.strokeStyle = burst.secondary;
        ctx.lineCap = 'round';
        ctx.lineWidth = radius * .5 * burst.size;
        ctx.beginPath();
        ctx.moveTo(x + sway(0), y);
        for (let step = 4; step < distance; step += 4) {
          ctx.lineTo(x + sway(step), y + step);
        }
        ctx.lineTo(x + sway(distance), y + distance);
        ctx.stroke();
      }

      ctx.globalAlpha = alpha * fade;
      glassDrop(ctx, x + sway(distance), y + distance, radius * burst.size, 1.15,
        burst.primary, burst.secondary);
    }

    rings(ctx, alpha, t * 1250 / 900, 80 * reach, 45 * reach, burst.secondary, 1.4 * burst.size);
    ctx.restore();
  }

  register('qa-lime', 'Lemonade Fizz', { primary: '#4C7F0C', secondary: '#F0FFDC', duration: 2000 }, lemonadeFizz);
  register('qa-honeycomb', 'Banana Honeycomb', { primary: '#FDC32E', secondary: '#FFE696', duration: 1600 }, bananaHoneycomb);
  register('qa-slate', 'Slate Rain', { primary: '#94A3B8', secondary: '#D2E1FF', duration: 1250 }, slateRain);
})();
(() => {
  'use strict';

  const TAU = Math.PI * 2;
  const HEAD_UP = -Math.PI / 2;
  const clamp = value => Math.max(0, Math.min(1, value));
  const unit = angle => ({ x: Math.cos(angle), y: Math.sin(angle) });
  const channel = phase => phase / TAU;
  const tint = (hex, opacity) => hex + Math.round(clamp(opacity) * 255).toString(16).padStart(2, '0');

  function ring(ctx, x, y, radius, color, width) {
    if (radius <= 0) return;
    ctx.strokeStyle = color;
    ctx.lineWidth = width;
    ctx.beginPath();
    ctx.arc(x, y, radius, 0, TAU);
    ctx.stroke();
  }

  function glow(ctx, x, y, radius, color, opacity) {
    const gradient = ctx.createRadialGradient(x, y, 0, x, y, radius);
    gradient.addColorStop(0, tint(color, opacity));
    gradient.addColorStop(.27, tint(color, opacity * .66));
    gradient.addColorStop(1, tint(color, 0));
    ctx.fillStyle = gradient;
    ctx.beginPath();
    ctx.arc(x, y, radius, 0, TAU);
    ctx.fill();
  }

  function heart(ctx, centerY, radius) {
    ctx.beginPath();
    for (let step = 0; step <= 80; step++) {
      const angle = TAU * step / 80;
      const x = Math.sin(angle) ** 3 * radius;
      const y = -(13 * Math.cos(angle) - 5 * Math.cos(2 * angle) -
        2 * Math.cos(3 * angle) - Math.cos(4 * angle)) * radius / 16;
      if (step) ctx.lineTo(x, centerY + y);
      else ctx.moveTo(x, centerY + y);
    }
    ctx.closePath();
  }

  function espresso(ctx, burst, t) {
    const spread = burst.spread / 95;

    // The click emits a cluster of short-lived, drifting steam puffs.
    ctx.save();
    ctx.rotate((burst.angle ?? HEAD_UP) - HEAD_UP);
    for (const particle of burst.particles) {
      const age = t - particle.delay * .68;
      const life = age * (1.52 + channel(particle.phase) * .68);
      if (life < 0 || life >= 1) continue;
      const x = Math.cos(particle.angle) * (13 + age * 31) * spread +
        Math.sin(particle.phase + age * 5) * 10 * age;
      const y = Math.sin(particle.angle) * 8 - age * (95 + particle.scale * 56) * spread;
      const radius = (9 + 9 * particle.scale) * (1 + .95 * life) * burst.size;
      glow(ctx, x, y, radius, burst.secondary, Math.sin(Math.PI * (life * .86 + .08)) * .32);
    }
    ctx.restore();

    // Two nested latte-art hearts expand inside a thin coffee-colored rim.
    const size = (18 + (1 - (1 - t) ** 3) * 70 * spread) * burst.size;
    const alpha = (1 - t) * .61;
    ctx.save();
    ctx.globalAlpha *= alpha;
    heart(ctx, 0, size);
    ctx.fillStyle = tint(burst.primary, .18);
    ctx.fill();
    ctx.strokeStyle = burst.primary;
    ctx.lineWidth = 2 * burst.size;
    ctx.stroke();
    heart(ctx, size * .08, size * .6);
    ctx.lineWidth = 1.2 * burst.size;
    ctx.stroke();
    ring(ctx, 0, 0, size * 1.5, tint(burst.primary, .52), burst.size);
    ctx.restore();
  }

  function ocean(ctx, burst, t) {
    const spread = burst.spread / 95;
    const rippleAge = t * 1.4;
    if (rippleAge < 1) {
      for (let index = 0; index < 3; index++) {
        const radius = rippleAge * (260 - index * 70) * spread * burst.size;
        const opacity = (1 - rippleAge) * (.55 - index * .12);
        ring(ctx, 0, 0, radius, tint(burst.primary, opacity * .7), (2.5 - index * .4) * burst.size);
        ring(ctx, 0, 0, radius, tint(burst.secondary, opacity), (1.8 - index * .4) * burst.size);
      }
    }

    ctx.save();
    ctx.rotate((burst.angle ?? HEAD_UP) - HEAD_UP);
    for (const particle of burst.particles) {
      const life = (t - particle.delay * .25) * 2.55;
      if (life < 0 || life >= 1) continue;
      const angle = HEAD_UP + (channel(particle.phase) * 2 - 1);
      const speed = (91 + 146 * particle.scale) * spread;
      const velocity = unit(angle);
      const x = velocity.x * speed * life;
      const y = velocity.y * speed * life + 116 * spread * life ** 2;
      const radius = (2.4 + particle.scale * 3.8) * burst.size;
      glow(ctx, x, y, radius, burst.primary, (1 - life) * .85);
      glow(ctx, x - radius * .2, y - radius * .24, radius * .46, burst.secondary, (1 - life) * .73);
    }

    for (let index = 0; index < Math.ceil(burst.count * 2 / 3); index++) {
      const particle = burst.particles[index];
      const life = t - particle.delay * .55;
      if (life < 0 || life >= 1) continue;
      const x = Math.cos(particle.angle) * 16 +
        Math.sin(particle.phase + life * 4) * (5 + life * 9) * spread;
      const y = Math.sin(particle.angle) * 8 - life * (70 + 75 * particle.scale) * spread;
      const radius = (1.9 + 3.1 * particle.scale) * burst.size;
      const alpha = (1 - life) * .64;
      glow(ctx, x, y, radius * 2.3, burst.primary, alpha * .48);
      ring(ctx, x, y, radius, tint(burst.primary, alpha * .74), Math.max(.55, .82 * burst.size));
      glow(ctx, x - radius * .29, y - radius * .32, radius * .66, burst.secondary, alpha);
    }
    ctx.restore();
  }

  function midnight(ctx, burst, t) {
    const spread = burst.spread / 95;
    const flareAge = t * (10 / 7);
    if (flareAge < 1) {
      const radius = (30 + flareAge * 220 * spread) * burst.size;
      const alpha = 1 - flareAge;
      glow(ctx, 0, 0, radius, burst.secondary, alpha * .32);
      ring(ctx, 0, 0, radius * .8, tint(burst.secondary, alpha * .53), 1.2 * burst.size);
    }

    const heading = burst.angle ?? (burst.seed % 2 ? Math.PI * .25 : Math.PI * .75);
    ctx.save();
    ctx.lineCap = 'round';
    for (const [index, particle] of burst.particles.entries()) {
      const delay = index / Math.max(1, burst.count - 1) * (.24 + particle.delay * 2.3);
      const age = (t - delay) * 1.92;
      if (age <= 0 || age >= 1) continue;
      const direction = unit(heading + channel(particle.phase) - .5);
      const distance = (280 + 370 * particle.scale) * age * spread;
      const length = (104 + 98 * particle.scale) * Math.min(1, age * 4 + .05) * spread * burst.size;
      const x = direction.x * distance;
      const y = direction.y * distance;
      const tailX = x - direction.x * length;
      const tailY = y - direction.y * length;
      const alpha = Math.min(1, (1 - age) * 1.5);
      const trail = ctx.createLinearGradient(x, y, tailX, tailY);
      trail.addColorStop(0, tint(burst.primary, alpha));
      trail.addColorStop(.3, tint(burst.secondary, alpha * .58));
      trail.addColorStop(1, tint(burst.primary, 0));
      ctx.strokeStyle = trail;
      ctx.lineWidth = (1.2 + particle.scale * 1.15) * burst.size;
      ctx.beginPath();
      ctx.moveTo(x, y);
      ctx.lineTo(tailX, tailY);
      ctx.stroke();
      glow(ctx, x, y, (6 + particle.scale * 5) * burst.size, burst.secondary, alpha * .9);
    }
    ctx.restore();
  }

  PetalReferenceEffects.register('qa-espresso', 'Espresso', {
    primary: '#e9c48c', secondary: '#967355', duration: 1800
  }, espresso);
  PetalReferenceEffects.register('qa-ocean', 'Ocean', {
    primary: '#569eb1', secondary: '#dcfaff', duration: 2100
  }, ocean);
  PetalReferenceEffects.register('qa-midnight', 'Midnight', {
    primary: '#4f46e5', secondary: '#a5b4fc', duration: 2000
  }, midnight);
})();
