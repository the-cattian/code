#!/usr/bin/env python3
"""ZenX 8.5: browser-backed status/Home regression. Uses an isolated mock page."""
from pathlib import Path
import asyncio, json, os
from playwright.async_api import async_playwright
from bs4 import BeautifulSoup
root=Path(__file__).resolve().parents[1]
results=[]
async def check(name,fn):
    try:
        detail=await fn();results.append({'test':name,'pass':True,'detail':detail});print('PASS',name,detail)
    except Exception as exc:
        results.append({'test':name,'pass':False,'error':str(exc)});print('FAIL',name,exc)
async def main():
  async with async_playwright() as p:
    browser=await p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
    page=await browser.new_page(viewport={'width':1440,'height':900})
    errors=[]
    page.on('pageerror',lambda e:errors.append(str(e)))
    html = BeautifulSoup((root/'tests/fixtures/agent-home-status.html').read_text(),'html.parser')
    for tag in html.select('script[src],link[rel=stylesheet]'): tag.decompose()
    await page.set_content(str(html))
    for file in ['premium.css','agent-status.css','agent-home.css']:
      await page.add_style_tag(content=(root/file).read_text())
    await page.add_script_tag(content=(root/'tester/mock-shim.js').read_text())
    await page.evaluate('''window.__zenxTestLocationPath='/agent/home/tickets';''')
    await page.add_script_tag(content=(root/'agent-status.js').read_text())
    source=(root/'agent-home.js').read_text().replace('homeURL=()=>/^','homeURL=()=>/^').replace('.test(location.pathname);','.test(window.__zenxTestLocationPath || location.pathname);')
    await page.add_script_tag(content=source)
    await page.evaluate('''window.zenxFixture={getProfileOpens:()=>opens,navToTicket:()=>window.__zenxTestLocationPath='/agent/tickets/1001',navToHome:()=>window.__zenxTestLocationPath='/agent/home/tickets'}''')
    await page.wait_for_timeout(900)
    async def initial():
      assert await page.locator('html').evaluate('(el)=>el.classList.contains("zenx-agent-home")')
      assert await page.locator('[data-zenx-home-surface="main"]').count()==1
      assert await page.locator('[data-zenx-home-surface="card"]').count()>=2
      assert await page.locator('[data-zenx-home-surface="metric"]').count()==3
      assert await page.locator('#zenx-presence-chip').count()==1
      text=await page.locator('#zenx-presence-chip').inner_text()
      assert 'Online' in text,text
      return {'chip':text,'cards':await page.locator('[data-zenx-home-surface="card"]').count()}
    await check('Home dashboard glass cards and status badge appear',initial)
    async def appearance():
      color=await page.locator('[data-test-id="agent-home-ticket-list"]').evaluate('(el)=>getComputedStyle(el).backgroundImage')
      assert 'gradient' in color,color
      assert 'rgb(255, 255, 255)' not in (await page.locator('[data-test-id="agent-home-ticket-list"]').evaluate('(el)=>getComputedStyle(el).backgroundColor'))
      r=await page.locator('#profile').bounding_box();b=await page.locator('#zenx-presence-chip').bounding_box()
      assert b['x']+b['width']<=r['x']+4,f'status overlay on profile: {b} vs {r}'
      assert b['y']<100
      return {'background':color[:75], 'badge_x':round(b['x'])}
    await check('Home surface themed, profile button unobstructed',appearance)
    async def opening():
      before=await page.evaluate('zenxFixture.getProfileOpens()')
      await page.locator('#zenx-presence-chip').click()
      assert await page.evaluate('zenxFixture.getProfileOpens()')==before+1
      assert await page.locator('#profile-menu').is_visible()
      return 'Native Zendesk profile menu opened'
    await check('Status chip delegates click to native profile menu',opening)
    async def updated():
      await page.locator('[role="menuitemradio"]',has_text='Away').click()
      await page.wait_for_timeout(520)
      chip=page.locator('#zenx-presence-chip')
      assert await chip.get_attribute('data-zenx-presence')=='away'
      assert 'Away' in await chip.inner_text()
      return 'Online → Away reflected immediately'
    await check('Native status changes update badge',updated)
    async def cycle():
      for label,tone in [('Transfers only','transfer'),('Offline','offline'),('Online','online')]:
        await page.locator('#zenx-presence-chip').click()
        await page.locator('[role="menuitemradio"]',has_text=label).click()
        await page.wait_for_timeout(350)
        assert await page.locator('#zenx-presence-chip').get_attribute('data-zenx-presence')==tone,label
      return 'Transfers only / Offline / Online'
    await check('All standard Zendesk status colors update',cycle)
    async def functions():
      await page.locator('[data-test-id="home-status-filter"]').click()
      await page.locator('[href="/agent/tickets/1001"]').evaluate('(a)=>a.addEventListener("click",event=>event.preventDefault(),{once:true})')
      await page.locator('[href="/agent/tickets/1001"]').click()
      assert await page.locator('[data-test-id="home-channel-filter"]').is_enabled()
      return 'Filters, links, ticket list remain interactive'
    await check('Home controls remain native',functions)
    async def nav():
      await page.evaluate('zenxFixture.navToTicket()')
      await page.wait_for_timeout(3000)
      assert not await page.locator('html').evaluate('(el)=>el.classList.contains("zenx-agent-home")')
      assert await page.locator('[data-zenx-home-surface]').count()==0
      assert await page.locator('#zenx-presence-chip').count()==1
      await page.evaluate('zenxFixture.navToHome()')
      await page.wait_for_timeout(3000)
      assert await page.locator('html').evaluate('(el)=>el.classList.contains("zenx-agent-home")')
      return 'SPA switch cleans and restores Home styling'
    await check('Home ⇄ ticket route cleanup',nav)
    async def disable():
      await page.evaluate('chrome.storage.local.set({zenx_enabled:false})')
      await page.wait_for_timeout(500)
      assert await page.locator('#zenx-presence-chip').count()==0
      assert not await page.locator('html').evaluate('(el)=>el.classList.contains("zenx-agent-home")')
      await page.evaluate('chrome.storage.local.set({zenx_enabled:true})')
      await page.wait_for_timeout(500)
      assert await page.locator('#zenx-presence-chip').count()==1
      assert await page.locator('html').evaluate('(el)=>el.classList.contains("zenx-agent-home")')
      return 'Disabled cleans DOM, enabled restores'
    await check('Extension enable/disable lifecycle',disable)
    async def custom():
      await page.evaluate("""() => {
        const menu=document.querySelector('#profile-menu');
        const item=document.createElement('button');
        item.setAttribute('role','menuitemradio');item.setAttribute('aria-checked','false');
        item.textContent='In meeting';menu.appendChild(item);
      }""")
      await page.locator('#zenx-presence-chip').click()
      await page.locator('[role="menuitemradio"]',has_text='In meeting').click()
      await page.wait_for_timeout(370)
      assert await page.locator('#zenx-presence-chip').get_attribute('data-zenx-presence')=='custom'
      assert 'In meeting' in await page.locator('#zenx-presence-chip').inner_text()
      await page.locator('#zenx-presence-chip').click()
      await page.locator('[role="menuitemradio"]',has_text='Online').click()
      await page.wait_for_timeout(300)
      return 'Custom Zendesk status displayed; reset to Online'
    await check('Zendesk custom status presentation',custom)
    async def light():
      await page.evaluate("""() => {
        document.documentElement.classList.remove('zskin-dark');
        document.documentElement.classList.add('zskin-light');
      }""")
      await page.wait_for_timeout(450)
      color=await page.locator('[data-zenx-home-surface="main"] h1').evaluate('(el)=>getComputedStyle(el).color')
      assert color=='rgb(40, 51, 65)',color
      assert await page.locator('#zenx-presence-chip').is_visible()
      await page.evaluate("""() => {
        document.documentElement.classList.remove('zskin-light');
        document.documentElement.classList.add('zskin-dark');
      }""")
      return 'Light theme heading/controls remain legible'
    await check('Home and profile adapt to light theme',light)
    async def narrow():
      await page.set_viewport_size({'width':800,'height':720})
      await page.wait_for_timeout(600)
      badge=await page.locator('#zenx-presence-chip').bounding_box()
      profile=await page.locator('#profile').bounding_box()
      assert badge['x']+badge['width'] <= profile['x'] + 4
      assert not errors,errors
      return {'badge_width':round(badge['width']),'errors':len(errors)}
    await check('Narrow window status placement and no runtime errors',narrow)
    out=root/'tests'/'home-status-validation.json'
    out.write_text(json.dumps({'passed':sum(x['pass'] for x in results),'failed':sum(not x['pass'] for x in results),'results':results,'page_errors':errors},indent=2))
    if os.environ.get('ZENX_CAPTURE'):
      await page.screenshot(path=str(root/'tests'/'home-status-preview.png'),full_page=True)
    await browser.close()
  print('SUMMARY',sum(x['pass'] for x in results),'/',len(results))
  if not all(x['pass'] for x in results):raise SystemExit(1)
if __name__=='__main__':asyncio.run(main())
