/* ZenX v8.5 — passive Zendesk-native agent availability indicator.
 * Reads availability from visible Zendesk controls, never writes it. Selecting
 * a status or opening the dropdown is always delegated to Zendesk itself.
 */
(() => {
  'use strict';
  if (window.__zenxAgentStatusLoaded) return;
  window.__zenxAgentStatusLoaded = true;
  const html = document.documentElement;
  const PROFILE_SELECTORS = [
    '[data-test-id="toolbar-profile-menu-button"]', '[data-garden-id="navigation.profile-menu-button"]',
    '[data-test-id="user-menu"]', '[data-test-id="user-menu-button"]',
    '[data-test-id="header-user-menu"]', '[data-test-id="profile-menu"]',
    '[data-test-id="agent-avatar"]', '[data-garden-id="navigation.avatar"]',
    'button[aria-label*="profile" i]', 'button[aria-label*="user menu" i]',
    'button[title*="profile" i]', 'button[aria-label*="account menu" i]',
    'button[aria-label*="account" i]',
    'button[data-test-id*="avatar" i]'
  ].join(',');
  const STATUS_SELECTORS = [
    '[data-test-id*="agent-status" i]', '[data-test-id*="unified-status" i]',
    '[data-test-id*="current-status" i]', '[data-test-id*="presence-status" i]',
    'button[aria-label*="current status" i]', 'button[aria-label*="availability" i]'
  ].join(',');
  const SELECTED_SELECTORS = [
    '[role="menuitemradio"][aria-checked="true"]',
    '[role="menuitemcheckbox"][aria-checked="true"]',
    '[role="option"][aria-selected="true"]',
    '[role="radio"][aria-checked="true"]',
    '[data-test-id*="status" i][aria-selected="true"]',
    '[data-test-id*="status" i][data-state="checked"]'
  ].join(',');
  const MENU_SELECTORS = '[role="menu"],[role="dialog"],[role="listbox"],[data-test-id*="profile-menu" i],[data-test-id*="status-menu" i],[data-test-id*="status-dropdown" i]';
  const state = { enabled: true, trigger: null, chip: null, label: null, dot: null,
    status: null, scheduled: false, lastRoute: '', attachedTo: null, stopped: false };

  function on() { return state.enabled && html.classList.contains('zskin-active') && html.classList.contains('zenx-premium'); }
  function visible(el) {
    if (!el || !el.isConnected || el.closest('[hidden],[aria-hidden="true"],[inert]')) return false;
    const r = el.getBoundingClientRect();
    if (r.width < 8 || r.height < 8) return false;
    const s = getComputedStyle(el);
    return s.display !== 'none' && s.visibility !== 'hidden' && s.visibility !== 'collapse';
  }
  function normalize(value, trusted = false) {
    const v = String(value || '').replace(/\s+/g, ' ').trim();
    if (!v || v.length > 100) return null;
    // A bare menu action such as "Set online" must not be mistaken for the
    // current status. Only selected items or explicit labels are trusted.
    const exact = /^(?:unified\s+)?(online|away|offline|transfers? only|available|busy)$/i.exec(v);
    const declared = /(?:^|[|,;\-—]\s*|\b)(?:current\s+)?(?:agent\s+)?(?:unified\s+)?(?:availability|presence|status)\s*[:\-–]\s*(.+)$/i.exec(v);
    const picked = exact?.[1] || declared?.[1];
    if (!picked) return null;
    const cleaned = picked.replace(/\s*(?:\(|\||•).*/, '').trim();
    const standard = /^(?:unified\s+)?(online|away|offline|transfers? only|available|busy)$/i.exec(cleaned);
    if (standard) {
      const raw = standard[1].toLowerCase();
      const key = raw === 'available' ? 'online' : raw === 'busy' ? 'custom' :
        raw.startsWith('transfer') ? 'transfer' : raw;
      const label = raw.startsWith('transfer') ? 'Transfers only' :
        raw === 'available' ? 'Online' : raw === 'busy' ? 'Busy' : raw[0].toUpperCase() + raw.slice(1);
      return {label, tone:key};
    }
    if (!declared || !trusted || !/^[\w\s'-]{2,40}$/.test(cleaned)) return null;
    if (/^(?:choose|select|change|set|unknown|not available)$/i.test(cleaned)) return null;
    return {label: cleaned, tone: 'custom'};
  }
  function read(el, allowText = false) {
    if (!el || el === state.chip || el.closest?.('#zenx-presence-chip')) return null;
    for (const name of ['data-agent-status','data-unified-status','data-current-status','data-status','aria-label','title']) {
      const value = el.getAttribute?.(name);
      if (!value) continue;
      const status = normalize(value, true);
      if (status) return status;
    }
    if (allowText) {
      const value = el.textContent?.trim();
      if (value && value.length < 80) return normalize(value, true);
    }
    for (const id of (el.getAttribute?.('aria-labelledby') || '').split(/\s+/)) {
      const label = id && document.getElementById(id);
      const found = label && normalize(label.textContent, true);
      if (found) return found;
    }
    return null;
  }
  function profileTrigger() {
    const possibilities = [...document.querySelectorAll(PROFILE_SELECTORS)]
      .filter(el => !el.matches('[role="menu"],[role="dialog"],[role="listbox"]') &&
        !el.closest('[role="menu"],[role="dialog"],[role="listbox"]'))
      .map(el => el.matches('button,[role="button"]') ? el : el.querySelector('button,[role="button"]') || el)
      .filter((el, i, list) => list.indexOf(el) === i && visible(el));
    const ranked = possibilities.map(el => {
      const r = el.getBoundingClientRect();
      let score = 0;
      if (r.top < 130 && r.right > innerWidth * .53) score += 10;
      if (r.top > innerHeight * .4 || r.left < innerWidth * .45) score -= 20;
      if (/user-menu|profile-menu|header-user-menu/.test(el.getAttribute('data-test-id') || '')) score += 7;
      if (el.closest('[data-test-id="header-toolbar"],[data-test-id="global-header"],[data-garden-id="navigation.header"],header')) score += 5;
      if (el.matches('button,[role="button"]')) score += 2;
      return {el, score};
    }).sort((a,b) => b.score - a.score);
    return ranked[0]?.score >= 8 ? ranked[0].el : null;
  }
  function fromZendesk(trigger) {
    // Selected radio/menu options are a reliable source. Unselected options
    // must never be read as the current status.
    for (const menu of document.querySelectorAll(MENU_SELECTORS)) {
      if (!visible(menu) || menu.closest('#zenx-presence-chip')) continue;
      for (const selected of menu.querySelectorAll(SELECTED_SELECTORS)) {
        const found = read(selected, true);
        if (found) return found;
        const raw = selected.textContent?.replace(/\s+/g,' ').trim();
        const isStatusMenu = /\bonline\b/i.test(menu.textContent || '') &&
          /\baway\b/i.test(menu.textContent || '') && /\boffline\b/i.test(menu.textContent || '');
        if (isStatusMenu && raw && raw.length < 36 && /^[\p{L}][\p{L}\p{N} '-]+$/u.test(raw))
          return {label:raw,tone:'custom'};
        const name = selected.querySelector('[data-test-id*="status" i]');
        if (name) { const nested = read(name, true); if (nested) return nested; }
      }
      // A Zendesk profile dropdown can show "Current status: Online" without
      // using a radio group. Limit this fallback to explicitly named nodes.
      for (const labelled of menu.querySelectorAll('[aria-label*="current status" i],[data-test-id*="current-status" i]')) {
        const found = read(labelled, true);
        if (found) return found;
      }
    }
    // The profile button might expose its current status accessibly.
    for (const el of [trigger, trigger?.parentElement]) {
      const found = read(el, false);
      if (found) return found;
    }
    // Explicit agent-status controls are different from ticket status badges.
    for (const el of document.querySelectorAll(STATUS_SELECTORS)) {
      if (!visible(el) || el.closest('[data-test-id*="ticket" i],[data-zenx-column="conversation"],article')) continue;
      if (!el.closest('header,[data-test-id="header-toolbar"],[data-test-id="global-header"],[data-garden-id="navigation.header"],'+MENU_SELECTORS) && !/agent-status|unified-status|presence-status/i.test(el.getAttribute('data-test-id') || '')) continue;
      const found = read(el, true);
      if (found) return found;
    }
    return null;
  }
  function makeChip() {
    if (state.chip?.isConnected) return state.chip;
    const chip = document.createElement('button');
    chip.id = 'zenx-presence-chip';
    chip.className = 'zenx-presence-chip';
    chip.type = 'button';
    chip.setAttribute('data-zenx-presence', 'unknown');
    const dot = document.createElement('span'); dot.className='zenx-presence-dot'; dot.setAttribute('aria-hidden','true');
    const label = document.createElement('span'); label.className='zenx-presence-name'; label.textContent='Check status';
    const chevron = document.createElement('span'); chevron.className='zenx-presence-chevron'; chevron.setAttribute('aria-hidden','true'); chevron.textContent='⌄';
    chip.append(dot,label,chevron);
    chip.addEventListener('click', () => {
      const trigger = state.trigger;
      if (visible(trigger)) trigger.click();
      setTimeout(schedule,180);
      setTimeout(schedule,550);
    });
    state.chip=chip; state.label=label; state.dot=dot;
    return chip;
  }
  function placeChip(chip, trigger) {
    // Prefer a native flex toolbar slot (no overlay on Help/Search icons).
    // Never place a button *inside* another button or move the profile control.
    let anchor = trigger;
    let parent = trigger.parentElement;
    let host = null;
    for (let i=0; parent && i<5; i++, anchor=parent, parent=parent.parentElement) {
      if (parent === document.body) break;
      const r=parent.getBoundingClientRect(), style=getComputedStyle(parent);
      if (r.width >= 104 && r.width < Math.min(720,innerWidth*.72) &&
          r.height >= 32 && r.height < 110 && /^(flex|inline-flex)$/.test(style.display) &&
          r.top < 145 && parent.contains(trigger)) {
        host = {parent, before: anchor}; break;
      }
    }
    if (host) {
      if (chip.parentElement !== host.parent || chip.nextSibling !== host.before) host.parent.insertBefore(chip, host.before);
      chip.classList.remove('zenx-presence-floating');
      chip.style.removeProperty('top'); chip.style.removeProperty('left'); chip.style.removeProperty('right');
      return;
    }
    // Some Zendesk versions have a fixed, non-flex toolbar. Keep the native
    // markup intact and anchor the display beside the existing profile button.
    if (chip.parentElement !== document.body) document.body.appendChild(chip);
    chip.classList.add('zenx-presence-floating');
    const r=trigger.getBoundingClientRect();
    const width=chip.getBoundingClientRect().width || 126;
    chip.style.top = `${Math.max(8,Math.round(r.top + (r.height-34)/2))}px`;
    chip.style.left = `${Math.max(72,Math.round(r.left-width-10))}px`;
  }
  function paint(status) {
    const chip=state.chip;
    if (!chip) return;
    const data=status || {label:'Check status',tone:'unknown'};
    if (chip.dataset.zenxPresence !== data.tone) chip.dataset.zenxPresence = data.tone;
    if (state.label.textContent !== data.label) state.label.textContent = data.label;
    const hint = status ? `Zendesk agent status: ${data.label}. Open profile menu.` :
      'Agent status not yet exposed by Zendesk. Open your profile menu to detect it.';
    if (chip.title !== hint) chip.title = hint;
    if (chip.getAttribute('aria-label') !== hint) chip.setAttribute('aria-label',hint);
    if (state.trigger) {
      if (status) state.trigger.setAttribute('data-zenx-presence-state', data.tone);
      else state.trigger.removeAttribute('data-zenx-presence-state');
    }
  }
  function remove() {
    if (state.trigger?.hasAttribute('data-zenx-presence-state')) state.trigger.removeAttribute('data-zenx-presence-state');
    state.trigger=null;
    state.chip?.remove();
  }
  function update() {
    state.scheduled=false;
    if (state.stopped) return;
    if (!on()) {remove();return;}
    const trigger=profileTrigger();
    if (!trigger) {remove();return;}
    if (state.trigger && state.trigger !== trigger) state.trigger.removeAttribute('data-zenx-presence-state');
    state.trigger=trigger;
    const chip=makeChip();
    const detected=fromZendesk(trigger);
    if (detected) state.status=detected;
    paint(state.status);
    placeChip(chip,trigger);
  }
  function schedule() {
    if (state.scheduled || state.stopped) return;
    state.scheduled=true;
    setTimeout(update, 140);
  }
  const observer=new MutationObserver(mutations => {
    if (!on()) {if (state.chip?.isConnected) schedule();return;}
    if (mutations.some(m => {
      if (m.type === 'childList') return [...m.addedNodes,...m.removedNodes].some(n => n.nodeType===1 &&
        n !== state.chip && !n.closest?.('#zenx-presence-chip') &&
        !n.matches?.('#zenx-presence-chip,#zenx-cursor-aura,.zenx-click-particle,.zenx-click-ring'));
      if (m.target === html && m.attributeName === 'class') return true;
      if (m.target === state.chip || m.target.closest?.('#zenx-presence-chip')) return false;
      if (m.attributeName === 'data-zenx-presence-state') return false;
      return ['aria-label','aria-checked','aria-selected','data-state','title','class','data-test-id'].includes(m.attributeName) &&
        (m.target===state.trigger || m.target.closest?.('header,[role="menu"],[role="dialog"],[role="listbox"],[data-test-id*="status" i],[data-test-id*="menu" i]'));
    })) schedule();
  });
  observer.observe(html, {subtree:true, childList:true, attributes:true,
    attributeFilter:['class','aria-label','aria-checked','aria-selected','data-state','title','data-test-id']});
  chrome.storage.local.get({zenx_enabled:true}, value => {state.enabled=value.zenx_enabled!==false;schedule();});
  chrome.storage.onChanged.addListener((changes,area) => {if(area==='local' && changes.zenx_enabled){state.enabled=changes.zenx_enabled.newValue!==false;schedule();}});
  document.addEventListener('click', event => {
    if (!on() || event.target.closest?.('#zenx-presence-chip')) return;
    if (event.target.closest?.(MENU_SELECTORS+', '+PROFILE_SELECTORS)) {
      setTimeout(schedule,90); setTimeout(schedule,380); setTimeout(schedule,950);
    }
  },true);
  window.addEventListener('resize',schedule,{passive:true});
  const refresh=setInterval(schedule,2500);
  window.addEventListener('pagehide',()=>{state.stopped=true;clearInterval(refresh);observer.disconnect();remove();},{once:true});
  schedule();
})();
