/* ZenX arcade shortcut isolation. Installs before Zendesk's document shortcut
 * listeners but is inert unless a running ZenX typing game has focus.
 * Does not suppress text insertion; '?' continues to type normally.
 */
(() => {
  'use strict';
  if (window.__zenxLiteArcadeKeyguard) return;
  window.__zenxLiteArcadeKeyguard = true;

  const intercept = (event) => {
    const path=typeof event.composedPath==='function'?event.composedPath():[];
    const input=path.find(node=>node && (node.id==='fall-input'||node.id==='typing-input'));
    const host=path.find(node=>node && node.id==='zenx-lite-arcade-root');
    if (!host || !input || !host.shadowRoot) return;
    const panel=host.shadowRoot;
    const mode=panel.getElementById('game-stage')?.dataset.mode;
    const expected=mode==='wordfall'?'fall-input':mode==='typing'?'typing-input':null;
    if(input.id!==expected || !panel.getElementById('overlay')?.hidden) return;

    if(event.type==='keydown' && event.key==='Escape'){
      event.preventDefault();
      host.dispatchEvent(new CustomEvent('zenx-lite-arcade-command',{detail:'pause'}));
    }else if(event.type==='keydown' && event.key==='Enter' && mode==='wordfall'){
      event.preventDefault();
      host.dispatchEvent(new CustomEvent('zenx-lite-arcade-command',{detail:'clear'}));
    }
    // Stop all page-level shortcut handlers, not normal browser text input.
    event.stopImmediatePropagation();
  };
  for(const type of ['keydown','keypress','keyup']) window.addEventListener(type,intercept,true);
})();
