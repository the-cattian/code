(() => {
  'use strict';

  const prefix = 'zenx_custom_macro:';
  const groupPrefix = 'zenx_custom_macro_group:';
  const maxOptions = 12;
  const validShortcut = /^[a-zA-Z0-9_-]{1,40}$/;
  const macros = new Map();
  const groups = new Map();
  const groupShortcuts = new Map();
  let builtIns = new Map();
  let dialog;
  let refreshList;
  let ready = false;

  function aliases(key, messages) {
    return [[key, messages.join('\n\n')], ...messages.map((text, i) => [key + (i + 1), text])];
  }

  function apply(key, value) {
    if (key.startsWith(groupPrefix)) {
      const shortcut = key.slice(groupPrefix.length);
      if (validShortcut.test(shortcut) && shortcut.length <= 38 &&
          Array.isArray(value) && value.length && value.length <= maxOptions &&
          value.every(text => typeof text === 'string' && text.trim() && text.length <= 4000)) {
        groups.set(shortcut, value);
      } else {
        groups.delete(shortcut);
      }
      groupShortcuts.clear();
      for (const name of [...groups.keys()].sort()) {
        for (const [alias, text] of aliases(name, groups.get(name))) {
          if (!groupShortcuts.has(alias)) groupShortcuts.set(alias, text);
        }
      }
    } else if (key.startsWith(prefix)) {
      const shortcut = key.slice(prefix.length);
      if (validShortcut.test(shortcut) && typeof value === 'string' && value.trim()) {
        macros.set(shortcut, value);
      } else {
        macros.delete(shortcut);
      }
    }
  }

  chrome.storage.local.get(null, items => {
    if (chrome.runtime.lastError) return;
    for (const [key, value] of Object.entries(items)) apply(key, value);
    ready = true;
    refreshList?.();
  });

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== 'local') return;
    const entries = Object.entries(changes).filter(([key]) => key.startsWith(prefix) || key.startsWith(groupPrefix));
    for (const [key, change] of entries) apply(key, change.newValue);
    if (entries.length) refreshList?.();
  });

  function buildDialog() {
    dialog = document.createElement('dialog');
    dialog.id = 'zenx-custom-macros';
    dialog.setAttribute('aria-labelledby', 'zenx-custom-macros-title');
    dialog.innerHTML = `
      <header>
        <h2 id="zenx-custom-macros-title">Custom Macros</h2>
        <button type="button" value="close">Close</button>
      </header>
      <p>Type a shortcut and press Tab in the reply box. For a group like <code>refund</code>, use <code>refund</code> for all replies or <code>refund2</code> for option 2.</p>
      <label>Saved macros
        <select><option value="">New macro</option><option value=":new-group">New group</option></select>
      </label>
      <form>
        <label>Shortcut
          <input name="shortcut" placeholder="hello1" maxlength="40" required>
        </label>
        <label data-single>Reply text
          <textarea name="reply" rows="5" maxlength="4000" required></textarea>
        </label>
        <section data-group hidden>
          <div data-options></div>
          <button type="button" value="add-option">Add reply</button>
        </section>
        <footer>
          <button type="submit">Save macro</button>
          <button type="button" value="delete" hidden>Delete macro</button>
        </footer>
      </form>
      <p role="status"></p>
    `;

    const select = dialog.querySelector('select');
    const form = dialog.querySelector('form');
    const shortcut = form.elements.shortcut;
    const reply = form.elements.reply;
    const save = form.querySelector('[type="submit"]');
    const remove = form.querySelector('[value="delete"]');
    const status = dialog.querySelector('[role="status"]');
    const group = form.querySelector('[data-group]');
    const options = group.querySelector('[data-options]');
    const add = group.querySelector('[value="add-option"]');
    let busy = false;
    let editing = '';

    function updateOptions() {
      const rows = [...options.children];
      rows.forEach((row, index) => {
        const number = index + 1;
        row.querySelector('span').textContent = 'Option ' + number;
        const button = row.querySelector('button');
        button.setAttribute('aria-label', 'Remove option ' + number);
        button.disabled = busy || rows.length === 1;
        row.querySelector('textarea').disabled = busy;
      });
      add.disabled = busy || rows.length >= maxOptions;
    }

    function addOption(text = '') {
      const row = document.createElement('div');
      row.className = 'zenx-macro-group-option';
      row.innerHTML = '<label><span></span><textarea rows="2" maxlength="4000" required></textarea></label>' +
        '<button type="button">Remove</button>';
      const field = row.querySelector('textarea');
      field.value = text;
      row.querySelector('button').addEventListener('click', () => {
        row.remove();
        updateOptions();
        (options.querySelector('textarea') || add).focus();
      });
      options.append(row);
      return field;
    }

    function loadSelected() {
      const selection = select.value;
      const grouped = selection === ':new-group' || selection.startsWith('group:');
      editing = selection === ':new-group' ? '' : grouped ? selection.slice(6) : selection;
      shortcut.value = editing;
      shortcut.readOnly = Boolean(editing);
      shortcut.maxLength = grouped ? 38 : 40;
      shortcut.placeholder = grouped ? 'refund' : 'hello1';
      reply.value = grouped ? '' : macros.get(editing) || '';
      reply.disabled = grouped;
      form.querySelector('[data-single]').hidden = grouped;
      group.hidden = !grouped;
      options.replaceChildren();
      if (grouped) for (const text of groups.get(editing) || ['']) addOption(text);
      updateOptions();
      save.textContent = grouped ? 'Save group' : 'Save macro';
      remove.textContent = grouped ? 'Delete group' : 'Delete macro';
      remove.hidden = !editing;
      status.textContent = '';
    }

    refreshList = (selected = select.value) => {
      const entries = [['New macro', ''], ['New group', ':new-group'],
        ...[...macros.keys()].sort().map(key => [key, key]),
        ...[...groups.keys()].sort().map(key => [key + ' (group)', 'group:' + key])];
      select.replaceChildren(...entries.map(([label, value]) => new Option(label, value)));
      if (entries.some(([, value]) => value === selected)) select.value = selected;
      else if (!busy) loadSelected();
      save.disabled = remove.disabled = busy || !ready;
    };

    function setBusy(value) {
      busy = value;
      select.disabled = shortcut.disabled = value;
      reply.disabled = value || !group.hidden;
      save.disabled = remove.disabled = value || !ready;
      updateOptions();
    }

    function write(key, value) {
      const grouped = !group.hidden;
      const storageKey = (grouped ? groupPrefix : prefix) + key;
      const selection = select.value;
      setBusy(true);
      const done = () => {
        setBusy(false);
        if (chrome.runtime.lastError) {
          status.textContent = 'Could not update macros. Try again.';
          return;
        }
        apply(storageKey, value);
        refreshList(value === undefined ? (grouped ? ':new-group' : '') : grouped ? 'group:' + key : key);
        loadSelected();
        const noun = grouped ? 'Group' : 'Macro';
        status.textContent = noun + (value === undefined ? ' deleted.' : ' saved.');
      };
      try {
        if (value === undefined) chrome.storage.local.remove(storageKey, done);
        else chrome.storage.local.set({ [storageKey]: value }, done);
      } catch (_) {
        setBusy(false);
        refreshList(selection);
        status.textContent = 'Could not update macros. Reload Zendesk and try again.';
      }
    }

    select.addEventListener('change', loadSelected);
    add.addEventListener('click', () => {
      if (options.children.length >= maxOptions) return;
      const field = addOption();
      updateOptions();
      field.focus();
    });
    form.addEventListener('submit', event => {
      event.preventDefault();
      if (busy || !ready) return;
      const key = shortcut.value;
      const grouped = !group.hidden;
      const value = grouped ? [...options.querySelectorAll('textarea')].map(field => field.value) : reply.value;
      if (!validShortcut.test(key) || (grouped ? key.length > 38 || value.some(text => !text.trim()) : !value.trim())) {
        status.textContent = 'Enter reply text and a shortcut using letters, numbers, underscores or hyphens.';
        return;
      }
      if (grouped) {
        const ownAliases = new Set(editing ? aliases(editing, groups.get(editing) || []).map(([name]) => name) : []);
        const conflict = aliases(key, value).find(([name]) => macros.has(name) || builtIns.has(name) ||
          (groupShortcuts.has(name) && !ownAliases.has(name)));
        if (conflict) {
          status.textContent = 'Shortcut already in use: ' + conflict[0] + '.';
          return;
        }
      } else if ((!editing && macros.has(key)) || groupShortcuts.has(key)) {
        status.textContent = 'That shortcut already exists. Select it above to edit its reply.';
        return;
      }
      write(key, value);
    });
    remove.addEventListener('click', () => {
      if (!busy && editing) write(editing, undefined);
    });
    dialog.querySelector('[value="close"]').addEventListener('click', () => dialog.close());
    document.body.append(dialog);
  }

  function open(quickReplies) {
    builtIns = quickReplies;
    if (!dialog) buildDialog();
    if (!dialog.open) {
      refreshList();
      dialog.showModal();
    }
  }

  function shortcutBefore(before, after) {
    if (/^[a-zA-Z0-9_-]/.test(after)) return '';
    return before.match(/(?:^|\s)([a-zA-Z0-9_-]{1,40})$/)?.[1] || '';
  }

  const blocks = 'p, div, li, pre, blockquote, h1, h2, h3, h4, h5, h6';

  function rangeText(range) {
    // Range text skips line breaks. Preserve those boundaries when matching.
    const fragment = range.cloneContents();
    for (const node of fragment.querySelectorAll('br, [contenteditable="false"]')) node.replaceWith('\n');
    for (const node of fragment.querySelectorAll(blocks)) {
      node.prepend('\n');
      node.append('\n');
    }
    return fragment.textContent;
  }

  function selectShortcut(editor, resolveReply) {
    if (editor.tagName === 'TEXTAREA') {
      const { selectionStart: start, selectionEnd: end, value } = editor;
      if (start !== end) return null;
      const key = shortcutBefore(value.slice(0, start), value.slice(end));
      const reply = resolveReply(key);
      if (!reply) return null;
      editor.setSelectionRange(start - key.length, start);
      return { key, reply, restore: () => editor.setSelectionRange(start, start) };
    }

    const selection = document.getSelection();
    if (!selection?.rangeCount || !selection.isCollapsed || !editor.contains(selection.anchorNode)) return null;
    const caret = selection.getRangeAt(0).cloneRange();
    const anchor = selection.anchorNode;
    const element = anchor.nodeType === Node.ELEMENT_NODE ? anchor : anchor.parentElement;
    if (element.closest('[contenteditable="false"]')) return null;
    const block = element.closest(blocks);
    const scope = block && editor.contains(block) ? block : editor;
    const before = document.createRange();
    before.selectNodeContents(scope);
    before.setEnd(caret.startContainer, caret.startOffset);
    const after = document.createRange();
    after.selectNodeContents(scope);
    after.setStart(caret.startContainer, caret.startOffset);

    const key = shortcutBefore(rangeText(before), rangeText(after));
    const reply = resolveReply(key);
    if (!reply) return null;
    const restore = () => {
      selection.removeAllRanges();
      selection.addRange(caret);
    };
    for (let count = 0; count < key.length; count++) selection.modify('extend', 'backward', 'character');
    if (selection.toString() !== key || !editor.contains(selection.focusNode)) {
      restore();
      return null;
    }
    return { key, reply, restore };
  }

  function expand(event, findComposer, quickReplies) {
    if (event.key !== 'Tab' || event.shiftKey || event.altKey || event.ctrlKey || event.metaKey ||
        event.isComposing || event.repeat || event.defaultPrevented) return;
    const focused = document.activeElement;
    if (event.target !== focused ||
        !(focused?.tagName === 'TEXTAREA' || focused?.isContentEditable)) return;
    const editor = findComposer(focused);
    if (editor !== focused) return;
    const match = selectShortcut(editor, key => macros.get(key) || groupShortcuts.get(key) || quickReplies.get(key));
    if (!match) return;
    const { reply } = match;
    let inserted = false;
    try {
      if (editor.isContentEditable) {
        inserted = !editor.dispatchEvent(new CustomEvent('zenx:editor-replace-shortcut', {
          bubbles: true, cancelable: true, detail: { shortcut: match.key, text: reply }
        }));
      }
      if (!inserted && editor.isContentEditable && reply.includes('\n')) {
        // Insert soft breaks without restructuring adjacent formatted text.
        const fragment = document.createElement('div');
        reply.split('\n').forEach((line, index) => {
          if (index) fragment.append(document.createElement('br'));
          fragment.append(line);
        });
        inserted = document.execCommand('insertHTML', false, fragment.innerHTML);
      }
      if (!inserted) inserted = document.execCommand('insertText', false, reply);
    } catch (_) {}
    if (!inserted) {
      match.restore();
      return;
    }
    event.preventDefault();
    event.stopImmediatePropagation();
  }

  globalThis.zenxCustomMacros = {
    open, close: () => dialog?.close(), expand,
    listGroups: () => [...groups.keys()].sort().map(key => [key, { title: key, caption: groups.get(key).length + ' replies', messages: groups.get(key) }])
  };
})();
