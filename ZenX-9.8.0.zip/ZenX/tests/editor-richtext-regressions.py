"""Test model-backed macro writing and deep link styling on offline Zendesk DOM."""
from pathlib import Path
from playwright.sync_api import sync_playwright
import re
ROOT=Path(__file__).resolve().parent.parent
with sync_playwright() as p:
  browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
  page=browser.new_page(viewport={'width':1600,'height':900})
  errors=[]
  page.on('pageerror',lambda e:errors.append(str(e)))
  html=(ROOT/'tests/fixtures/nested.html').read_text()
  html=re.sub(r'<script\b[^>]*>.*?</script>', '', html, flags=re.S|re.I)
  html=re.sub(r'<link\b[^>]*rel="stylesheet"[^>]*>', '', html, flags=re.I)
  page.set_content(html)
  for f in ['tester/mock.css','styles.css','premium.css']:
    page.add_style_tag(content=(ROOT/f).read_text())
  for f in ['tester/mock-shim.js','editor-bridge.js','content.js','themes.js','theme.js','workspace.js','app-frames.js','chrome-glass.js','effects.js']:
    code=(ROOT/f).read_text()
    if f=='tester/mock-shim.js': code=code.replace("new URL('../'+path,location.href).href", "'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVQIHWP4////fwAJ+wP+Y+9J5wAAAABJRU5ErkJggg=='")
    page.add_script_tag(content=code)
  page.wait_for_selector('#zd-floating-sla-timer')
  def send(msg):
    return page.evaluate('m=>new Promise(resolve=>chrome.runtime.__send(m,resolve))',msg)
  # Simulate a CKEditor instance with separate model state and DOM rendering.
  page.evaluate('''() => {
    const old=document.querySelector('[data-test-id="omni-composer-text-input"]');
    const editor=document.createElement('div');
    editor.dataset.testId='omnicomposer-plain-text-ckeditor';
    editor.contentEditable='true';editor.className='ck-editor__editable';
    editor.setAttribute('role','textbox');
    editor.ckeditorInstance={
      setData(html) { window.__managedDraft=html; editor.innerHTML=html; },
      getData() { return window.__managedDraft || ''; }
    };
    window.__managedDraft='';old.replaceWith(editor);
  }''')
  success=send({'type':'INSERT_MACRO','text':'This is a managed editor macro.'})
  assert success['success'],success
  assert 'managed editor macro' in page.evaluate('window.__managedDraft'), 'managed editor data was not updated'
  print('PASS CKEditor model and DOM are both updated')
  # Suppress model-based writing and simulate a framework re-render after native input.
  page.evaluate('''() => {
    const editor=document.querySelector('.ck-editor__editable');
    editor.ckeditorInstance={setData(){throw Error('model not available')},getData(){return window.__managedDraft}};
    editor.addEventListener('input',()=>setTimeout(()=>{editor.innerHTML=window.__managedDraft},25));
  }''')
  failed=send({'type':'INSERT_MACRO','text':'Transient DOM text must never count as inserted.'})
  assert failed['success'] is False, failed
  assert 'Transient DOM' not in page.locator('.ck-editor__editable').inner_text()
  print('PASS transient DOM-only edits do not report successful insertion')
  # Actual HTML anchors/semantic rich text, dark/light and bot bubble.
  page.evaluate('''() => {
    const root=document.querySelector('#mock-messages');
    const msg=document.createElement('article');msg.dataset.testId='omni-log-comment-item';msg.dataset.chatRole='bot';msg.dataset.zenxVa='1';
    msg.innerHTML='<div data-test-id="omni-log-item-message"><div data-test-id="omni-log-message-content">Regular <a href="https://example.org/item">Deep linked text</a> and <strong>Bold text</strong> plus <em>italic text</em>.</div></div>';
    root.appendChild(msg);
  }''')
  def check_styles():
    return page.evaluate('''() => {
      const root=document.querySelector('#mock-messages [data-test-id="omni-log-message-content"]');
      const a=root.querySelector('a'),strong=root.querySelector('strong'),em=root.querySelector('em');
      return {anchorDecoration:getComputedStyle(a).textDecorationLine,anchorWeight:Number(getComputedStyle(a).fontWeight),
        anchorColor:getComputedStyle(a).color,normalColor:getComputedStyle(root).color,
        strongWeight:Number(getComputedStyle(strong).fontWeight),italic:getComputedStyle(em).fontStyle};
    }''')
  for is_dark in [True,False]:
    assert send({'type':'SET_THEME','darkMode':is_dark})['success']
    styles=check_styles()
    assert 'underline' in styles['anchorDecoration'],styles
    assert styles['anchorWeight']>=600,styles
    assert styles['anchorColor']!=styles['normalColor'],styles
    assert styles['strongWeight']>=700,styles
    assert styles['italic']=='italic',styles
    print('PASS %s theme preserves visible linked/bold/italic formatting'%('dark' if is_dark else 'light'))
  assert not errors,errors
  browser.close()
