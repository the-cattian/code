/* Shared 48 × 48 cursor artwork for the studio preview and page effects. */
(() => {
  'use strict';

  const models = {
    arrow: {
      label: 'Arrow',
      hotspot: [6, 5],
      parts: [
        ['primary', 'M6 5 40 29 25 30 18 43 15 31 6 36Z'],
        ['secondary', 'M9 10 31 26 19 27 9 31Z', false]
      ]
    },
    hand: {
      label: 'Pointing Hand',
      hotspot: [17, 4],
      parts: [
        ['primary', 'M17 4Q13 4 13 9V24L10 21C7 18 3 20 4 24L12 37Q14 43 20 44H33Q39 42 41 36L43 24Q44 19 40 18 37 17 35 20 33 15 29 17 27 13 22 16V9Q22 4 17 4Z'],
        ['secondary', 'M16 24V10Q16 7 18 8V25Q20 29 18 36 15 32 12 29 15 30 16 24ZM25 40Q32 40 36 36 33 42 28 42Z', false],
        ['ink', 'M22 17V26M29 18V26M35 21V27']
      ]
    },
    'paw-cat': {
      label: 'Cat Paw',
      parts: [
        ['primary', 'M7 29C7 24 11 23 14 20 17 18 18 16 23 16 30 16 32 21 36 24 43 29 43 36 38 41 33 46 28 39 23 39 18 39 14 45 8 40 4 37 4 32 7 29Z'],
        ['secondary', 'M14 32C14 28 18 27 20 25 23 22 25 24 27 26 29 28 34 29 34 33 33 38 27 34 24 34 20 34 16 38 14 32Z', false],
        ['primary', 'M6 14C4 10 5 6 8 5 11 4 14 7 14 11 14 15 9 19 6 14Z'],
        ['primary', 'M16 10C15 5 17 2 21 2 25 2 27 6 25 11 24 15 18 15 16 10Z'],
        ['primary', 'M28 10C28 5 31 3 35 4 38 5 38 9 36 13 34 17 28 16 28 10Z'],
        ['primary', 'M38 16C38 12 41 10 44 11 47 12 47 16 44 19 41 22 38 20 38 16Z']
      ]
    },
    'paw-dog': {
      label: 'Dog Paw',
      parts: [
        ['primary', 'M7 31C8 27 12 26 15 24 18 21 21 19 24 19 28 19 31 22 33 24 37 27 41 27 42 32 44 39 37 44 30 42 26 41 22 41 18 42 10 45 4 39 7 31Z'],
        ['secondary', 'M12 34C12 30 17 30 20 27 23 25 25 25 29 28 31 31 36 30 36 35 35 40 28 36 24 37 20 36 13 40 12 34Z', false],
        ['primary', 'M8 19C4 19 2 15 3 12 4 9 7 8 10 10 13 12 13 18 8 19Z'],
        ['primary', 'M17 15C13 14 12 9 14 6 16 3 19 4 22 7 25 11 21 16 17 15Z'],
        ['primary', 'M31 15C27 16 23 12 26 8 28 4 32 3 34 6 36 9 35 14 31 15Z'],
        ['primary', 'M40 19C35 18 35 14 38 11 41 8 44 9 45 12 46 15 44 19 40 19Z']
      ]
    },
    'whale-tail': {
      label: 'Whale Tail',
      parts: [
        ['primary', 'M24 19C20 11 14 8 4 8 7 21 13 27 21 27 22 32 19 36 17 39 20 43 28 43 31 39 29 35 26 31 27 27 36 28 42 20 44 8 34 8 28 11 24 19Z'],
        ['secondary', 'M8 11C11 20 17 23 23 24 17 17 14 13 8 11ZM40 11C37 20 31 23 25 24 31 17 34 13 40 11Z', false],
        ['secondary', 'M18 38Q24 40 30 38L31 39Q24 43 17 39Z', false]
      ]
    },
    'shark-fin': {
      label: 'Shark Fin',
      parts: [
        ['primary', 'M9 32C11 22 18 12 30 6 29 19 32 26 37 32L37 36 9 36Z'],
        ['secondary', 'M16 29Q20 19 26 14 26 24 30 30Z', false],
        ['secondary', 'M4 35C8 35 8 32 12 32 16 32 17 35 21 35 25 35 25 32 29 32 33 32 34 35 38 35 41 35 43 33 44 32L44 39C40 43 37 44 32 41 29 39 27 39 24 41 19 44 16 44 12 41 10 39 7 39 4 40Z']
      ]
    },
    fox: {
      label: 'Fox',
      parts: [
        ['primary', 'M6 7 17 13Q24 10 31 13L42 7 39 25Q43 33 35 36L24 44 13 36Q5 33 9 25Z'],
        ['secondary', 'M10 12 16 16 12 23ZM38 12 32 16 36 23Z', false],
        ['secondary', 'M9 27Q14 25 18 30L24 34 30 30Q34 25 39 27 41 33 34 37L24 42 14 37Q6 32 9 27Z', false],
        ['ink', 'M13 25Q16 23 18 25M30 25Q32 23 35 25'],
        ['outline', 'M21 33Q24 31 27 33L24 37Z', false]
      ]
    },
    bunny: {
      label: 'Bunny',
      parts: [
        ['primary', 'M12 22C7 15 8 4 13 3 19 2 22 12 21 19L27 19C26 12 29 2 35 3 40 4 41 15 36 22 41 25 43 30 41 36 39 43 30 45 24 45 16 45 9 42 7 36 5 30 7 26 12 22Z'],
        ['secondary', 'M15 19C12 14 11 7 14 7 17 7 19 14 18 19ZM33 19H30C29 14 31 7 34 7 37 7 36 14 33 19Z', false],
        ['outline', 'M15 31a2 2 0 1 0 4 0 2 2 0 1 0-4 0ZM29 31a2 2 0 1 0 4 0 2 2 0 1 0-4 0Z', false],
        ['secondary', 'M20 34Q24 32 28 34L24 38Z', false],
        ['ink', 'M24 37V39Q21 42 19 39M24 39Q27 42 29 39']
      ]
    },
    bear: {
      label: 'Bear',
      parts: [
        ['primary', 'M6 20C2 16 3 9 8 6 13 3 19 5 20 10Q24 9 28 10C29 5 35 3 40 6 45 9 46 16 42 20 45 24 47 30 44 36 41 42 32 44 24 44 16 44 7 42 4 36 1 30 3 24 6 20Z'],
        ['secondary', 'M8 15Q7 12 10 10 14 8 15 12ZM40 15 33 12Q34 8 38 10 41 12 40 15Z', false],
        ['secondary', 'M14 35C14 30 18 27 24 27 30 27 34 30 34 35 34 40 28 41 24 41 19 41 14 39 14 35Z', false],
        ['outline', 'M12 26a2 2 0 1 0 4 0 2 2 0 1 0-4 0ZM32 26a2 2 0 1 0 4 0 2 2 0 1 0-4 0ZM21 32Q24 30 27 32L24 35Z', false],
        ['ink', 'M24 34V37Q21 40 19 37M24 37Q27 40 29 37']
      ]
    },
    butterfly: {
      label: 'Butterfly',
      parts: [
        ['primary', 'M24 20C19 12 11 4 6 5 1 7 3 18 12 25 4 25 4 34 9 38 15 42 21 34 24 28 27 34 33 42 39 38 44 34 44 25 36 25 45 18 47 7 42 5 37 4 29 12 24 20Z'],
        ['secondary', 'M8 10C11 9 17 14 20 20 15 20 10 16 8 10ZM40 10C37 9 31 14 28 20 33 20 38 16 40 10ZM10 32Q14 27 20 28 17 34 12 35ZM38 32Q34 27 28 28 31 34 36 35Z', false],
        ['outline', 'M22 19Q24 16 26 19L26 31Q24 36 22 31Z', false],
        ['ink', 'M23 20Q22 15 18 11M25 20Q26 15 30 11']
      ]
    },
    frog: {
      label: 'Frog',
      parts: [
        ['primary', 'M5 25C2 19 5 10 12 8 17 7 21 11 22 16H26C27 11 31 7 36 8 43 10 46 19 43 25 46 28 46 35 41 39 37 43 31 43 24 43 17 43 11 43 7 39 2 35 2 28 5 25Z'],
        ['secondary', 'M8 20C8 16 11 13 14 13 18 13 20 17 20 20Q14 23 8 20ZM40 20C40 16 37 13 34 13 30 13 28 17 28 20Q34 23 40 20Z', false],
        ['outline', 'M12 18a2 2 0 1 0 4 0 2 2 0 1 0-4 0ZM32 18a2 2 0 1 0 4 0 2 2 0 1 0-4 0Z', false],
        ['secondary', 'M8 30Q12 26 16 30 12 34 8 30ZM32 30Q36 26 40 30 36 34 32 30Z', false],
        ['ink', 'M16 29Q24 37 32 29']
      ]
    },
    cat: {
      label: 'Cat',
      parts: [
        ['primary', 'M6 6 18 15Q24 13 30 15L42 6 40 22C44 25 45 32 41 37 37 42 31 44 24 44 17 44 11 42 7 37 3 32 4 25 8 22Z'],
        ['secondary', 'M10 12 16 17 11 21ZM38 12 32 17 37 21Z', false],
        ['outline', 'M14 29a2 2 0 1 0 4 0 2 2 0 1 0-4 0ZM30 29a2 2 0 1 0 4 0 2 2 0 1 0-4 0Z', false],
        ['secondary', 'M21 33Q24 31 27 33L24 36Z', false],
        ['ink', 'M24 35V38Q21 40 19 37M24 38Q27 40 29 37M3 30 11 32M4 36 12 35M45 30 37 32M44 36 36 35']
      ]
    },
    otter: {
      label: 'Otter',
      parts: [
        ['primary', 'M6 20Q2 16 5 12 8 8 13 12 18 9 24 9 30 9 35 12 40 8 43 12 46 16 42 20 48 29 42 38 38 43 24 44 10 43 6 38 0 29 6 20Z'],
        ['secondary', 'M9 16Q8 12 11 14L13 16ZM39 16H35L37 14Q40 12 39 16ZM10 34C9 29 14 25 19 25L24 27 29 25C34 25 39 29 38 34 37 40 29 42 24 42 19 42 11 40 10 34Z', false],
        ['outline', 'M13 23a1.5 1.5 0 1 0 3 0 1.5 1.5 0 1 0-3 0ZM32 23a1.5 1.5 0 1 0 3 0 1.5 1.5 0 1 0-3 0ZM19 28Q24 26 29 28 29 31 24 33 19 31 19 28Z', false],
        ['ink', 'M24 32V35Q21 38 18 35M24 35Q27 38 30 35M12 33H13M15 30H16M32 30H33M35 33H36']
      ]
    },
    penguin: {
      label: 'Penguin',
      parts: [
        ['secondary', 'M15 40Q9 44 10 46H22L23 41ZM26 41 27 46H39Q40 44 33 40Z'],
        ['primary', 'M24 3C13 3 9 13 9 21 3 26 1 34 5 37L9 34C10 41 16 44 24 44 32 44 38 41 39 34L43 37C47 34 45 26 39 21 39 13 35 3 24 3Z'],
        ['secondary', 'M24 15C20 8 14 11 13 20 8 31 13 41 24 41 35 41 40 31 35 20 34 11 28 8 24 15Z', false],
        ['outline', 'M15 19a2 2 0 1 0 4 0 2 2 0 1 0-4 0ZM29 19a2 2 0 1 0 4 0 2 2 0 1 0-4 0Z', false],
        ['primary', 'M20 22Q24 21 28 22L24 26Z']
      ]
    },
    axolotl: {
      label: 'Axolotl',
      parts: [
        ['secondary', 'M16 20C9 20 5 17 5 12 9 11 13 13 16 16 12 10 12 6 16 4 20 7 20 12 20 17ZM32 20C39 20 43 17 43 12 39 11 35 13 32 16 36 10 36 6 32 4 28 7 28 12 28 17Z'],
        ['secondary', 'M14 26C7 24 4 26 3 30 5 33 11 32 15 30ZM34 26C41 24 44 26 45 30 43 33 37 32 33 30Z'],
        ['primary', 'M8 26C9 17 16 14 24 14 32 14 39 17 40 26 41 34 34 40 24 40 14 40 7 34 8 26Z'],
        ['secondary', 'M10 30Q13 27 17 30 14 34 10 30ZM38 30Q35 27 31 30 34 34 38 30Z', false],
        ['outline', 'M15 24a2 2 0 1 0 4 0 2 2 0 1 0-4 0ZM29 24a2 2 0 1 0 4 0 2 2 0 1 0-4 0Z', false],
        ['ink', 'M20 29Q24 34 28 29']
      ]
    },
    bee: {
      label: 'Bee',
      parts: [
        ['secondary', 'M22 21C9 22 4 16 7 10 10 5 20 10 25 17 29 10 39 5 42 10 45 17 37 23 25 21Z'],
        ['outline', 'M8 29 3 33 10 35Z', false],
        ['primary', 'M8 30C8 22 16 17 26 17 36 17 42 22 42 29 42 36 35 41 25 41 15 41 8 36 8 30Z'],
        ['outline', 'M16 20Q11 30 17 39L22 40Q16 29 22 18ZM25 18Q20 29 25 41L30 40Q25 29 31 18Z', false],
        ['ink', 'M34 18Q34 12 37 11M38 20Q41 15 44 15M35 33Q37 35 39 32'],
        ['outline', 'M33 27a1.4 1.4 0 1 0 2.8 0 1.4 1.4 0 1 0-2.8 0ZM38 27a1.2 1.2 0 1 0 2.4 0 1.2 1.2 0 1 0-2.4 0Z', false]
      ]
    },
    turtle: {
      label: 'Turtle',
      parts: [
        ['secondary', 'M19 12C17 7 19 3 24 3 29 3 31 7 29 12L27 18H21ZM12 19Q5 14 3 19 4 25 11 27ZM36 19Q43 14 45 19 44 25 37 27ZM14 33Q7 36 10 42 15 43 19 37ZM34 33Q41 36 38 42 33 43 29 37ZM22 37Q20 41 24 45 28 41 26 37Z'],
        ['primary', 'M11 23C11 15 17 11 24 11 31 11 37 15 37 23 37 33 32 39 24 39 16 39 11 33 11 23Z'],
        ['secondary', 'M17 21 24 16 31 21 29 30 24 34 19 30Z'],
        ['ink', 'M13 19 17 21M31 21 35 19M15 32 19 30M29 30 33 32M24 34V38M24 12V16'],
        ['outline', 'M20 8a1.15 1.15 0 1 0 2.3 0 1.15 1.15 0 1 0-2.3 0ZM26 8a1.15 1.15 0 1 0 2.3 0 1.15 1.15 0 1 0-2.3 0Z', false]
      ]
    },
    jellyfish: {
      label: 'Jellyfish',
      parts: [
        ['secondary', 'M11 24H15C20 33 11 36 15 43 10 46 8 39 12 33 14 29 12 28 11 24ZM21 24H25C30 32 22 37 25 44 20 47 18 40 22 33 24 29 22 28 21 24ZM31 24H35C40 33 31 36 35 43 30 46 28 39 32 33 34 29 32 28 31 24Z'],
        ['primary', 'M5 21C5 10 13 4 24 4 35 4 43 10 43 21L43 25Q40 30 35 26 32 31 27 27 23 32 19 27 14 31 11 26 7 29 5 25Z'],
        ['secondary', 'M9 17C11 10 16 7 23 7 18 10 16 13 15 17Z', false],
        ['outline', 'M14 20a1.7 1.7 0 1 0 3.4 0 1.7 1.7 0 1 0-3.4 0ZM31 20a1.7 1.7 0 1 0 3.4 0 1.7 1.7 0 1 0-3.4 0Z', false],
        ['ink', 'M21 22Q24 26 27 22']
      ]
    },
    mushroom: {
      label: 'Mushroom',
      parts: [
        ['secondary', 'M18 23H30L31 35C35 42 29 45 24 45 18 45 13 42 17 35Z'],
        ['primary', 'M5 25C4 22 7 16 10 12 14 7 18 4 24 4 30 4 34 7 38 12 41 16 44 22 43 25 40 31 8 31 5 25Z'],
        ['secondary', 'M15 15a3.4 3.4 0 1 0 6.8 0 3.4 3.4 0 1 0-6.8 0ZM28 13a2.6 2.6 0 1 0 5.2 0 2.6 2.6 0 1 0-5.2 0ZM23 22a3.4 3.4 0 1 0 6.8 0 3.4 3.4 0 1 0-6.8 0ZM34 21a2 2 0 1 0 4 0 2 2 0 1 0-4 0ZM9 23a1.8 1.8 0 1 0 3.6 0 1.8 1.8 0 1 0-3.6 0Z', false],
        ['ink', 'M21 35H21.5M26.5 35H27M22 38Q24 40 26 38']
      ]
    },
    comet: {
      label: 'Comet',
      parts: [
        ['primary', 'M22 10C27 5 35 3 41 8 46 13 45 22 39 28 33 34 20 34 7 44L12 34 4 36 14 26 6 28C11 20 17 14 22 10Z'],
        ['secondary', 'M22 20Q24 11 31 9C36 7 40 10 40 15 42 23 33 30 26 28 22 27 20 24 22 20Z', false],
        ['secondary', 'M10 34Q16 26 21 24L23 28Z', false],
        ['outline', 'M30 14 31.5 17 35 18 32 20 31 23 29.2 20.3 26 19 29 17Z', false],
        ['ink', 'M42 32 45 30M38 37 41 35']
      ]
    },
    heart: {
      label: 'Heart',
      parts: [
        ['primary', 'M24 13C29 4 41 7 44 15 48 26 37 35 24 43 11 35 0 26 4 15 7 7 19 4 24 13Z'],
        ['secondary', 'M10 17Q14 10 20 16 15 15 10 23 8 21 10 17Z', false],
        ['secondary', 'M25 36Q34 29 41 18 42 27 25 36Z', false]
      ]
    },
    star: {
      label: 'Star',
      parts: [
        ['primary', 'M24 3 30 17 45 19 34 29 37 44 24 37 11 44 14 29 3 19 18 17Z'],
        ['secondary', 'M24 9 24 22 10 21 20 19ZM24 22 40 21 31 28 33 38 24 33Z', false]
      ]
    }
  };

  const catalog = Object.entries(models).map(([id, model]) => ({
    id,
    label: model.label,
    hotspot: model.hotspot,
    parts: model.parts.map(([fill, path, border = true]) => ({ fill, path: new Path2D(path), border }))
  }));
  const byId = new Map(catalog.map(model => [model.id, model]));
  const lookup = id => byId.get(id) || byId.get('arrow');

  function hotspot(shape) {
    const [x, y] = lookup(shape).hotspot || [24, 24];
    return { x: x / 48, y: y / 48 };
  }

  function draw(ctx, shape, size, primary, secondary, outline, strokeWidth = 2) {
    if (!(size > 0)) return;
    const colors = { primary, secondary, outline };
    ctx.save();
    ctx.scale(size / 48, size / 48);
    ctx.lineJoin = 'round';
    ctx.lineCap = 'round';
    ctx.strokeStyle = outline;
    for (const { fill, path, border } of lookup(shape).parts) {
      if (fill !== 'ink') {
        ctx.fillStyle = colors[fill];
        ctx.fill(path);
      }
      if (border && (strokeWidth > 0 || fill === 'ink')) {
        ctx.lineWidth = fill === 'ink' ? Math.max(1.1, strokeWidth * .73) : strokeWidth;
        ctx.stroke(path);
      }
    }
    ctx.restore();
  }

  globalThis.PetalArt = { shapes: catalog.map(({ id, label }) => ({ id, label })), draw, hotspot };
})();
