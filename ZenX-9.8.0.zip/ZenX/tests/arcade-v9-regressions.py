#!/usr/bin/env python3
"""Offline gameplay tests for ZenX v9.0; uses a local, non-Zendesk mock."""
import asyncio
from pathlib import Path
from playwright.async_api import async_playwright
ROOT=Path(__file__).resolve().parents[1]
HTML='''<!doctype html><html class="zskin-active"><head><style>
*{box-sizing:border-box}body{margin:0;background:#1b242d;color:#fff;font-family:Arial}
.top{height:40px;background:#111} .row{display:flex;height:calc(100vh - 40px)}
nav{width:52px;background:#111}aside{width:570px;padding:24px 20px;border-right:1px solid #555}
aside h2{margin:0 0 30px;font-size:18px}aside p{margin:6px 0 28px}aside h4{color:#aeb8c1;font-size:12px}
main{flex:1;padding:32px}.card{height:100%;padding:32px;display:grid;place-content:center;text-align:center}
</style></head><body><div class="top"></div><div class="row"><nav></nav><aside><h2>Home</h2><h4>Your work</h4><p>Tickets</p><h4>Shared work</h4><p>CC'd</p><p>Following</p><h4>Completed work</h4><p>Last 30 days</p></aside><main><div class="card"><strong>No tickets</strong><p>Work you're assigned will appear here.</p></div></main></div></body></html>'''
async def main():
    results=[]; errors=[]
    async with async_playwright() as p:
        browser=await p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
        page=await browser.new_page(viewport={'width':1792,'height':861})
        page.on('pageerror',lambda e: errors.append(str(e)))
        await page.set_content(HTML)
        await page.add_script_tag(content=(ROOT/'tester/mock-shim.js').read_text())
        await page.evaluate('''(css)=>chrome.runtime.getURL=(path)=>'data:text/css,'+encodeURIComponent(css)''',(ROOT/'arcade.css').read_text())
        source=(ROOT/'arcade.js').read_text().replace('location.pathname','(window.__zenxTestLocationPath || location.pathname)')
        source=source.replace('  schedule();\n})();', '''  window.__arcadeGameTest = {
            getFall:()=>fall, updateFall, spawnWord,
            getTyping:()=>typing, updateTyping,
            getFlappy:()=>flappy, updateFlappy,
            getBounce:()=>bounce, updateBounce,
            getState:()=>state, getGame:()=>game,
            getScore:()=>score, setElapsed:(seconds)=>{if(fall)fall.elapsed=seconds;}
        };
        schedule();
})();''')
        await page.evaluate("window.__zenxTestLocationPath='/agent/home/tickets'")
        await page.add_script_tag(content=source)
        await page.wait_for_timeout(420)
        shadow=page.locator('#zenx-arcade-root')
        await shadow.wait_for(state='attached')
        async def check(label,call):
            try:
                result=await call()
                print('PASS',label,result)
                results.append((label,True))
            except Exception as exc:
                print('FAIL',label,str(exc))
                results.append((label,False))

        async def wordfall():
            await shadow.locator('#next').click() # Snake
            await shadow.locator('#next').click() # Falling words
            assert (await shadow.locator('#mode-title').inner_text())=='Falling Words'
            box=await shadow.bounding_box()
            assert box['height']>=460,box
            assert box['y']+box['height']<=861,box
            await shadow.locator('#start').click()
            field=shadow.locator('#fall-input')
            await page.evaluate('window.__arcadeGameTest.spawnWord()')
            word=await page.evaluate('window.__arcadeGameTest.getFall().words[0].text')
            await field.fill(word.swapcase())
            assert len(await page.evaluate('window.__arcadeGameTest.getFall().words'))>=1,'Wrong capitalization destroyed word'
            await field.fill(word)
            assert await shadow.locator('#score').inner_text()!='0'
            await page.evaluate('window.__arcadeGameTest.getFall().elapsed=59.6; window.__arcadeGameTest.updateFall(0.6)')
            assert 'LEVEL 2' in await shadow.locator('#game-meta').inner_text() or await page.evaluate('window.__arcadeGameTest.getFall().level')==2
            await page.evaluate('''() => {
              const g=window.__arcadeGameTest.getFall();
              g.words=[{id:91,x:10,y:295,text:'Hello'},{id:92,x:210,y:295,text:'Bye'},{id:93,x:400,y:295,text:'World'}];
              g.lives=3;g.spawn=9999;
              window.__arcadeGameTest.updateFall(0.8);
            }''')
            assert await page.evaluate('window.__arcadeGameTest.getState()')=='over'
            assert await shadow.locator('#last').inner_text()!='0'
            return f'taller panel, exact case, live level 2, 3-miss limit, high/last score; example {word}'
        await check('Falling Words mechanics',wordfall)

        async def typing():
            await shadow.locator('#next').click()
            assert (await shadow.locator('#mode-title').inner_text())=='Typing Test'
            assert (await shadow.bounding_box())['height']>=460
            await shadow.locator('#test-duration').select_option('2')
            assert await shadow.locator('#typing-clock').inner_text()=='02:00'
            await shadow.locator('#test-duration').select_option('1')
            await shadow.locator('#start').click()
            phrase=await shadow.locator('#typing-prompt').inner_text()
            wrong=phrase[:1].swapcase() if phrase[0].isalpha() else '~'
            await shadow.locator('#typing-input').fill(wrong)
            assert await shadow.locator('#typing-prompt .incorrect').count()>0
            await shadow.locator('#typing-input').fill(phrase)
            assert await page.evaluate('window.__arcadeGameTest.getTyping().passages')==1
            await page.evaluate('window.__arcadeGameTest.getTyping().elapsed=59.5; window.__arcadeGameTest.updateTyping(0.5)')
            assert await page.evaluate('window.__arcadeGameTest.getState()')=='over'
            assert 'WPM' in await shadow.locator('#last').inner_text()
            await shadow.locator('#test-duration').select_option('5')
            assert await shadow.locator('#typing-clock').inner_text()=='05:00'
            assert await shadow.locator('#score').inner_text()=='0 WPM'
            return {'duration_choices':[1,2,5],'first_sentence':phrase,'finished_run':True}
        await check('Typing Test capitalization, timer and WPM',typing)

        async def flappy():
            await shadow.locator('#next').click()
            assert await shadow.locator('#mode-title').inner_text()=='Flappy Bird'
            await shadow.locator('#start').click()
            await shadow.locator('#screen').focus()
            await page.keyboard.press('Space')
            assert await page.evaluate('window.__arcadeGameTest.getFlappy().velocity')<0
            await page.evaluate('''() => {
              const f=window.__arcadeGameTest.getFlappy();
              f.pipes=[{x:0,gapTop:50,gap:170,scored:false}];f.birdY=135;
              window.__arcadeGameTest.updateFlappy(.02);
            }''')
            assert await shadow.locator('#score').inner_text()=='1'
            await page.evaluate('window.__arcadeGameTest.getFlappy().birdY=280; window.__arcadeGameTest.updateFlappy(.02)')
            assert await page.evaluate('window.__arcadeGameTest.getState()')=='over'
            return 'Flap keyboard, pipe pass scores, ground collision ends run'
        await check('Flappy Bird mechanics',flappy)

        async def bounce():
            await shadow.locator('#next').click()
            assert await shadow.locator('#mode-title').inner_text()=='Bounce Ball'
            assert await shadow.locator('#touch-controls').is_visible()
            await shadow.locator('#start').click()
            await shadow.locator('#screen').focus()
            x0=await page.evaluate('window.__arcadeGameTest.getBounce().x')
            await page.keyboard.down('ArrowRight')
            await page.wait_for_timeout(120)
            await page.keyboard.up('ArrowRight')
            x1=await page.evaluate('window.__arcadeGameTest.getBounce().x')
            assert x1>x0,(x0,x1)
            await page.evaluate('''() => {
               const b=window.__arcadeGameTest.getBounce();
               b.rings=5;b.ringsList=[{x:b.x,y:b.y,taken:false}];
               window.__arcadeGameTest.updateBounce(.01);
            }''')
            assert await shadow.locator('#score').inner_text()=='25'
            assert await page.evaluate('window.__arcadeGameTest.getBounce().level')==2
            await page.evaluate('''() => {
              const b=window.__arcadeGameTest.getBounce();b.y=375;b.lives=1;b.invulnerable=0;
              window.__arcadeGameTest.updateBounce(.01);
            }''')
            assert await page.evaluate('window.__arcadeGameTest.getState()')=='over'
            return 'Arrow movement, ring pickup increases level, falling ends final life'
        await check('Bounce Ball mechanics',bounce)

        async def persistence():
            await page.wait_for_timeout(200)
            values=await page.evaluate('''new Promise(resolve=>chrome.storage.local.get(Object.fromEntries(['zenx_games_wordfall_best','zenx_games_wordfall_last','zenx_games_typing_1_last','zenx_games_flappy_best','zenx_games_bounce_best','zenx_games_typing_duration'].map(k=>[k,null])),resolve))''')
            for k in ['zenx_games_wordfall_best','zenx_games_wordfall_last','zenx_games_typing_1_last','zenx_games_flappy_best','zenx_games_bounce_best']:
                assert k in values,(k,list(values))
            assert values['zenx_games_typing_duration']==5
            await shadow.locator('#next').click()
            assert await shadow.locator('#mode-title').inner_text()=='Dinosaur'
            await shadow.locator('#previous').click()
            assert await shadow.locator('#mode-title').inner_text()=='Bounce Ball'
            return 'All new score keys saved; six-game navigation wraps'
        await check('Score persistence and navigation',persistence)
        assert not errors,errors
        await shadow.locator('#previous').click() # Flappy
        await shadow.locator('#previous').click() # Typing
        await shadow.locator('#previous').click() # Wordfall
        await shadow.locator('#start').click()
        await page.wait_for_timeout(800)
        await page.screenshot(path='/mnt/data/zenx_v9_falling_words_preview.png')
        await shadow.locator('#next').click() # Typing
        await shadow.locator('#start').click()
        await page.screenshot(path='/mnt/data/zenx_v9_typing_preview.png')
        print('SUMMARY',sum(ok for _,ok in results),'/',len(results))
        await browser.close()
        if not all(ok for _,ok in results):raise SystemExit(1)

if __name__=='__main__':asyncio.run(main())
