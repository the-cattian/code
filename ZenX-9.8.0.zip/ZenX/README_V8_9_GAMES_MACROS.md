# ZenX v8.9 — Arcade, Quick Replies, and Timer Fixes

## Pill quick replies
Click the **⚡ macro icon** in the floating ZenX pill. If the pill is collapsed, hover to expand it first. Choose **Hold**, **Empathy**, **Apology**, or **Denied**; each category has four distinct customer-support message drafts. Selecting a message inserts it in Zendesk’s reply composer but **does not click Send**. Review and adjust the message for the actual case and company policy before sending. If direct insertion cannot be verified, the existing clipboard fallback remains available. The menu includes **Turn off macros**; opening the icon again offers **Enable macros**. Existing timed Hold suggestions remain available when macros are on.

## Games
The resizable arcade appears only on the Zendesk Home screen when the native ticket list explicitly says **No tickets**. Its separate game on/off control remains in the extension popup. **Snake** wraps across all four board edges and ends only after hitting its own body. **Dinosaur** now uses refined custom pixel-art sprites, animated flying pterodactyls (after the score begins increasing), and cacti, with distinct running/ducking collision boxes. Each game keeps its own last run and high score in Chrome local storage.

## Correct active ticket and tab timer
The floating pill prioritizes the visible Zendesk ticket header over stale workspace-tab attributes. The active top-tab countdown synchronizes on a new agent-message or SLA cycle and then runs from a real deadline rather than repeatedly recalculating from a stale “just now” timestamp. Manual reset of the top-tab timer remains separate from the pill.

## Per-tab settings
Use **Enable on this tab** in the ZenX popup to disable the entire extension for just the current browser tab without changing other tabs. The global ZenX toggle and Game toggle continue to work separately.

## Installation
Extract the ZIP into a folder, replacing your previous ZenX extension files. Visit **chrome://extensions** → **Reload** ZenX, then refresh Zendesk. If replacing the unpacked-extension folder under the same path, the existing local scores and settings persist.

## Validation
Tested in a local browser mock using automated regression tests: quick reply menu, draft insertion and no auto-send; current ticket versus stale workspace ID; independent top-tab countdown; Snake boundary wrap; Home, ticket, arcade, per-tab, and macro compatibility. **Not tested in a live Zendesk account.**
