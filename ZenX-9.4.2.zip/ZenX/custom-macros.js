(() => {
  'use strict';

  const prefix = 'zenx_custom_macro:';
  const validShortcut = /^[a-zA-Z0-9_-]{1,40}$/;
  const macros = new Map();
  let dialog;
  let refreshList;
  let ready = false;

  function apply(key, value) {
    if (!key.startsWith(prefix)) return;
    const shortcut = key.slice(prefix.length);
    if (validShortcut.test(shortcut) && typeof value === 'string' && value.trim()) {
      macros.set(shortcut, value);
    } else {
      macros.delete(shortcut);
    }
  }

  chrome.storage.local.get(null, items => {
    if (chrome.runtime.lastError) return;
    for (const [key, value] of Object.entries(items)) apply(key, value);
    ready = true;
    refreshList?.();
  });

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== 'local') return;
    const entries = Object.entries(changes).filter(([key]) => key.startsWith(prefix));
    for (const [key, change] of entries) apply(key, change.newValue);
    if (entries.length) refreshList?.();
  });

  function buildDialog() {
    dialog = document.createElement('dialog');
    dialog.id = 'zenx-custom-macros';
    dialog.setAttribute('aria-labelledby', 'zenx-custom-macros-title');
    dialog.innerHTML = `
      <header>
        <h2 id="zenx-custom-macros-title">Custom Macros</h2>
        <button type="button" value="close">Close</button>
      </header>
      <p>Type a saved shortcut like <code>hello1</code> in the reply box and press Tab.</p>
      <label>Saved macros
        <select><option value="">New macro</option></select>
      </label>
      <form>
        <label>Shortcut
          <input name="shortcut" placeholder="hello1" maxlength="40" required>
        </label>
        <label>Reply text
          <textarea name="reply" rows="5" maxlength="4000" required></textarea>
        </label>
        <footer>
          <button type="submit">Save macro</button>
          <button type="button" value="delete" hidden>Delete macro</button>
        </footer>
      </form>
      <p role="status"></p>
    `;

    const select = dialog.querySelector('select');
    const form = dialog.querySelector('form');
    const shortcut = form.elements.shortcut;
    const reply = form.elements.reply;
    const save = form.querySelector('[type="submit"]');
    const remove = form.querySelector('[value="delete"]');
    const status = dialog.querySelector('[role="status"]');
    let busy = false;
    let editing = '';

    function loadSelected() {
      editing = select.value;
      shortcut.value = editing;
      shortcut.readOnly = Boolean(editing);
      reply.value = macros.get(editing) || '';
      remove.hidden = !editing;
      status.textContent = '';
    }

    refreshList = () => {
      select.replaceChildren(new Option('New macro', ''), ...[...macros.keys()].sort().map(key => new Option(key, key)));
      if (macros.has(editing)) select.value = editing;
      else if (editing && !busy) loadSelected();
      save.disabled = remove.disabled = busy || !ready;
    };

    function setBusy(value) {
      busy = value;
      select.disabled = shortcut.disabled = reply.disabled = value;
      save.disabled = remove.disabled = value || !ready;
    }

    function write(key, value) {
      setBusy(true);
      const done = () => {
        setBusy(false);
        if (chrome.runtime.lastError) {
          status.textContent = 'Could not update macros. Try again.';
          return;
        }
        apply(prefix + key, value);
        refreshList();
        select.value = value === undefined ? '' : key;
        loadSelected();
        status.textContent = value === undefined ? 'Macro deleted.' : 'Macro saved.';
      };
      try {
        if (value === undefined) chrome.storage.local.remove(prefix + key, done);
        else chrome.storage.local.set({ [prefix + key]: value }, done);
      } catch (_) {
        setBusy(false);
        status.textContent = 'Could not update macros. Reload Zendesk and try again.';
      }
    }

    select.addEventListener('change', loadSelected);
    form.addEventListener('submit', event => {
      event.preventDefault();
      if (busy || !ready) return;
      const key = shortcut.value;
      if (!validShortcut.test(key) || !reply.value.trim()) {
        status.textContent = 'Enter reply text and a shortcut using letters, numbers, underscores or hyphens.';
        return;
      }
      if (!editing && macros.has(key)) {
        status.textContent = 'That shortcut already exists. Select it above to edit its reply.';
        return;
      }
      write(key, reply.value);
    });
    remove.addEventListener('click', () => {
      if (!busy && editing) write(editing, undefined);
    });
    dialog.querySelector('[value="close"]').addEventListener('click', () => dialog.close());
    document.body.append(dialog);
  }

  function open() {
    if (!dialog) buildDialog();
    if (!dialog.open) {
      refreshList();
      dialog.showModal();
    }
  }

  function shortcutBefore(before, after) {
    if (/^[a-zA-Z0-9_-]/.test(after)) return '';
    return before.match(/(?:^|\s)([a-zA-Z0-9_-]{1,40})$/)?.[1] || '';
  }

  const blocks = 'p, div, li, pre, blockquote, h1, h2, h3, h4, h5, h6';

  function rangeText(range) {
    // Range text skips line breaks. Preserve those boundaries when matching.
    const fragment = range.cloneContents();
    for (const node of fragment.querySelectorAll('br, [contenteditable="false"]')) node.replaceWith('\n');
    for (const node of fragment.querySelectorAll(blocks)) {
      node.prepend('\n');
      node.append('\n');
    }
    return fragment.textContent;
  }

  function selectShortcut(editor, resolveReply) {
    if (editor.tagName === 'TEXTAREA') {
      const { selectionStart: start, selectionEnd: end, value } = editor;
      if (start !== end) return null;
      const key = shortcutBefore(value.slice(0, start), value.slice(end));
      const reply = resolveReply(key);
      if (!reply) return null;
      editor.setSelectionRange(start - key.length, start);
      return { key, reply, restore: () => editor.setSelectionRange(start, start) };
    }

    const selection = document.getSelection();
    if (!selection?.rangeCount || !selection.isCollapsed || !editor.contains(selection.anchorNode)) return null;
    const caret = selection.getRangeAt(0).cloneRange();
    const anchor = selection.anchorNode;
    const element = anchor.nodeType === Node.ELEMENT_NODE ? anchor : anchor.parentElement;
    if (element.closest('[contenteditable="false"]')) return null;
    const block = element.closest(blocks);
    const scope = block && editor.contains(block) ? block : editor;
    const before = document.createRange();
    before.selectNodeContents(scope);
    before.setEnd(caret.startContainer, caret.startOffset);
    const after = document.createRange();
    after.selectNodeContents(scope);
    after.setStart(caret.startContainer, caret.startOffset);

    const key = shortcutBefore(rangeText(before), rangeText(after));
    const reply = resolveReply(key);
    if (!reply) return null;
    const restore = () => {
      selection.removeAllRanges();
      selection.addRange(caret);
    };
    for (let count = 0; count < key.length; count++) selection.modify('extend', 'backward', 'character');
    if (selection.toString() !== key || !editor.contains(selection.focusNode)) {
      restore();
      return null;
    }
    return { key, reply, restore };
  }

  function expand(event, findComposer, quickReplies) {
    if (event.key !== 'Tab' || event.shiftKey || event.altKey || event.ctrlKey || event.metaKey ||
        event.isComposing || event.repeat || event.defaultPrevented) return;
    const focused = document.activeElement;
    if (event.target !== focused ||
        !(focused?.tagName === 'TEXTAREA' || focused?.isContentEditable)) return;
    const editor = findComposer(focused);
    if (editor !== focused) return;
    const match = selectShortcut(editor, key => macros.get(key) || quickReplies.get(key));
    if (!match) return;
    const { reply } = match;
    let inserted = false;
    try {
      if (editor.isContentEditable) {
        inserted = !editor.dispatchEvent(new CustomEvent('zenx:editor-replace-shortcut', {
          bubbles: true, cancelable: true, detail: { shortcut: match.key, text: reply }
        }));
      }
      if (!inserted && editor.isContentEditable && reply.includes('\n')) {
        // Insert soft breaks without restructuring adjacent formatted text.
        const fragment = document.createElement('div');
        reply.split('\n').forEach((line, index) => {
          if (index) fragment.append(document.createElement('br'));
          fragment.append(line);
        });
        inserted = document.execCommand('insertHTML', false, fragment.innerHTML);
      }
      if (!inserted) inserted = document.execCommand('insertText', false, reply);
    } catch (_) {}
    if (!inserted) {
      match.restore();
      return;
    }
    event.preventDefault();
    event.stopImmediatePropagation();
  }

  globalThis.zenxCustomMacros = { open, close: () => dialog?.close(), expand };
})();
