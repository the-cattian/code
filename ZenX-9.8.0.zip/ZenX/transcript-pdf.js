(() => {
  'use strict';

  const pageWidth = 595;
  const pageHeight = 842;
  const margin = 43;
  const textWidth = pageWidth - margin * 2;
  const contentBottom = pageHeight - 58;
  const scale = 2;
  const lineHeight = 16;
  const encoder = new TextEncoder();
  const graphemes = new Intl.Segmenter(undefined, { granularity: 'grapheme' });

  function* wrapText(context, text) {
    const measure = value => context.measureText(value).width;
    for (const paragraph of text.replace(/\r\n?|\u2028|\u2029/g, '\n').replace(/\t/g, '    ').split('\n')) {
      let line = '';
      for (const token of paragraph.match(/\s+|\S+/gu) || []) {
        if (measure(line + token) <= textWidth) {
          line += token;
          continue;
        }
        if (line.trimEnd()) yield line.trimEnd();
        line = '';
        if (/^\s/u.test(token)) continue;

        // Long URLs and scripts without inter-word spaces still need to wrap.
        for (const { segment } of graphemes.segment(token)) {
          if (line && measure(line + segment) > textWidth) {
            yield line;
            line = '';
          }
          line += segment;
        }
      }
      yield line.trimEnd();
    }
  }

  function pdfUnicode(text) {
    let hex = 'FEFF';
    for (let i = 0; i < text.length; i++) hex += text.charCodeAt(i).toString(16).padStart(4, '0');
    return hex;
  }

  function textLayer(line, x, y, size, width) {
    const glyphCount = [...line].length;
    // The invisible Helvetica glyphs define selection bounds. ActualText holds
    // the Unicode line independently of the PDF viewer's installed fonts.
    const scalePercent = (width * 100 / (glyphCount * size * .667)).toFixed(3);
    return `/Span << /ActualText <${pdfUnicode(line)}> >> BDC\nBT /F1 ${size} Tf 3 Tr ${scalePercent} Tz 1 0 0 1 ${x} ${pageHeight - y} Tm (${'X'.repeat(glyphCount)}) Tj ET\nEMC\n`;
  }

  function pdfDocument(pages) {
    const parts = [];
    const offsets = [0];
    let byteLength = 0;
    const append = chunk => {
      const bytes = typeof chunk === 'string' ? encoder.encode(chunk) : chunk;
      byteLength += bytes.size ?? bytes.byteLength;
      parts.push(bytes);
    };
    function object(id, ...chunks) {
      offsets[id] = byteLength;
      append(id + ' 0 obj\n');
      for (const chunk of chunks) append(chunk);
      append('\nendobj\n');
    }
    append('%PDF-1.7\n');
    append(new Uint8Array([37, 226, 227, 207, 211, 10]));
    object(1, '<< /Type /Catalog /Pages 2 0 R >>');
    const children = pages.map((_, index) => (4 + index * 3) + ' 0 R');
    object(2, `<< /Type /Pages /Count ${pages.length} /Kids [${children.join(' ')}] >>`);
    object(3, '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>');

    for (const [index, page] of pages.entries()) {
      const pageId = 4 + index * 3;
      const imageId = pageId + 1;
      const streamId = pageId + 2;
      object(pageId, `<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ${pageWidth} ${pageHeight}] /Resources << /XObject << /Im0 ${imageId} 0 R >> /Font << /F1 3 0 R >> >> /Contents ${streamId} 0 R >>`);
      object(imageId, `<< /Type /XObject /Subtype /Image /Width ${pageWidth * scale} /Height ${pageHeight * scale} /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /FlateDecode /Length ${page.image.size} >>\nstream\n`,
        page.image, '\nendstream');
      const content = encoder.encode(`q ${pageWidth} 0 0 ${pageHeight} 0 0 cm /Im0 Do Q\n` + page.text.join(''));
      object(streamId, `<< /Length ${content.byteLength} >>\nstream\n`, content, 'endstream');
    }
    const start = byteLength;
    append(`xref\n0 ${offsets.length}\n0000000000 65535 f \n`);
    for (const offset of offsets.slice(1)) append(String(offset).padStart(10, '0') + ' 00000 n \n');
    append(`trailer\n<< /Size ${offsets.length} /Root 1 0 R >>\nstartxref\n${start}\n%%EOF\n`);
    return new Blob(parts, { type: 'application/pdf' });
  }

  async function create({ ticketId, messages }) {
    if (!ticketId || !Array.isArray(messages) || !messages.length) throw new Error('No chat messages to export.');
    const canvas = document.createElement('canvas');
    canvas.width = pageWidth * scale;
    canvas.height = pageHeight * scale;
    const context = canvas.getContext('2d', { alpha: false, willReadFrequently: true });
    if (!context) throw new Error('Could not create the transcript PDF.');
    context.scale(scale, scale);
    const pages = [];
    let text = [];
    let y = 0;

    function font(size, weight = 'normal') {
      context.font = weight + ' ' + size + 'px system-ui, sans-serif';
    }

    function draw(line, x, baseline, size, color) {
      if (!line) return;
      context.fillStyle = color;
      context.fillText(line, x, baseline);
      const width = context.measureText(line).width;
      if (width > 0) text.push(textLayer(line, x, baseline, size, width));
    }

    function rule(baseline) {
      context.fillStyle = '#d9e0e6';
      context.fillRect(margin, baseline, textWidth, 1);
    }

    function beginPage() {
      text = [];
      context.fillStyle = '#fff';
      context.fillRect(0, 0, pageWidth, pageHeight);
      font(23, 'bold');
      draw('Chat transcript', margin, 65, 23, '#142b3e');
      font(12, 'bold');
      draw('Ticket #' + ticketId, margin, 85, 12, '#315d75');
      rule(103);
      y = 127;
    }

    async function finishPage() {
      rule(pageHeight - 43);
      font(9);
      draw('Page ' + (pages.length + 1), margin, pageHeight - 27, 9, '#405260');
      // Store lossless page pixels so small lettering and fallback glyphs
      // stay crisp. Compress once in the browser without uploading content.
      const { width, height } = canvas;
      const rgba = context.getImageData(0, 0, width, height).data;
      const rgb = new Uint8Array(width * height * 3);
      for (let source = 0, target = 0; source < rgba.length; source += 4, target += 3) {
        rgb[target] = rgba[source];
        rgb[target + 1] = rgba[source + 1];
        rgb[target + 2] = rgba[source + 2];
      }
      const compressed = new Blob([rgb]).stream().pipeThrough(new CompressionStream('deflate'));
      const image = await new Response(compressed).blob();
      pages.push({ image, text });
    }

    beginPage();
    for (const message of messages) {
      const sender = message.sender || 'Participant';
      const label = [sender, message.timestamp].filter(Boolean).join(' · ');
      font(10, 'bold');
      const heading = [...wrapText(context, label)];
      const headingHeight = heading.length * 14;
      if (y + headingHeight + lineHeight > contentBottom && y > 127) {
        await finishPage();
        beginPage();
        font(10, 'bold');
      }
      for (const line of heading) {
        if (y > contentBottom) {
          await finishPage();
          beginPage();
          font(10, 'bold');
        }
        draw(line, margin, y, 10, '#315d75');
        y += 14;
      }
      font(11);
      for (const line of wrapText(context, message.text || '')) {
        if (y > contentBottom) {
          await finishPage();
          beginPage();
          font(11);
        }
        draw(line, margin, y, 11, '#16242f');
        y += lineHeight;
      }
      y += 12;
    }
    await finishPage();
    return pdfDocument(pages);
  }

  globalThis.ZenXTranscriptPdf = { create };
})();
