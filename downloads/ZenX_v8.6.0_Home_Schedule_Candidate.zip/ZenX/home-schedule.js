/* Home-only schedule. Discover the current app URL through Zendesk's native
 * launcher; never persist account URLs or construct an app GUID. */
(() => {
  'use strict';
  let host, pending = false, deadline = 0, attempted = false, stopped = false;
  let enabled = true;
  const html = document.documentElement;
  const launcher = () => document.querySelector('button[data-test-id="top-bar-app-view"][data-app-title="Assembled"]');
  function active() {
    return enabled && html.classList.contains('zskin-active') && html.classList.contains('zenx-premium') &&
      /^\/agent\/(home|dashboard)(\/|$)/.test(location.pathname);
  }
  function launch() {
    const button = launcher();
    if (!button || pending) return;
    // Do not close a dialog the user already opened.
    if (button.getAttribute('aria-expanded') === 'true' || document.querySelector('[aria-modal="true"]')) return;
    pending = true; deadline = Date.now() + 10000;
    button.click();
  }
  function cleanup() {
    if (pending) {
      const pane = document.querySelector('[data-test-id="top-bar-app-pane-app-element-container"][data-app-title="Assembled"]');
      pane?.closest('[role="dialog"]')?.querySelector('button[aria-label="Close"]')?.click();
    }
    pending = false; attempted = false;
    host?.remove(); host = null;
    html.classList.remove('zenx-home-schedule');
  }
  function update() {
    if (stopped) return;
    if (!active()) { cleanup(); return; }
    const main = document.querySelector('[data-test-id="nah-container"]');
    if (!main) { cleanup(); return; }
    if (!host?.isConnected) {
      host = document.createElement('aside'); host.id = 'zenx-home-schedule';
      host.setAttribute('aria-label', 'Assembled schedule');
      const heading = document.createElement('h2'); heading.textContent = 'Today’s schedule';
      const note = document.createElement('p'); note.textContent = 'Loading Assembled…';
      const retry = document.createElement('button'); retry.type = 'button'; retry.textContent = 'Load schedule';
      retry.addEventListener('click', launch);
      host.append(heading, note, retry); main.append(host);
    }
    html.classList.add('zenx-home-schedule');
    if (!attempted && launcher() && !document.querySelector('[aria-modal="true"]')) { attempted = true; launch(); }
    if (!pending) return;
    const pane = document.querySelector('[data-test-id="top-bar-app-pane-app-element-container"][data-app-title="Assembled"]');
    const source = pane?.querySelector('iframe');
    const dialog = pane?.closest('[role="dialog"]');
    const close = dialog?.querySelector('button[aria-label="Close"]');
    if (source && close) {
      let url;
      try { url = new URL(source.src); } catch { return; }
      if (url.origin !== 'https://app.assembledhq.com') return;
      const frame = document.createElement('iframe');
      frame.title = 'Assembled — today’s schedule';
      // Preserve the app's security restrictions and live session URL.
      for (const name of ['sandbox', 'allow', 'referrerpolicy']) {
        if (source.hasAttribute(name)) frame.setAttribute(name, source.getAttribute(name));
      }
      frame.src = url.href;
      pending = false;
      close.click(); // releases Zendesk's modal focus trap before embedding
      host.querySelector('iframe')?.remove();
      host.querySelector('p')?.remove();
      host.querySelector('button').textContent = 'Reload schedule';
      host.append(frame);
    } else if (Date.now() > deadline) {
      pending = false;
      let note = host.querySelector('p');
      if (!note) { note = document.createElement('p'); host.append(note); }
      note.textContent = 'Use Load schedule to retry, or open Assembled from the toolbar.';
      dialog?.querySelector('button[aria-label="Close"]')?.click();
    }
  }
  chrome.storage.local.get({zenx_enabled:true}, v => { enabled = v.zenx_enabled !== false; update(); });
  chrome.storage.onChanged.addListener((c, area) => { if (area === 'local' && c.zenx_enabled) { enabled = c.zenx_enabled.newValue !== false; update(); } });
  const timer = setInterval(update, 500);
  window.addEventListener('pagehide', () => { stopped = true; clearInterval(timer); cleanup(); }, {once:true});
})();
