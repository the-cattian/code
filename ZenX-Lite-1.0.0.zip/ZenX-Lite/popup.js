'use strict';

const controls = [
  ['zenx_clicks_enabled', document.querySelector('#click-effects')],
  ['zenx_games_enabled', document.querySelector('#home-arcade')]
];
const status = document.querySelector('#status');

chrome.storage.local.get({ zenx_clicks_enabled: true, zenx_games_enabled: true }, values => {
  if (chrome.runtime.lastError) {
    status.textContent = 'Could not load settings. Reopen the popup to try again.';
    return;
  }
  for (const [key, input] of controls) {
    input.checked = values[key] !== false;
    input.disabled = false;
    input.addEventListener('change', () => {
      const checked = input.checked;
      input.disabled = true;
      chrome.storage.local.set({ [key]: checked }, () => {
        input.disabled = false;
        if (chrome.runtime.lastError) {
          input.checked = !checked;
          status.textContent = 'Could not save the setting.';
        } else {
          status.textContent = '';
        }
      });
    });
  }
});
