# ZenX v8.4.1 — Macro and Rich-Text fixes

This is a targeted update to ZenX v8.4.0. Other theme, timer, SLA, panel, and macro suggestion logic is retained.

## Changes

- **Macro insertion:** Composer detection still prioritizes Zendesk's native reply field, but uses a separate MAIN-world editor adapter when a CKEditor instance is accessible, keeping the editor's internal draft in sync with what it displays. Native text-input events remain the fallback. The extension checks again after a brief stabilization period and will not show a green success message for text that gets immediately discarded by a managed editor.
- **Macro fallback:** Clicking a suggestion also attempts to copy it to your clipboard as a backup. If ZenX cannot verify the text in the reply draft, the popup says so and reports whether clipboard backup succeeded. Nothing is sent automatically.
- **Deeplink/format styling:** Actual HTML hyperlinks inside Zendesk conversation messages and rich-text replies now get a visible underline and contrasting color. Bold, italic and underline semantics are preserved in dark and light modes.
- **Popup messaging:** Extension-to-content-script INSERT_MACRO replies now wait for the asynchronous insertion check instead of returning an immediate, unreliable result.

## Modified files

- `content.js` — reliable composer insertion and asynchronous status feedback
- `editor-bridge.js` — new main-world editor adapter (no network requests)
- `manifest.json` — registers the adapter and version 8.4.1
- `styles.css` — message and composer rich-text visibility
- `tester/mock-shim.js`, `tester/mock.html`, `tests/timer-macro-regressions.py` — adapt offline regression harness
- `tests/editor-richtext-regressions.py` — managed-editor and formatting regression tests

## Verification

Passed in the included offline browser simulator:
- Existing countdown and ticket scenarios
- Macro insertion into both contenteditable and textarea composers
- Timer macro option click without sending
- CKEditor-style model update, including rejecting a DOM-only false success
- Visible hyperlinks, bold and italic formatting in dark and light modes
- Existing SLA/ticket parity checks (`node tests/verify-parity.mjs`)

**Limitation:** Zendesk's live editor was not accessible in this environment. Test on an open Zendesk ticket before relying on this in a production workflow. Different Zendesk rollout variants may expose different editor APIs.

## Install/update

1. Unzip the archive.
2. Open `chrome://extensions` and enable **Developer mode**.
3. Remove or disable an older duplicate ZenX installation if necessary.
4. Use **Load unpacked** and select the extracted `ZenX` folder; or press **Reload** for an already installed extension pointing to that folder.
5. Refresh the Zendesk tab, open a reply, click a timer macro and verify it appears and remains in the draft. Do not send during the initial test.
