'use strict';

const settings = [
  ['zenx_clicks_enabled', '#click-effects', true],
  ['zenx_click_style', '#click-style', 'sparkle'],
  ['zenx_cursor_style', '#cursor-style', 'aqua'],
  ['zenx_games_enabled', '#home-arcade', true]
];
const defaults = Object.fromEntries(settings.map(([key, , value]) => [key, value]));
const status = document.querySelector('#status');

chrome.storage.local.get(defaults, values => {
  if (chrome.runtime.lastError) {
    status.textContent = 'Could not load settings. Reopen the popup to try again.';
    return;
  }
  for (const [key, selector, fallback] of settings) {
    const field = document.querySelector(selector);
    const property = field.type === 'checkbox' ? 'checked' : 'value';
    field[property] = values[key] ?? fallback;
    if (field.value === '') field[property] = fallback;
    let saved = field[property];
    field.disabled = false;
    field.addEventListener('change', () => {
      const value = field[property];
      field.disabled = true;
      chrome.storage.local.set({ [key]: value }, () => {
        field.disabled = false;
        if (chrome.runtime.lastError) {
          field[property] = saved;
          status.textContent = 'Could not save the setting.';
        } else {
          saved = value;
          status.textContent = '';
        }
      });
    });
  }
});
