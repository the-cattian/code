/* Petal Pop Home Arcade (six independent mini-games, progressive difficulty).
 * Independent Shadow DOM UI; never edits or moves Zendesk elements.
 * Strictly visible on the native Home empty-ticket state.
 */
(() => {
  'use strict';
  if (window.__zenxLiteArcadeLoaded) return;
  window.__zenxLiteArcadeLoaded = true;

  const STORAGE = {
    enabled: 'zenx_games_enabled',
    layout: 'zenx_games_layout',
    mode: 'zenx_games_mode',
    dinoBest: 'zenx_games_dino_best',
    dinoLast: 'zenx_games_dino_last',
    snakeBest: 'zenx_games_snake_best',
    snakeLast: 'zenx_games_snake_last',
    wordfallBest: 'zenx_games_wordfall_best',
    wordfallLast: 'zenx_games_wordfall_last',
    flappyBest: 'zenx_games_flappy_best',
    flappyLast: 'zenx_games_flappy_last',
    bounceBest: 'zenx_games_bounce_best',
    bounceLast: 'zenx_games_bounce_last',
    typingDuration: 'zenx_games_typing_duration'
  };
  const MODES=['dino','snake','wordfall','typing','flappy','bounce'];
  const NAMES={dino:'Dinosaur',snake:'Snake',wordfall:'Falling Words',typing:'Typing Test',flappy:'Flappy Bird',bounce:'Bounce Ball'};
  const TYPING_TIMES=[1,2,5];
  for(const minutes of TYPING_TIMES){
    STORAGE[`typing${minutes}Best`]=`zenx_games_typing_${minutes}_best`;
    STORAGE[`typing${minutes}Last`]=`zenx_games_typing_${minutes}_last`;
  }
  const defaultStorage = {
    [STORAGE.enabled]: true,
    [STORAGE.layout]: null,
    [STORAGE.mode]: 'dino',
    [STORAGE.dinoBest]: 0,
    [STORAGE.dinoLast]: 0,
    [STORAGE.snakeBest]: 0,
    [STORAGE.snakeLast]: 0,
    [STORAGE.wordfallBest]: 0, [STORAGE.wordfallLast]: 0,
    [STORAGE.flappyBest]: 0, [STORAGE.flappyLast]: 0,
    [STORAGE.bounceBest]: 0, [STORAGE.bounceLast]: 0,
    [STORAGE.typingDuration]: 1
  };
  for(const minutes of TYPING_TIMES){
    defaultStorage[STORAGE[`typing${minutes}Best`]]=0;
    defaultStorage[STORAGE[`typing${minutes}Last`]]=0;
  }
  const W = 720, H = 300;
  const root = document.documentElement;
  let gamesEnabled = false, disposed = false;
  let host = null, shadow = null, refs = {}, frame = 0, lastFrameTime = 0;
  let game = 'dino', state = 'ready', score = 0;
  let stats = Object.fromEntries(MODES.map(name=>[name,{best:0,last:0}]));
  let typingScores={1:{best:0,last:0},2:{best:0,last:0},5:{best:0,last:0}};
  let duration=1;
  let savedLayout = null, layoutChanged = false;
  let statusTimer = 0, scoreSaveTimer = 0, pointerAction = null;
  let dino = null, snake = null, fall = null, typing = null, flappy = null, bounce = null, statusPoll = 0;
  // Natural dictionary words: no random alternating-case text or artificial CamelCase.
  // Proper nouns and short expressions are intentionally capitalized.
  const COMMON_WORDS = ('answer patient caring helpful honest polite comfortable important ' +
    'please thanks welcome update waiting review account concern understand check ' +
    'details explain quickly balance focus bright quiet faster practice improve ' +
    'correct response question message support company mobile keyboard ' +
    'window computer garden flower river forest morning evening sunshine ' +
    'weather season orange banana apple kitten coffee travel family friend ' +
    'genuine simple careful friendly useful surprising thoughtful ' +
    'confidence service journey challenge progress attention amazing ' +
    'arrive deliver discuss urgent ordinary happy peaceful gentle ' +
    'thoughtful arrival luggage yesterday tomorrow today happy').split(/\s+/);
  const PROPER_WORDS = ['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday',
    'January','February','March','April','August','October','November','December',
    'London','Lahore','Pakistan','Canada','Python','Chrome','Zendesk','Maria','Sophie'];
  const EXPRESSIONS = ['Hello!','Really?','Why?','Thanks!','Great!','Ready?','Certainly.','Please!'];
  const ACRONYMS = ['WPM','SLA','USA','FAQ','VIP'];
  const PHRASES = [
    'Please review Ticket #245 before 5:30 PM today.',
    'A calm response can make a difficult moment easier.',
    'On Monday, Maria emailed three updates to the team.',
    'I appreciate your patience while I check the details.',
    'The Quick Brown Fox? Not quite: this one runs at 8:15.',
    'We opened the window, and the rainy street looked bright.',
    'Accuracy matters: read carefully, then type with confidence.',
    'Before leaving, Daniel counted 12 blue folders.',
    'Keep moving forward; progress often begins with small steps.',
    'A clear explanation helps customers understand the next step.',
    'During lunch, Sophie ordered tea, coffee, and fresh fruit.',
    'Check the date: November 19, 2026, is a Thursday.',
    'Great work! You have finished the first challenge.',
    'Would you mind waiting another 3-5 minutes for an update?',
    'My keyboard has letters, numbers (1-9), and symbols.',
    'Small improvements add up, especially when you practice daily.',
    'Charlotte asked, "Where did the package go?"',
    'At 7:45 AM, the train arrived near the old bridge.',
    'A friendly message should be specific, honest, and helpful.',
    'Tonight, the stars shimmer over quiet green hills.',
    'Practice makes typing faster, but precision comes first.',
    'Your account information remains private and secure.',
    'The colorful kite soared above the city on Saturday.',
    'Take time to proofread names, dates, and punctuation.'
  ];

  const clamp = (x, a, b) => Math.min(Math.max(x,a),b);
  const isHome = () => /^\/agent\/(?:home|dashboard)(?:\/|$)/.test(location.pathname) ||
    (/^\/agent\/?$/.test(location.pathname) && !!findText(/^Last 30 days$/i) && !!findText(/^Home$/i));
  const active = () => gamesEnabled && isHome();
  const storageSet = (values) => {
    try { chrome.storage.local.set(values); } catch (_) {}
  };
  // Zendesk registers global shortcuts at document capture. While a game input
  // owns focus, intercept the composed event at WINDOW CAPTURE (earlier in
  // the propagation path), without preventDefault: a '?' must still be typed.
  // This never runs for Zendesk's own editors, search or other page controls.
  function captureArcadeKeys(event){
    if(!host||!shadow||!active())return;
    const target=shadow.activeElement;
    if(!target)return;
    const textGame=(game==='wordfall'&&target===refs['fall-input']) ||
      (game==='typing'&&target===refs['typing-input']);
    if(textGame && state==='running'){
      // Keep these two game-only hotkeys working because propagation is stopped
      // before Zendesk's document listeners can see the keyboard event.
      if(event.type==='keydown' && event.key==='Escape'){
        event.preventDefault();pause();target.blur();
      } else if(event.type==='keydown' && game==='wordfall' && event.key==='Enter'){
        event.preventDefault();target.value='';target.dataset.invalid='false';draw();
      }
      event.stopImmediatePropagation();
    }
  }
  for(const name of ['keydown','keyup','keypress'])
    window.addEventListener(name,captureArcadeKeys,true);

  const isVisible = el => {
    if (!el || !el.isConnected || el.closest('[hidden],[aria-hidden="true"],[inert]')) return false;
    const css = getComputedStyle(el);
    return css.display !== 'none' && css.visibility !== 'hidden' && !!el.getClientRects().length;
  };

  // A text-node match does not mistake container textContent for an empty state.
  // Also never interprets the game panel's Shadow DOM as Zendesk content.
  function findText(pattern, within = document.body) {
    if (!within) return null;
    const walker = document.createTreeWalker(within, NodeFilter.SHOW_TEXT);
    let n, checked = 0;
    while ((n = walker.nextNode()) && checked++ < 16000) {
      if (pattern.test((n.nodeValue || '').trim())) {
        const el = n.parentElement;
        if (el && !el.closest('#zenx-lite-arcade-root') && isVisible(el)) return el;
      }
    }
    return null;
  }
  function findEmptyMessage() {
    // Restrict the check to the Home screen; don't use an absent ticket-table
    // as proof of emptiness while Zendesk is still fetching ticket data.
    const scope = document.querySelector('[data-test-id="agent-home"], [data-test-id="home-page"], [data-test-id="home-page-content"], main, [role="main"]') || document.body;
    return findText(/^(?:No tickets|No assigned tickets|You have no tickets|No tickets found)$/i, scope) ||
      (scope !== document.body ? findText(/^(?:No tickets|No assigned tickets|You have no tickets)$/i) : null);
  }
  function findZone(emptyNode) {
    // Anchor below the actual left-column label, not to a guessed ancestor.
    // Zendesk's Home layout gives the left nav a tall sibling column, whereas
    // the "Last 30 days" row itself can be inside a short (under 300px) list.
    const last = findText(/^Last 30 days$/i) || findText(/^Completed work$/i);
    if (!last || !emptyNode) return null;
    const label = last.getBoundingClientRect();
    const empty = emptyNode.getBoundingClientRect();
    if (label.width < 1 || empty.width < 1) return null;
    let rightEdge = innerWidth * 0.348;
    // Find the start of the ticket content pane from native ancestors of the
    // visible "No tickets" message, so the game stays in the blank left area.
    // Do not use Zendesk class hashes; they rotate between deployments.
    const boundaries=[];
    for(let node=emptyNode.parentElement,depth=0;node&&depth<16;node=node.parentElement,depth++){
      const r=node.getBoundingClientRect();
      if(r.width>350 && r.height>250 && r.left>label.left+290 &&
         r.left<empty.left && r.left<innerWidth*.8) boundaries.push(r.left);
    }
    if(boundaries.length)rightEdge=Math.min(...boundaries);
    const left=Math.max(12,Math.round(label.left+3));
    const top=Math.round(label.bottom+27);
    const width=Math.min(500, Math.floor(rightEdge-left-25), Math.floor(innerWidth-left-20));
    const height=Math.min(425,Math.floor(innerHeight-top-24));
    if(width<320||height<286)return null;
    return {left,top,width,height,maxWidth:width};
  }

  function saveLayout() {
    if (!host) return;
    savedLayout = {
      left:Math.round(parseFloat(host.style.left)), top:Math.round(parseFloat(host.style.top)),
      width:Math.round(host.offsetWidth), height:Math.round(host.offsetHeight)
    };
    layoutChanged = true;
    storageSet({[STORAGE.layout]:savedLayout});
  }
  function setGeometry(box) {
    if (!host) return;
    host.style.left = `${box.left}px`;
    host.style.top = `${box.top}px`;
    host.style.width = `${box.width}px`;
    host.style.height = `${box.height}px`;
  }
  function position(zone) {
    if (!host || pointerAction) return;
    const maxW = Math.max(320, innerWidth - 18);
    const maxH = Math.max(286, innerHeight - 18);
    const custom = savedLayout && layoutChanged;
    const width = clamp(custom ? savedLayout.width : zone.width,320,maxW);
    const tall = game==='wordfall'||game==='typing';
    // Typing games need substantially more vertical reading space. On small
    // screens the panel moves upwards rather than spilling out of the viewport.
    const minTall=Math.min(Math.max(zone.height+35,Math.min(560,innerHeight-zone.top-12)),maxH);
    const height = clamp(Math.max(custom ? savedLayout.height : zone.height,tall ? minTall : 286),286,maxH);
    const left = clamp(custom ? savedLayout.left : zone.left,5,Math.max(5,innerWidth-width-5));
    const proposedTop=custom ? savedLayout.top : zone.top;
    const top = clamp(proposedTop,5,Math.max(5,innerHeight-height-5));
    setGeometry({left,top,width,height});
  }
  function bindPointerDrag(node, resize) {
    node.addEventListener('pointerdown', e => {
      if (e.button !== 0 || (e.target.closest('button') && !resize) || !host) return;
      e.preventDefault();
      const start = {x:e.clientX, y:e.clientY,
        left:parseFloat(host.style.left),top:parseFloat(host.style.top),
        width:host.offsetWidth,height:host.offsetHeight};
      pointerAction = {resize,start};
      node.setPointerCapture(e.pointerId);
      if (!resize) node.classList.add('dragging');
    });
    node.addEventListener('pointermove', e => {
      if (!pointerAction || pointerAction.resize !== resize) return;
      const {start} = pointerAction, dx=e.clientX-start.x, dy=e.clientY-start.y;
      if (resize) {
        host.style.width = `${clamp(start.width+dx,320,Math.max(320,innerWidth-start.left-6))}px`;
        host.style.height = `${clamp(start.height+dy,286,Math.max(286,innerHeight-start.top-6))}px`;
      } else {
        host.style.left = `${clamp(start.left+dx,5,Math.max(5,innerWidth-start.width-5))}px`;
        host.style.top = `${clamp(start.top+dy,5,Math.max(5,innerHeight-start.height-5))}px`;
      }
    });
    const end = () => {
      if (!pointerAction || pointerAction.resize !== resize) return;
      pointerAction = null;
      node.classList.remove('dragging');
      saveLayout();
      draw();
    };
    node.addEventListener('pointerup',end);
    node.addEventListener('pointercancel',end);
    node.addEventListener('lostpointercapture',end);
  }

  function markup() {
    return `<section id="arcade-shell" aria-label="Petal Pop Home Arcade">
      <header id="drag-handle" title="Drag to move arcade">
        <span class="arcade-icon" aria-hidden="true">▦</span>
        <div class="heading"><strong>PETAL POP ARCADE</strong><small>No tickets? Time for a break.</small></div>
        <div class="top-actions"><button id="power-off" class="icon-button" type="button" title="Turn games off (can be re-enabled in the Petal Pop popup)" aria-label="Turn games off">⏻</button></div>
      </header>
      <div class="game-switcher"><div class="nav-group">
        <button id="previous" class="arrow" type="button" aria-label="Previous game">‹</button>
        <span id="mode-title" class="mode-title">Dinosaur</span>
        <button id="next" class="arrow" type="button" aria-label="Next game">›</button>
      </div><span id="game-meta" class="mini-hint">6 games</span></div>
      <div class="stats">
        <div class="stat"><small>Score</small><strong id="score">0</strong></div>
        <div class="stat best"><small>High score</small><strong id="best">0</strong></div>
        <div class="stat"><small>Last run</small><strong id="last">0</strong></div>
      </div>
      <div id="game-stage" class="stage"><canvas id="screen" width="720" height="300" tabindex="0" aria-label="Arcade game. Select Start then use keyboard." role="application"></canvas>
        <div id="fall-entry" class="fall-entry" hidden><label for="fall-input">TYPE TO DESTROY</label><input id="fall-input" type="text" maxlength="24" spellcheck="false" autocomplete="off" autocapitalize="off" placeholder="Match a falling word exactly" aria-label="Type the falling word with exact capitalization"/><span id="fall-lives" aria-live="polite">3 lives</span></div>
        <div id="typing-interface" class="typing-interface" hidden><div class="typing-overview"><span id="typing-clock">01:00</span><span id="typing-accuracy">Accuracy 100%</span><span id="typing-typed">0 characters</span></div><div id="typing-prompt" class="typing-prompt" aria-label="Text to type"></div><label class="typing-entry-label" for="typing-input">Type the passage exactly, including capitalization and punctuation.</label><textarea id="typing-input" spellcheck="false" autocapitalize="off" autocomplete="off" aria-label="Typing test response" placeholder="Click Start, then type here."></textarea></div>
        <div id="overlay" class="overlay"><strong id="overlay-title">Ready to play?</strong><span id="overlay-subtitle">Select Start to play</span></div>
      </div>
      <div class="game-actions"><div class="left-actions"><button class="primary" id="start" type="button">Start</button><button class="secondary" id="restart" type="button">Restart</button><label id="duration-label" class="duration-label" hidden>Duration <select id="test-duration" aria-label="Typing test duration"><option value="1">1 min</option><option value="2">2 min</option><option value="5">5 min</option></select></label></div><span id="keyboard-tip" class="keyboard-tip">Space / ↑ Jump · ↓ Duck</span></div>
      <div id="touch-controls" class="touch-controls"><button id="ctrl-left" type="button" aria-label="Snake left">←</button><button id="ctrl-up" type="button" aria-label="Snake up">↑</button><button id="ctrl-down" type="button" aria-label="Snake down">↓</button><button id="ctrl-right" type="button" aria-label="Snake right">→</button></div>
      <div id="resize-grip" title="Drag to resize" aria-label="Drag to resize arcade"><svg viewBox="0 0 14 14" fill="none" stroke="currentColor" stroke-width="1.6"><path d="M13 3L3 13M13 8L8 13"/></svg></div>
    </section>`;
  }
  function makePanel(zone) {
    if (host) {position(zone);return;}
    host = document.createElement('div');
    host.id = 'zenx-lite-arcade-root';
    host.setAttribute('aria-label', 'Petal Pop Home Arcade');
    shadow = host.attachShadow({mode:'open'});
    const css = document.createElement('link');
    css.rel = 'stylesheet';
    css.href = chrome.runtime.getURL('arcade.css');
    shadow.append(css);
    const wrapper = document.createElement('div');
    wrapper.innerHTML = markup();
    shadow.append(wrapper.firstElementChild);
    refs = Object.fromEntries(['drag-handle','power-off','previous','next','mode-title','game-meta','score','best','last',
      'screen','game-stage','overlay','overlay-title','overlay-subtitle','start','restart','keyboard-tip','touch-controls',
      'ctrl-left','ctrl-up','ctrl-down','ctrl-right','resize-grip','fall-entry','fall-input','fall-lives',
      'typing-interface','typing-clock','typing-accuracy','typing-typed','typing-prompt','typing-input',
      'duration-label','test-duration'].map(id=>[id,shadow.getElementById(id)]));
    document.body.append(host);
    // Commands forwarded by the document_start shortcut guard.
    host.addEventListener('zenx-lite-arcade-command',event=>{
      if(state!=='running')return;
      if(event.detail==='pause') {pause();shadow.activeElement?.blur();}
      if(event.detail==='clear'&&game==='wordfall'){
        refs['fall-input'].value='';refs['fall-input'].dataset.invalid='false';draw();
      }
    });
    lastZone=zone;
    position(zone);
    bindPointerDrag(refs['drag-handle'],false);
    bindPointerDrag(refs['resize-grip'],true);
    refs['power-off'].addEventListener('click', () => storageSet({[STORAGE.enabled]:false}));
    refs.previous.addEventListener('click', () => switchMode(-1));
    refs.next.addEventListener('click', () => switchMode(1));
    refs.start.addEventListener('click', () => {
      if(state === 'running') pause(); else if(state==='paused') resume(); else begin();
      focusGame();
    });
    refs.restart.addEventListener('click', () => {begin();focusGame();});
    refs.screen.addEventListener('keydown', keydown);
    refs.screen.addEventListener('keyup', e => {
      if (e.code === 'ArrowDown' || e.code === 'KeyS') {if(dino)dino.duck=false;e.preventDefault();}
      if(game==='bounce'){
        if(['ArrowLeft','KeyA'].includes(e.code))setBounceKey('left',false);
        if(['ArrowRight','KeyD'].includes(e.code))setBounceKey('right',false);
      }
    });
    refs.screen.addEventListener('pointerdown', e => {
      if(e.button !== 0) return;
      refs.screen.focus({preventScroll:true});
      if(game==='dino') {if(state==='ready'||state==='over')begin();jump();}
      else if(game==='flappy') {if(state==='ready'||state==='over')begin();flap();}
      else if(game==='bounce') {if(state==='ready'||state==='over')begin();bounceJump();}
    });
    for (const [direction,id] of [['left','ctrl-left'],['up','ctrl-up'],['down','ctrl-down'],['right','ctrl-right']]) {
      refs[id].addEventListener('click',()=>{
        if(game==='snake') {if(state==='ready'||state==='over')begin();setDirection(direction);}
        else if(game==='bounce') {if(state==='ready'||state==='over')begin();if(direction==='up')bounceJump();else bounceNudge(direction);}
        else if(direction==='up') {if(state==='ready'||state==='over')begin();if(game==='flappy')flap();else jump();}
        focusGame();
      });
    }
    for(const direction of ['left','up','right']){
      const node=refs[`ctrl-${direction}`];
      node.addEventListener('pointerdown',()=>{if(game==='bounce')setBounceKey(direction,true);});
      for(const kind of ['pointerup','pointercancel','pointerleave'])node.addEventListener(kind,()=>setBounceKey(direction,false));
    }
    refs['fall-input'].addEventListener('input',typeFallingWord);
    refs['fall-input'].addEventListener('keydown',e=>{
      if(e.key==='Enter'){e.preventDefault();e.stopPropagation();e.currentTarget.value='';e.currentTarget.dataset.invalid='false';draw();}
    });
    refs['typing-input'].addEventListener('input',typeTest);
    for(const node of [refs['fall-input'],refs['typing-input']]){
      node.addEventListener('keydown', e=>{e.stopPropagation();if(e.key==='Escape'&&state==='running'){pause();node.blur();}});
      node.addEventListener('keyup', e=>e.stopPropagation());
    }
    refs['test-duration'].addEventListener('change',()=>{
      if(game!=='typing')return;
      if(state==='running'||state==='paused'||state==='over')recordRun();
      cancelAnimationFrame(frame);frame=0;state='ready';score=0;
      duration=TYPING_TIMES.includes(Number(refs['test-duration'].value))?Number(refs['test-duration'].value):1;
      storageSet({[STORAGE.typingDuration]:duration});typing=null;
      refreshMode();
    });
    refreshMode();
  }
  function removePanel() {
    if (!host) return;
    if (state==='running' || state==='paused') recordRun();
    cancelAnimationFrame(frame);frame=0;lastFrameTime=0;
    host.remove();host=null;shadow=null;refs={};pointerAction=null;
    state='ready';score=0;dino=null;snake=null;fall=null;typing=null;flappy=null;bounce=null;
  }
  function selectedStats() {return game==='typing'?typingScores[duration]:stats[game];}
  function focusGame() {
    const node=game==='wordfall'?refs['fall-input']:game==='typing'?refs['typing-input']:refs.screen;
    node?.focus({preventScroll:true});
  }
  function refreshMode() {
    if (!host) return;
    refs['mode-title'].textContent=NAMES[game];
    const tips={dino:'Space / ↑ Jump · ↓ Duck',snake:'Arrow keys / WASD to turn',wordfall:'Real words · exact case · Enter clears errors',
      typing:'Case, spaces and punctuation count',flappy:'Space / ↑ / click to flap',bounce:'← → Move · Space / ↑ Boost'};
    refs['keyboard-tip'].textContent=tips[game];
    refs['touch-controls'].hidden=!['snake','bounce'].includes(game);
    refs['ctrl-down'].hidden=game==='bounce';
    refs['game-stage'].dataset.mode=game;
    refs['fall-entry'].hidden=game!=='wordfall';
    refs['typing-interface'].hidden=game!=='typing';
    refs.screen.hidden=game==='typing';
    refs['duration-label'].hidden=game!=='typing';
    refs['test-duration'].value=String(duration);
    refs['fall-input'].value='';refs['typing-input'].value='';
    position(lastZone || {left:Math.round(parseFloat(host.style.left)||70),top:350,width:host.offsetWidth||450,height:420});
    refreshStats();refreshStatus();refreshMeta();draw();
  }
  function refreshMeta() {
    if(!host)return;
    if(game==='wordfall'){
      const level=fall?fall.level:2;
      refs['game-meta'].textContent=`LEVEL ${level} · ${fall?fall.lives:3} ♥ · ${Math.round(fallRate(fall?.elapsed||0))} WPM`;
      refs['fall-lives'].textContent=`${fall?fall.lives:3} lives`;
    }else if(game==='typing'){
      const left=typing?Math.max(0,Math.ceil(duration*60-typing.elapsed)):duration*60;
      const fmt=n=>`${String(Math.floor(n/60)).padStart(2,'0')}:${String(n%60).padStart(2,'0')}`;
      refs['game-meta'].textContent=`${duration} MIN TEST`;
      refs['typing-clock'].textContent=fmt(left);
      const accuracy=typing&&typing.keystrokes?Math.round(100*(typing.keystrokes-typing.errors)/typing.keystrokes):100;
      refs['typing-accuracy'].textContent=`Accuracy ${accuracy}%`;
      refs['typing-typed'].textContent=`${typing?typing.typedTotal+refs['typing-input'].value.length:0} characters`;
    }else if(game==='flappy')refs['game-meta'].textContent='FLAP · PASS PIPES';
    else if(game==='bounce')refs['game-meta'].textContent=`LEVEL ${bounce?bounce.level:1} · ${bounce?bounce.stageRings:0}/${bounce?.ringsList.length||6} HOOPS`;
    else refs['game-meta'].textContent='6 GAMES';
  }
  function refreshStats() {
    if (!host) return;
    const values=selectedStats();
    refs.score.textContent=String(score);
    refs.best.textContent=String(values.best);
    refs.last.textContent=String(values.last);
    const units=game==='typing'?' WPM':'';
    for(const id of ['score','best','last'])refs[id].textContent+=units;
  }
  function refreshStatus() {
    if (!host) return;
    refs.overlay.hidden=state==='running';
    const intros={
      dino:'Avoid faster cacti and flying pterodactyls',
      snake:'Eat food, wrap around edges, avoid your tail',
      wordfall:'Type falling words precisely; 3 misses end the run',
      typing:`A ${duration}-minute test. Match all capital letters and punctuation.`,
      flappy:'Tap / Space to flap between the pipes',
      bounce:'Collect every hoop to unlock the exit; avoid moving traps'
    };
    const data=state==='ready'?['Ready to play?',intros[game]]:
      state==='paused'?['Paused','Select Resume to continue']:
      state==='over'?[game==='typing'?'Test complete!':'Game over',game==='typing'?`You typed at ${score} WPM`:`You scored ${score} points · Try again`]:['',''];
    refs['overlay-title'].textContent=data[0];
    refs['overlay-subtitle'].textContent=data[1];
    refs.start.textContent=state==='running'?'Pause':state==='paused'?'Resume':state==='over'?'Try again':'Start';
  }
  function recordRun() {
    if (!state || state==='ready'||(game==='typing'&&state!=='over'))return;
    const values=selectedStats();
    values.last=score;
    if(score>values.best)values.best=score;
    saveScores();
  }
  function saveScores() {
    clearTimeout(scoreSaveTimer);scoreSaveTimer=0;
    const values={};
    for(const name of ['dino','snake','wordfall','flappy','bounce']){
      values[STORAGE[name+'Best']]=stats[name].best;
      values[STORAGE[name+'Last']]=stats[name].last;
    }
    for(const minutes of TYPING_TIMES){
      values[STORAGE[`typing${minutes}Best`]]=typingScores[minutes].best;
      values[STORAGE[`typing${minutes}Last`]]=typingScores[minutes].last;
    }
    storageSet(values);
  }
  function scoreChanged(value) {
    if(value===score)return;
    score=Math.max(0,value);
    const values=selectedStats();
    if(game!=='typing' && score>values.best){values.best=score;if(!scoreSaveTimer)scoreSaveTimer=setTimeout(saveScores,1800);}
    refreshStats();
  }
  let lastZone=null;
  function switchMode(delta=1) {
    if(state==='running'||state==='paused'||state==='over')recordRun();
    cancelAnimationFrame(frame);frame=0;
    game=MODES[(MODES.indexOf(game)+delta+MODES.length)%MODES.length];
    storageSet({[STORAGE.mode]:game});
    state='ready';score=0;dino=null;snake=null;fall=null;typing=null;flappy=null;bounce=null;lastFrameTime=0;
    refreshMode();
  }
  function resetDino() {
    dino = {y:0,vel:0,duck:false,obstacles:[],spawn:1.1,distance:0,flight:0,elapsed:0,
      clouds:[{x:128,y:48},{x:430,y:70},{x:650,y:38}]};
  }
  function resetSnake() {
    snake = {cells:[{x:14,y:7},{x:13,y:7},{x:12,y:7}], dir:'right',next:'right',food:null,elapsed:0,alive:0};
    placeFood();
  }
  function begin() {
    if(state==='running'||state==='paused')recordRun();
    cancelAnimationFrame(frame);frame=0;score=0;state='running';lastFrameTime=0;
    if(game==='dino')resetDino();
    else if(game==='snake')resetSnake();
    else if(game==='wordfall')resetFall();
    else if(game==='typing')resetTyping();
    else if(game==='flappy')resetFlappy();
    else if(game==='bounce')resetBounce();
    refreshStats();refreshStatus();refreshMeta();draw();
    focusGame();frame=requestAnimationFrame(loop);
  }
  function pause() {
    if(state!=='running')return;
    state='paused';cancelAnimationFrame(frame);frame=0;lastFrameTime=0;
    if(dino)dino.duck=false;
    if(bounce)bounce.keys={};
    refreshStatus();draw();
  }
  function resume() {
    if(state!=='paused')return;
    state='running';lastFrameTime=0;refreshStatus();frame=requestAnimationFrame(loop);
  }
  function finish() {
    if(state!=='running')return;
    state='over';cancelAnimationFrame(frame);frame=0;
    recordRun();refreshStats();refreshStatus();refreshMeta();draw();
  }
  function jump() {
    if(game==='dino'&&state==='running'&&dino && dino.y===0) {
      dino.vel = 700; dino.duck=false;
    }
  }
  function keydown(e) {
    if (!host || e.altKey || e.ctrlKey || e.metaKey) return;
    const k=e.code;
    if(game==='dino' && (k==='Space'||k==='ArrowUp'||k==='KeyW')) {
      e.preventDefault();if(state==='ready'||state==='over')begin();else if(state==='paused')resume();jump();
    } else if(game==='dino' && (k==='ArrowDown'||k==='KeyS')) {
      e.preventDefault();if(dino)dino.duck=true;
    } else if(game==='snake' && /^Arrow(Up|Down|Left|Right)$/.test(k) ||
      game==='snake' && /^(KeyW|KeyA|KeyS|KeyD)$/.test(k)) {
      e.preventDefault();
      if(state==='ready'||state==='over')begin();
      const direction={ArrowUp:'up',ArrowDown:'down',ArrowLeft:'left',ArrowRight:'right',KeyW:'up',KeyS:'down',KeyA:'left',KeyD:'right'}[k];
      setDirection(direction);
    } else if(game==='flappy' && ['Space','ArrowUp','KeyW'].includes(k)){
      e.preventDefault();if(state==='ready'||state==='over')begin();else if(state==='paused')resume();flap();
    } else if(game==='bounce' && ['Space','ArrowUp','KeyW'].includes(k)){
      e.preventDefault();if(state==='ready'||state==='over')begin();else if(state==='paused')resume();bounceJump();
    } else if(game==='bounce' && ['ArrowLeft','KeyA','ArrowRight','KeyD'].includes(k)){
      e.preventDefault();if(state==='ready'||state==='over')begin();setBounceKey(['ArrowLeft','KeyA'].includes(k)?'left':'right',true);
    } else if(k==='Space' && game==='snake') {
      e.preventDefault();if(state==='running')pause();else if(state==='paused')resume();else begin();
    } else if(k==='Escape') {
      if(state==='running')pause();refs.screen.blur();
    }
  }
  function setDirection(direction) {
    if (!snake || !direction) return;
    const reverse={up:'down',down:'up',left:'right',right:'left'};
    if (direction !== reverse[snake.dir]) snake.next=direction;
  }
  function placeFood() {
    const free=[];
    for(let y=0;y<13;y++)for(let x=0;x<33;x++)
      if(!snake.cells.some(c=>c.x===x&&c.y===y))free.push({x,y});
    snake.food=free.length?free[Math.floor(Math.random()*free.length)]:null;
  }
  function updateSnake(dt) {
    if(!snake)return;
    snake.elapsed+=dt;
    snake.alive=(snake.alive||0)+dt;
    // Progressively accelerates even when the player hasn't eaten an apple.
    const step=clamp(.145-score*.0002-snake.alive*.00020,.065,.145);
    while(snake.elapsed>=step) {
      snake.elapsed-=step;
      snake.dir=snake.next;
      const d={up:[0,-1],down:[0,1],left:[-1,0],right:[1,0]}[snake.dir];
      // Classic Snake: leaving any edge enters on the opposite side.
      const head={x:(snake.cells[0].x+d[0]+33)%33,y:(snake.cells[0].y+d[1]+13)%13};
      const eating=snake.food && head.x===snake.food.x&&head.y===snake.food.y;
      const tailSafe=eating ? snake.cells : snake.cells.slice(0,-1);
      if(tailSafe.some(c=>c.x===head.x&&c.y===head.y)) {finish();return;}
      snake.cells.unshift(head);
      if(eating) {scoreChanged(score+10);placeFood();if(!snake.food){finish();return;}}
      else snake.cells.pop();
    }
  }
  function updateDino(dt) {
    if(!dino)return;
    dino.elapsed+=dt;
    const speed=Math.min(650,290+score*.9+dino.elapsed*.22);
    dino.distance+=speed*dt;
    scoreChanged(Math.floor(dino.distance/38));
    if(dino.y>0||dino.vel>0) {
      dino.y=Math.max(0,dino.y+dino.vel*dt);
      dino.vel-=1800*dt;
      if(dino.y===0)dino.vel=0;
    }
    dino.flight+=dt;
    dino.spawn-=dt;
    if(dino.spawn<=0){
      const ptero=(score>=35||dino.elapsed>=30) && Math.random()<Math.min(.52,.26+dino.elapsed*.0009);
      if (ptero) {
        // Flying at chest height requires ducking; the higher flight is an
        // optional hazard for badly timed jumps, matching the Chrome concept.
        const low=Math.random()<.73;
        dino.obstacles.push({type:'ptero',x:W+20,width:51,height:27,top:low?177:153});
      } else {
        const height=Math.random()>.46?49:35;
        dino.obstacles.push({type:'cactus',x:W+20,width:height>40?31:23,height});
      }
      dino.spawn=clamp(1.02+Math.random()*.92-score*.0014-dino.elapsed*.0008,.67,1.75);
    }
    for (const ob of dino.obstacles) {
      ob.x-=speed*dt;
      const ducking=dino.duck&&dino.y===0;
      const dx=82, dw=ducking?56:48, dh=ducking?27:48;
      const dy=240-dino.y-dh;
      const top=ob.type==='ptero'?ob.top:240-ob.height;
      // Small hitbox inset avoids unfair collisions on pixel-art edges.
      if(dx+dw-10>ob.x+5 && dx+10<ob.x+ob.width-5 &&
         dy+dh-4>top+4 && dy+4<top+ob.height-4) {finish();return;}
    }
    dino.obstacles=dino.obstacles.filter(ob=>ob.x>-90);
    for(const cloud of dino.clouds){cloud.x-=dt*15;if(cloud.x< -70)cloud.x=W+30;}
  }
  // Fall schedule: roughly 7 words/min initially, 10/min after 1 minute,
  // 20/min after 2 minutes, then +10/min per minute to a 45/min ceiling.
  // Word travel accelerates gently from 34 px/sec, keeping early rounds active.
  function fallRate(t){
    return Math.min(45,7+Math.min(t,60)*.05+Math.max(0,t-60)/6);
  }
  function randomWord() {
    const n=Math.random();
    if(n<.72)return COMMON_WORDS[Math.floor(Math.random()*COMMON_WORDS.length)];
    if(n<.92)return PROPER_WORDS[Math.floor(Math.random()*PROPER_WORDS.length)];
    if(n<.97)return EXPRESSIONS[Math.floor(Math.random()*EXPRESSIONS.length)];
    return ACRONYMS[Math.floor(Math.random()*ACRONYMS.length)];
  }
  function resetFall(){
    fall={words:[],elapsed:0,spawn:.01,lives:3,level:2,kills:0,nextId:1,flash:0};
    refs['fall-input'].value='';refs['fall-input'].dataset.invalid='false';
  }
  function spawnWord(){
    if(!fall)return;
    let word=randomWord();
    for(let i=0;i<14 && fall.words.some(w=>w.text===word);i++)word=randomWord();
    let x=50+Math.random()*(W-245);
    for(let attempt=0;attempt<16;attempt++){
      const collision=fall.words.some(w=>w.y<75&&Math.abs(w.x-x)<155);
      if(!collision)break;
      x=50+Math.random()*(W-245);
    }
    fall.words.push({id:fall.nextId++,text:word,x,y:14,speed:34+fall.elapsed*.045});
  }
  function updateFall(dt){
    if(!fall)return;
    fall.elapsed+=dt;
    fall.level=2+Math.floor(fall.elapsed/60);
    fall.flash=Math.max(0,fall.flash-dt);
    fall.spawn-=dt;
    if(fall.spawn<=0){
      spawnWord();
      fall.spawn+=60/fallRate(fall.elapsed)*(.90+Math.random()*.20);
    }
    for(const word of fall.words)word.y+=(34+fall.elapsed*.045)*dt;
    const missed=fall.words.filter(w=>w.y>H-12);
    if(missed.length){
      fall.lives-=missed.length;fall.flash=.55;
      const misses=new Set(missed.map(w=>w.id));
      fall.words=fall.words.filter(w=>!misses.has(w.id));
      if(fall.lives<=0){fall.lives=0;finish();return;}
    }
  }
  function typeFallingWord(){
    if(game!=='wordfall'||state!=='running'||!fall)return;
    const typed=refs['fall-input'].value;
    const match=fall.words.filter(w=>w.text===typed).sort((a,b)=>b.y-a.y)[0];
    if(match){
      fall.words=fall.words.filter(w=>w.id!==match.id);
      fall.kills++;
      scoreChanged(score+Math.max(10,match.text.length*3));
      refs['fall-input'].value='';
    }else if(typed.length>18){refs['fall-input'].value='';}
    const now=refs['fall-input'].value;
    refs['fall-input'].dataset.invalid=String(!!now&&!fall.words.some(w=>w.text.startsWith(now)));
    draw();
  }
  function drawFall(ctx){
    const bg='#e3f0f3';
    ctx.fillStyle=bg;ctx.fillRect(0,0,W,H);
    const level=fall?fall.level:2;
    // Grid makes movement and the fall distance easy to read.
    ctx.strokeStyle='#bad4df';ctx.lineWidth=1;
    for(let x=0;x<W;x+=60){ctx.beginPath();ctx.moveTo(x,0);ctx.lineTo(x,H);ctx.stroke();}
    for(let y=0;y<H;y+=40){ctx.beginPath();ctx.moveTo(0,y);ctx.lineTo(W,y);ctx.stroke();}
    ctx.fillStyle='#455d69';ctx.font='bold 13px system-ui';
    ctx.fillText(`LEVEL ${String(level).padStart(2,'0')}`,16,24);
    const words=fall?.words||[{text:'Hello!',x:95,y:90},{text:'focus',x:400,y:165},{text:'Monday',x:210,y:230}];
    const typed=refs['fall-input']?.value||'';
    const targeted=typed?words.filter(w=>w.text.startsWith(typed)).sort((a,b)=>b.y-a.y)[0]:null;
    for(const w of words){
      const matched=targeted&&targeted===w;
      ctx.font='bold 23px ui-monospace,Consolas,monospace';
      const width=ctx.measureText(w.text).width+29;
      const x=clamp(w.x,12,W-width-6);
      roundedRect(ctx,x-8,w.y-25,width,38,9,matched?'#d1f3dc':'#fff');
      ctx.strokeStyle=matched?'#76eec6':'#c5d8e0';ctx.lineWidth=2;
      ctx.strokeRect(x-8,w.y-25,width,38);
      ctx.fillStyle='#213947';ctx.fillText(w.text,x,w.y+1);
      if(matched){
        ctx.save();ctx.beginPath();ctx.rect(x,w.y-21,ctx.measureText(typed).width,32);ctx.clip();
        ctx.fillStyle='#187f63';ctx.fillText(w.text,x,w.y+1);ctx.restore();
      }
    }
    ctx.fillStyle=fall?.flash?'#f28d82':'#cc675d';
    ctx.fillRect(0,H-8,W,8);
    ctx.fillStyle='#586f7b';ctx.font='12px system-ui';
    ctx.fillText('Words that reach the red line cost one life.',16,H-20);
  }

  function resetTyping(){
    typing={elapsed:0,typedTotal:0,correctTotal:0,keystrokes:0,errors:0,
      passage:PHRASES[Math.floor(Math.random()*10)],previous:'',passages:0};
    refs['typing-input'].disabled=false;
    refs['typing-input'].value='';
    refs['typing-input'].placeholder='Start typing the passage here...';
    showTypingPrompt();
  }
  function showTypingPrompt(){
    if(!typing)return;
    const typed=refs['typing-input'].value;
    // DOM text nodes, never innerHTML with untrusted typed content.
    const prompt=refs['typing-prompt'];prompt.replaceChildren();
    for(let i=0;i<typing.passage.length;i++){
      const span=document.createElement('span');span.textContent=typing.passage[i];
      span.className=i<typed.length?(typing.passage[i]===typed[i]?'correct':'incorrect'):(i===typed.length?'cursor':'pending');
      prompt.append(span);
    }
  }
  function typingWpm(){
    if(!typing)return 0;
    const typed=refs['typing-input'].value;
    let currentCorrect=0;
    for(let i=0;i<typed.length;i++)if(typed[i]===typing.passage[i])currentCorrect++;
    return Math.max(0,Math.round((typing.correctTotal+currentCorrect)/5 / (Math.max(1,typing.elapsed)/60)));
  }
  function typeTest(){
    if(game!=='typing'||state!=='running'||!typing)return;
    const current=refs['typing-input'].value;
    if(current.length>typing.previous.length){
      for(let i=typing.previous.length;i<current.length;i++){
        typing.keystrokes++;
        if(current[i]!==typing.passage[i])typing.errors++;
      }
    }
    typing.previous=current;
    if(current===typing.passage){
      typing.typedTotal+=current.length;typing.correctTotal+=current.length;typing.passages++;
      const tier=typing.elapsed>=90?PHRASES.slice(13):typing.elapsed>=30?PHRASES.slice(8):PHRASES.slice(0,11);
      const options=tier.filter(p=>p!==typing.passage);
      typing.passage=options[Math.floor(Math.random()*options.length)];
      refs['typing-input'].value='';typing.previous='';
    }
    showTypingPrompt();
    scoreChanged(typingWpm());refreshMeta();
  }
  function updateTyping(dt){
    if(!typing)return;
    typing.elapsed=Math.min(duration*60,typing.elapsed+dt);
    scoreChanged(typingWpm());
    if(typing.elapsed>=duration*60){
      refs['typing-input'].disabled=true;
      finish();
    }
  }

  function resetFlappy(){
    flappy={birdY:135,velocity:-180,pipes:[],spawn:1.3,speed:162,passed:0,elapsed:0,wing:0};
  }
  function flap(){
    if(game==='flappy'&&state==='running'&&flappy){flappy.velocity=-305;flappy.wing=0;}
  }
  function updateFlappy(dt){
    if(!flappy)return;
    flappy.elapsed+=dt;
    flappy.speed=162+Math.min(125,flappy.elapsed*.33);
    flappy.velocity+=820*dt;
    flappy.birdY+=flappy.velocity*dt;
    flappy.wing+=dt;
    flappy.spawn-=dt;
    if(flappy.spawn<=0){
      const gap=Math.max(108,150-flappy.passed*.43-flappy.elapsed*.085);
      flappy.pipes.push({x:W+15,gapTop:48+Math.random()*(240-gap-54),gap,scored:false});
      flappy.spawn=Math.max(1.25,1.65-flappy.elapsed*.0009);
    }
    for(const pipe of flappy.pipes){
      pipe.x-=flappy.speed*dt;
      if(!pipe.scored&&pipe.x+74<153){pipe.scored=true;flappy.passed++;scoreChanged(flappy.passed);}
      if(153+15>pipe.x&&153-15<pipe.x+74 &&
         (flappy.birdY-12<pipe.gapTop||flappy.birdY+12>pipe.gapTop+pipe.gap)){finish();return;}
    }
    flappy.pipes=flappy.pipes.filter(p=>p.x>-90);
    if(flappy.birdY-13<=3||flappy.birdY+13>=268)finish();
  }
  function drawFlappy(ctx){
    ctx.fillStyle='#a6e2ec';ctx.fillRect(0,0,W,H);
    ctx.fillStyle='#fff9';
    for(const [x,y] of [[90,45],[290,68],[520,35],[630,97]]){
      roundedRect(ctx,x,y,79,16,8,ctx.fillStyle);roundedRect(ctx,x+21,y-8,43,19,10,ctx.fillStyle);
    }
    const f=flappy||{birdY:139,velocity:0,pipes:[{x:420,gapTop:92,gap:143}],wing:0};
    for(const pipe of f.pipes){
      const x=pipe.x,top=pipe.gapTop,bottom=top+pipe.gap;
      const fill='#279955',edge='#125f37';
      roundedRect(ctx,x+5,-6,64,top+6,4,fill);
      roundedRect(ctx,x,top-16,74,16,3,edge);
      roundedRect(ctx,x+5,bottom,64,270-bottom,4,fill);
      roundedRect(ctx,x,bottom,74,16,3,edge);
      ctx.fillStyle='#95e6a0';ctx.fillRect(x+12,0,8,Math.max(0,top-16));
      ctx.fillRect(x+12,bottom+16,8,Math.max(0,267-bottom-16));
    }
    ctx.fillStyle='#dfc975';ctx.fillRect(0,268,W,32);
    ctx.fillStyle='#6bb978';ctx.fillRect(0,268,W,9);
    ctx.save();ctx.translate(153,f.birdY);ctx.rotate(clamp(f.velocity/800,-.45,.8));
    roundedRect(ctx,-17,-12,32,24,9,'#fac64f');
    roundedRect(ctx,-13,Math.sin(f.wing*14)>0?0:-5,19,10,5,'#f59c38');
    ctx.fillStyle='#fff';ctx.fillRect(4,-9,9,9);ctx.fillStyle='#1d2530';ctx.fillRect(9,-7,4,5);
    ctx.fillStyle='#ef7d41';ctx.fillRect(13,1,14,5);ctx.restore();
    ctx.font='bold 38px system-ui';ctx.fillStyle='#2a6372';
    ctx.textAlign='center';ctx.fillText(String(f.passed||0),W/2,48);ctx.textAlign='left';
  }

  // Nokia Bounce-inspired level platformer: authored terrain, hoops, floating
  // brick corridors, checkpoints, springs, spikes, rotating enemies and exits.
  // All graphics are our own canvas art; no copied Nokia ROM or sprite assets.
  const BOUNCE_STAGES = [
    {
      length:1960,
      ground:[[-80,540],[515,350],[908,335],[1300,650]],
      ledges:[[210,208,150],[560,201,135],[760,157,110],[1010,205,135],[1160,169,116],[1440,211,138],[1645,184,105]],
      blocks:[[348,241,25,27],[692,235,25,33],[1185,241,27,27],[1460,80,80,28]],
      hoops:[[140,226],[270,176],[600,173],[805,125],[1060,172],[1500,177]],
      spikes:[[420,254],[992,254],[1360,254]],
      rotors:[[675,126,'y',24,1.3],[1254,189,'x',43,1.0]],
      springs:[[1042,205]], checkpoints:[555,1340], portal:1840
    },
    {
      length:2070,
      ground:[[-80,440],[415,332],[830,319],[1200,308],[1580,490]],
      ledges:[[150,210,124],[365,170,144],[610,215,120],[760,159,126],[990,195,142],[1180,143,130],[1430,202,130],[1625,167,126],[1830,192,95]],
      blocks:[[287,228,27,40],[575,239,22,29],[1038,226,27,42],[1375,228,30,40],[1490,74,116,26]],
      hoops:[[188,183],[435,140],[662,181],[806,126],[1230,110],[1695,138]],
      spikes:[[310,254],[930,254],[1258,254],[1750,254]],
      rotors:[[740,112,'y',35,1.4],[1120,190,'x',55,1.1],[1550,136,'y',32,1.25]],
      springs:[[995,195],[1448,202]], checkpoints:[470,1230], portal:1995
    },
    {
      length:2150,
      ground:[[-80,360],[405,334],[812,342],[1215,300],[1590,560]],
      ledges:[[160,200,130],[340,160,120],[540,216,145],[742,150,135],[960,204,150],[1135,152,137],[1420,210,116],[1550,151,134],[1790,195,116]],
      blocks:[[295,236,26,32],[667,220,27,48],[1045,232,30,36],[1480,226,27,42],[1750,55,130,24]],
      hoops:[[205,173],[385,128],[595,183],[802,117],[1202,118],[1602,121]],
      spikes:[[320,254],[575,254],[890,254],[1280,254],[1875,254]],
      rotors:[[380,95,'y',36,1.6],[910,149,'x',62,1.25],[1390,165,'y',37,1.3],[1770,132,'x',52,1.6]],
      springs:[[950,204],[1560,151]], checkpoints:[465,1260], portal:2065
    }
  ];
  function bounceGenerate(world){
    const layout=BOUNCE_STAGES[(world.level-1)%BOUNCE_STAGES.length];
    const extra=Math.floor((world.level-1)/BOUNCE_STAGES.length);
    world.length=layout.length;
    world.platforms=[...layout.ground.map(([x,w])=>({x,y:268,w,h:86,kind:'ground'})),
      ...layout.ledges.map(([x,y,w])=>({x,y,w,h:17,kind:'ledge'})),
      ...layout.blocks.map(([x,y,w,h])=>({x,y,w,h,kind:'block'}))];
    world.ringsList=layout.hoops.map(([x,y])=>({x,y,taken:false}));
    world.spikes=layout.spikes.map(([x,y])=>({x,y}));
    world.rotors=layout.rotors.map(([x,y,axis,range,speed],i)=>({x,y,axis,range,speed:speed*(1+extra*.12),phase:i*1.8,r:14}));
    world.springs=layout.springs.map(([x,y])=>({x,y}));
    world.checkpointList=layout.checkpoints;
    world.portal={x:layout.portal,y:229};
    world.stageRings=0;
  }
  function resetBounce(){
    bounce={x:105,y:233,vx:0,vy:-360,keys:{},camera:0,lives:3,rings:0,level:1,
      checkpoints:105,platforms:[],ringsList:[],spikes:[],rotors:[],springs:[],
      invulnerable:0,elapsed:0,stageRings:0,portal:null};
    bounceGenerate(bounce);
  }
  function setBounceKey(direction,pressed){
    if(game==='bounce'&&bounce)bounce.keys[direction]=pressed;
  }
  function bounceNudge(direction){
    if(!bounce)return;
    if(direction==='left')bounce.vx=-236;
    if(direction==='right')bounce.vx=236;
  }
  function bounceJump(){
    if(game==='bounce'&&state==='running'&&bounce){
      bounce.vy=Math.min(bounce.vy,-550);
    }
  }
  function bounceDamage(){
    if(!bounce||bounce.invulnerable>0)return;
    bounce.lives--;
    if(bounce.lives<=0){finish();return;}
    bounce.invulnerable=1.6;
    bounce.x=bounce.checkpoints;bounce.y=227;bounce.vy=-390;bounce.vx=0;
    bounce.camera=Math.max(0,bounce.x-155);
  }
  function bounceNextStage(){
    if(!bounce)return;
    scoreChanged(score+250);
    bounce.level++;
    bounce.x=105;bounce.y=227;bounce.vx=0;bounce.vy=-360;
    bounce.camera=0;bounce.checkpoints=105;bounce.invulnerable=1.2;
    bounceGenerate(bounce);
  }
  function updateBounce(dt){
    if(!bounce)return;
    const b=bounce;
    b.elapsed+=dt;
    b.invulnerable=Math.max(0,b.invulnerable-dt);
    const direction=(b.keys.right?1:0)-(b.keys.left?1:0);
    const pace=Math.min(300,236+b.elapsed*.10+(b.level-1)*7);
    if(direction)b.vx=direction*pace;
    else b.vx*=Math.max(0,1-7*dt);
    const oldX=b.x,oldY=b.y;
    b.x=clamp(b.x+b.vx*dt,16,b.length-18);
    b.vy=Math.min(680,b.vy+1320*dt);
    b.y+=b.vy*dt;
    const R=14;
    // Collision with bricks: tops, ceilings and vertical faces are solid.
    for(const p of b.platforms){
      if(b.x+R<=p.x||b.x-R>=p.x+p.w||b.y+R<=p.y||b.y-R>=p.y+p.h)continue;
      if(oldY+R<=p.y+2 && b.vy>=0){
        b.y=p.y-R;b.vy=-410; // automatic rubber-ball bounce
      }else if(oldY-R>=p.y+p.h-2 && b.vy<0){
        b.y=p.y+p.h+R;b.vy=Math.max(85,-b.vy*.22);
      }else if(oldX+R<=p.x+2 && b.vx>0){
        b.x=p.x-R;b.vx=-b.vx*.22;
      }else if(oldX-R>=p.x+p.w-2 && b.vx<0){
        b.x=p.x+p.w+R;b.vx=-b.vx*.22;
      }else if(b.vy>=0){b.y=p.y-R;b.vy=-410;}
      else {b.y=p.y+p.h+R;b.vy=85;}
    }
    for(const pad of b.springs){
      if(Math.abs(b.x-pad.x)<22 && Math.abs(b.y-pad.y+R)<19 && b.vy<0)
        b.vy=Math.min(b.vy,-640);
    }
    for(const cp of b.checkpointList){
      if(b.x>=cp&&cp>b.checkpoints)b.checkpoints=cp;
    }
    b.camera=clamp(b.x-163,0,Math.max(0,b.length-W));
    if(b.y>H+42){bounceDamage();return;}
    for(const ring of b.ringsList){
      if(!ring.taken&&Math.hypot(ring.x-b.x,ring.y-b.y)<27){
        ring.taken=true;b.rings++;b.stageRings++;
        scoreChanged(score+30);
      }
    }
    for(const spike of b.spikes){
      if(Math.abs(b.x-spike.x)<20 && b.y+R>spike.y-13 && b.y-R<spike.y+13){
        bounceDamage();return;
      }
    }
    for(const rotor of b.rotors){
      const phase=b.elapsed*rotor.speed*(1+Math.min(1.5,b.elapsed*.004))+rotor.phase;
      const cx=rotor.x+(rotor.axis==='x'?Math.sin(phase)*rotor.range:0);
      const cy=rotor.y+(rotor.axis==='y'?Math.sin(phase)*rotor.range:0);
      if(Math.hypot(cx-b.x,cy-b.y)<R+rotor.r-2){bounceDamage();return;}
    }
    if(b.stageRings===b.ringsList.length &&
      Math.hypot(b.x-b.portal.x,b.y-b.portal.y)<45)bounceNextStage();
  }
  function drawBounce(ctx){
    const b=bounce||{x:105,y:233,camera:0,lives:3,rings:0,level:1,stageRings:0,elapsed:0,
      invulnerable:0,platforms:[{x:-80,y:268,w:540,h:86}],
      ringsList:[{x:140,y:226,taken:false},{x:270,y:176,taken:false}],
      spikes:[{x:420,y:254}],rotors:[{x:675,y:126,axis:'y',range:24,speed:1.3,phase:0,r:14}],
      springs:[],checkpointList:[555],portal:{x:1840,y:229},length:1960};
    const camera=b.camera;
    const sky='#8dd9f4';
    ctx.fillStyle=sky;ctx.fillRect(0,0,W,H);
    // Nokia-era cyan sky and atmospheric geometric clouds.
    const haze='#c8f0ff';
    for(let i=0;i<7;i++){
      const x=((i*226-camera*.12+W*5)%(W+270))-120;
      roundedRect(ctx,x,45+i%3*29,90,12,5,haze);
      roundedRect(ctx,x+23,36+i%3*29,49,16,7,haze);
    }
    // Flooded gaps beneath the bricks, visible but not themselves a collision.
    ctx.fillStyle='#3175b3';ctx.fillRect(0,285,W,15);
    ctx.strokeStyle='#9adaff';ctx.lineWidth=2;
    for(let x=0;x<W;x+=36){ctx.beginPath();ctx.moveTo(x,285+Math.sin(x*.07+b.elapsed*2)*2);ctx.lineTo(x+17,285);ctx.stroke();}
    const brickBase='#b64520',brickHi='#ef7b3d';
    const brickDark='#73321f';
    for(const p of b.platforms){
      const left=p.x-camera,right=left+p.w;
      if(left>W+30||right< -30)continue;
      const x0=Math.max(0,Math.floor(left/24)),x1=Math.min(Math.ceil(W/24),Math.ceil(right/24));
      const top=Math.max(0,p.y),bottom=Math.min(H,p.y+p.h);
      // Tile rectangles clipped to each platform, so brick seams match blocks.
      ctx.save();ctx.beginPath();ctx.rect(left,p.y,p.w,p.h);ctx.clip();
      ctx.fillStyle=brickBase;ctx.fillRect(left,top,p.w,bottom-top);
      for(let yy=Math.floor(p.y/24)*24;yy<bottom;yy+=24){
        for(let col=x0-1;col<=x1+1;col++){
          const x=col*24+(Math.floor(yy/24)%2?12:0);
          ctx.fillStyle=brickDark;ctx.fillRect(x,yy,24,1.8);ctx.fillRect(x,yy,1.8,24);
          ctx.fillStyle=brickHi;ctx.fillRect(x+3,yy+4,17,3);
          ctx.fillStyle='#ef9e6544';ctx.fillRect(x+4,yy+10,10,2);
        }
      }
      ctx.restore();
    }
    for(const spring of b.springs){
      const x=spring.x-camera,y=spring.y;if(x<-30||x>W+30)continue;
      ctx.fillStyle='#24ad73';ctx.fillRect(x-10,y-17,20,18);
      ctx.fillStyle='#f4d257';ctx.fillRect(x-15,y-20,30,5);
      ctx.fillStyle='#e6fff2';ctx.fillRect(x-6,y-13,12,5);
    }
    for(const cp of b.checkpointList){
      const x=cp-camera;if(x<-30||x>W+30)continue;
      ctx.strokeStyle='#e3e5ef';ctx.lineWidth=3;ctx.beginPath();ctx.moveTo(x,269);ctx.lineTo(x,225);ctx.stroke();
      ctx.fillStyle=cp<=b.checkpoints?'#6de39f':'#bdd1dc';
      ctx.beginPath();ctx.moveTo(x+1,226);ctx.lineTo(x+23,231);ctx.lineTo(x+1,243);ctx.fill();
    }
    for(const ring of b.ringsList){
      if(ring.taken)continue;
      const x=ring.x-camera;if(x<-40||x>W+40)continue;
      ctx.strokeStyle='#a96208';ctx.lineWidth=8;ctx.beginPath();ctx.ellipse(x,ring.y,11,18,0,0,Math.PI*2);ctx.stroke();
      ctx.strokeStyle='#ffd44a';ctx.lineWidth=5;ctx.beginPath();ctx.ellipse(x,ring.y,11,18,0,0,Math.PI*2);ctx.stroke();
      ctx.strokeStyle='#fff2a4';ctx.lineWidth=2;ctx.beginPath();ctx.ellipse(x-2,ring.y-2,8,15,0,Math.PI*.8,Math.PI*1.7);ctx.stroke();
    }
    for(const spike of b.spikes){
      const x=spike.x-camera;if(x<-40||x>W+40)continue;
      ctx.fillStyle='#652c20';ctx.fillRect(x-15,spike.y+9,30,5);
      for(let k=-1;k<=1;k++){
        ctx.fillStyle='#f5b95e';ctx.beginPath();ctx.moveTo(x+k*10-5,spike.y+10);
        ctx.lineTo(x+k*10,spike.y-13);ctx.lineTo(x+k*10+5,spike.y+10);ctx.fill();
        ctx.fillStyle='#fff3ad';ctx.fillRect(x+k*10-1,spike.y-7,2,5);
      }
    }
    for(const rotor of b.rotors){
      const phase=b.elapsed*rotor.speed*(1+Math.min(1.5,b.elapsed*.004))+rotor.phase;
      const x=rotor.x-camera+(rotor.axis==='x'?Math.sin(phase)*rotor.range:0);
      const y=rotor.y+(rotor.axis==='y'?Math.sin(phase)*rotor.range:0);
      if(x<-45||x>W+45)continue;
      ctx.save();ctx.translate(x,y);ctx.rotate(b.elapsed*3.4);
      ctx.fillStyle='#113c5e';ctx.strokeStyle='#8bd9fa';ctx.lineWidth=2.5;
      for(let k=0;k<8;k++){
        ctx.rotate(Math.PI/4);ctx.beginPath();ctx.moveTo(0,-6);ctx.lineTo(-5,-23);ctx.lineTo(0,-27);ctx.lineTo(5,-23);ctx.lineTo(2,-6);ctx.fill();ctx.stroke();
      }
      ctx.fillStyle='#98d8f4';ctx.beginPath();ctx.arc(0,0,8,0,Math.PI*2);ctx.fill();ctx.restore();
    }
    const gateOpen=b.stageRings===b.ringsList.length;
    const exitX=b.portal.x-camera;
    if(exitX>-70&&exitX<W+60){
      ctx.fillStyle=gateOpen?'#3b805d':'#667382';ctx.fillRect(exitX-18,189,37,78);
      ctx.fillStyle=gateOpen?'#baffb3':'#d5dee4';ctx.fillRect(exitX-13,194,27,63);
      ctx.fillStyle=gateOpen?'#2b9c69':'#7a8694';ctx.fillRect(exitX-8,199,17,53);
      ctx.fillStyle=gateOpen?'#e0ffe8':'#d7e0ee';ctx.fillRect(exitX+2,220,4,4);
      ctx.font='bold 10px system-ui';ctx.fillStyle='#edfaff';
      ctx.fillText(gateOpen?'EXIT':'LOCKED',exitX-21,180);
    }
    if(b.invulnerable<=0||Math.floor(b.invulnerable*12)%2===0){
      const x=b.x-camera,y=b.y;
      const glow=ctx.createRadialGradient(x-5,y-6,1,x,y,16);
      glow.addColorStop(0,'#ffcb83');glow.addColorStop(.45,'#ff5c36');glow.addColorStop(1,'#8d1c28');
      ctx.fillStyle=glow;ctx.beginPath();ctx.arc(x,y,14,0,Math.PI*2);ctx.fill();
      ctx.strokeStyle='#5c1820';ctx.lineWidth=2;ctx.stroke();
      ctx.fillStyle='#ffe0b2';ctx.beginPath();ctx.ellipse(x-5,y-6,4,3,-.4,0,Math.PI*2);ctx.fill();
    }
    ctx.font='bold 12px ui-monospace,monospace';ctx.fillStyle='#143b5a';
    ctx.fillText(`LEVEL ${b.level}  ♥ ${b.lives}  HOOPS ${b.stageRings}/${b.ringsList.length}  TIME ${Math.floor(b.elapsed)}s`,15,19);
    if(!gateOpen){
      ctx.font='10px system-ui';ctx.fillStyle='#25526c';
      ctx.fillText('Collect all golden hoops to open the exit',15,36);
    }
  }

  function loop(time) {
    if (!host || state!=='running') return;
    if (!lastFrameTime)lastFrameTime=time;
    const dt=clamp((time-lastFrameTime)/1000,0,.05);
    lastFrameTime=time;
    if(game==='dino')updateDino(dt);
    else if(game==='snake')updateSnake(dt);
    else if(game==='wordfall')updateFall(dt);
    else if(game==='typing')updateTyping(dt);
    else if(game==='flappy')updateFlappy(dt);
    else if(game==='bounce')updateBounce(dt);
    refreshMeta();draw();
    if(state==='running')frame=requestAnimationFrame(loop);
  }
  function roundedRect(ctx,x,y,w,h,r,color) {
    ctx.fillStyle=color;
    ctx.beginPath();ctx.roundRect(x,y,w,h,r);ctx.fill();
  }
  function draw() {
    if(!host)return;
    const ctx=refs.screen.getContext('2d');
    if(!ctx)return;
    ctx.clearRect(0,0,W,H);
    ctx.fillStyle='#edf5f5';ctx.fillRect(0,0,W,H);
    if(game==='dino')drawDino(ctx);
    else if(game==='snake')drawSnake(ctx);
    else if(game==='wordfall')drawFall(ctx);
    else if(game==='flappy')drawFlappy(ctx);
    else if(game==='bounce')drawBounce(ctx);
  }
  // Original, crisp pixel-art characters painted in canvas (no imported game sprites).
  function drawDino(ctx) {
    const ground='#708e95';
    const ink='#294b56';
    const highlight='#407887';
    const shade='#203e48';
    const sky='#d8e9ed';
    const cactus='#247c62';
    const world=dino || {y:0,duck:false,flight:0,distance:0,
      obstacles:[{type:'cactus',x:485,width:28,height:49},{type:'ptero',x:625,width:51,height:27,top:177}],
      clouds:[{x:128,y:48},{x:430,y:70},{x:650,y:38}]};
    ctx.imageSmoothingEnabled=false;
    const rect=(x,y,w,h,c)=>{ctx.fillStyle=c;ctx.fillRect(Math.round(x),Math.round(y),w,h);};
    // Atmospheric sky: a striped sun and small 8-bit clouds.
    rect(594,26,57,57,'#c5dbe1');
    rect(600,32,45,45,'#f2e9c1');
    for(let i=0;i<3;i++)rect(595,53+i*10,56,3,sky);
    for(const cloud of world.clouds){
      const x=Math.round(cloud.x),y=cloud.y;
      rect(x+10,y,28,3,ground);rect(x+4,y+4,44,3,ground);
      rect(x,y+8,58,3,ground);rect(x+7,y+11,47,2,ground);
    }
    rect(0,240,W,2,ground);
    for(let i=0;i<20;i++){
      const x=((i*67-(world.distance*.61)%67)+W)%W;
      rect(x,255+(i%3)*10,(i%3===0?18:9),2,ground);
    }
    // Improved original T-Rex: large snout, open mouth, eye, arm, alternating
    // running legs, and clearly different ducking pose.
    const jumpY=Math.round(world.y), duck=world.duck&&jumpY===0;
    const runFrame=Math.floor(world.distance/28)%2;
    ctx.save();ctx.translate(82,240-jumpY);
    if(duck){
      rect(-3,-25,49,16,ink);rect(31,-32,37,20,ink);
      rect(56,-15,20,5,ink);rect(0,-29,11,8,ink);
      rect(8,-9,8,9,ink);rect(42,-9,8,9,ink);
      rect(56,-26,4,4,sky);rect(47,-11,20,3,sky);
      rect(35,-29,3,11,highlight);rect(5,-20,15,4,shade);
    } else {
      rect(0,-33,34,25,ink);rect(-13,-25,17,7,ink);
      rect(-7,-19,12,5,ink);rect(21,-51,31,30,ink);
      rect(44,-40,22,12,ink);rect(36,-28,31,7,ink);
      rect(50,-31,18,3,sky);rect(32,-50,10,4,highlight);
      rect(45,-45,5,5,sky);rect(46,-44,2,2,highlight);
      rect(28,-23,14,5,shade);rect(39,-21,9,4,ink);
      rect(7,-9,9,9,ink);rect(26,-9,9,9,ink);
      if(jumpY===0&&state==='running'){
        if(runFrame){rect(7,-5,11,5,sky);rect(20,-3,14,3,ink);}
        else {rect(26,-6,10,6,sky);rect(6,-3,13,3,ink);}
      }
    }
    ctx.restore();
    for(const ob of world.obstacles){
      const x=Math.round(ob.x);
      if(ob.type==='ptero'){
        const y=ob.top,up=Math.floor(world.flight*8)%2===0;
        // Animated flapping pterodactyl: beak, wing, feet, tail and single eye.
        rect(x+17,y+11,25,9,ink);rect(x+34,y+15,23,4,ink);
        rect(x+2,y+16,16,5,ink);rect(x,y+12,9,4,ink);
        rect(x+23,y+20,4,5,ink);rect(x+35,y+20,4,5,ink);
        if(up){
          rect(x+17,y+3,11,11,ink);rect(x+11,y-3,9,9,ink);
          rect(x+5,y-7,8,7,ink);rect(x+32,y+4,8,11,shade);
        }else{
          rect(x+14,y+17,9,7,ink);rect(x+10,y+23,9,5,ink);
          rect(x+31,y+20,12,7,shade);rect(x+38,y+24,9,4,ink);
        }
        rect(x+39,y+12,4,4,sky);
      }else{
        const y=240-ob.height, tall=ob.height>40;
        rect(x+8,y,ob.width-14,ob.height,cactus);
        rect(x+4,y+7,ob.width-8,ob.height-8,cactus);
        rect(x-5,y+(tall?22:13),9,7,cactus);
        rect(x-5,y+(tall?10:8),5,(tall?15:9),cactus);
        rect(x+ob.width-2,y+17,10,7,cactus);
        rect(x+ob.width+4,y+7,5,14,cactus);
        rect(x+10,y+4,3,ob.height-8,'#7bd5a6');
      }
    }
  }
  function drawSnake(ctx) {
    const x0=30,y0=20,cell=20;
    const grid='rgba(38,109,112,.12)';
    ctx.fillStyle='#dfeeee';ctx.fillRect(x0,y0,660,260);
    ctx.strokeStyle=grid;ctx.lineWidth=1;
    for(let x=0;x<=33;x++){ctx.beginPath();ctx.moveTo(x0+x*cell+.5,y0);ctx.lineTo(x0+x*cell+.5,y0+260);ctx.stroke();}
    for(let y=0;y<=13;y++){ctx.beginPath();ctx.moveTo(x0,y0+y*cell+.5);ctx.lineTo(x0+660,y0+y*cell+.5);ctx.stroke();}
    const world=snake || {cells:[{x:14,y:7},{x:13,y:7},{x:12,y:7},{x:11,y:7}],dir:'right',food:{x:22,y:7}};
    if (world.food) {
      const fx=x0+world.food.x*cell,fy=y0+world.food.y*cell;
      roundedRect(ctx,fx+3,fy+3,14,14,5,'#e76c5d');
      ctx.fillStyle='#6f9c62';ctx.fillRect(fx+9,fy+1,4,5);
    }
    world.cells.forEach((segment,i)=>{
      const xx=x0+segment.x*cell,yy=y0+segment.y*cell;
      roundedRect(ctx,xx+2,yy+2,16,16, i===0?5:4, i===0?'#137f75':'#4bb59c');
      if(i===0){
        ctx.fillStyle='#eefbfa';
        const [a,b]=world.dir==='up'||world.dir==='down' ? [[6,8],[12,8]]:[[10,6],[10,12]];
        ctx.fillRect(xx+a[0],yy+a[1],3,3);ctx.fillRect(xx+b[0],yy+b[1],3,3);
      }
    });
  }

  function checkState() {
    if (disposed) return;
    if(!active()) {removePanel();return;}
    const empty=findEmptyMessage();
    if(!empty) {removePanel();return;}
    const zone=findZone(empty);
    if(!zone){removePanel();return;}
    lastZone=zone;
    if(!host)makePanel(zone);
    else position(zone); // Clamp saved location after viewport changes.
  }
  function schedule() {
    clearTimeout(statusTimer);
    if(!disposed)statusTimer=setTimeout(checkState,280);
  }
  const observer=new MutationObserver(mutations=>{
    if(disposed)return;
    if(mutations.some(m=>
      m.type==='characterData' && !m.target.parentElement?.closest('#zenx-lite-arcade-root') ||
      m.type==='childList' && !m.target.closest?.('#zenx-lite-arcade-root') &&
      ([...m.addedNodes,...m.removedNodes].some(n=>n.nodeType===1&&!n.closest?.('#zenx-lite-arcade-root')))))schedule();
  });
  observer.observe(root,{subtree:true,childList:true,characterData:true});
  chrome.storage.local.get(defaultStorage,values=>{
    gamesEnabled=values[STORAGE.enabled]!==false;
    game=MODES.includes(values[STORAGE.mode])?values[STORAGE.mode]:'dino';
    duration=TYPING_TIMES.includes(Number(values[STORAGE.typingDuration]))?Number(values[STORAGE.typingDuration]):1;
    stats=Object.fromEntries(MODES.map(name=>[name,{
      best:Math.max(0,Number(values[STORAGE[name+'Best']])||0),
      last:Math.max(0,Number(values[STORAGE[name+'Last']])||0)
    }]));
    typingScores=Object.fromEntries(TYPING_TIMES.map(minutes=>[minutes,{
      best:Math.max(0,Number(values[STORAGE[`typing${minutes}Best`]])||0),
      last:Math.max(0,Number(values[STORAGE[`typing${minutes}Last`]])||0)
    }]));
    if(values[STORAGE.layout] && typeof values[STORAGE.layout]==='object'){
      const l=values[STORAGE.layout];
      if(['left','top','width','height'].every(k=>Number.isFinite(l[k]))){savedLayout=l;layoutChanged=true;}
    }
    schedule();
  });
  chrome.storage.onChanged.addListener((changes,area)=>{
    if(area!=='local')return;
    let refresh=false;
    if(changes[STORAGE.enabled]){gamesEnabled=changes[STORAGE.enabled].newValue!==false;refresh=true;}
    for(const name of ['dino','snake','wordfall','flappy','bounce']){
      const best=STORAGE[name+'Best'],last=STORAGE[name+'Last'];
      if(changes[best])stats[name].best=Math.max(stats[name].best,Number(changes[best].newValue)||0);
      if(changes[last])stats[name].last=Number(changes[last].newValue)||0;
    }
    for(const minutes of TYPING_TIMES){
      const b=STORAGE[`typing${minutes}Best`],l=STORAGE[`typing${minutes}Last`];
      if(changes[b])typingScores[minutes].best=Math.max(typingScores[minutes].best,Number(changes[b].newValue)||0);
      if(changes[l])typingScores[minutes].last=Number(changes[l].newValue)||0;
    }
    if(host)refreshStats();
    if(refresh)schedule();
  });
  window.addEventListener('popstate',schedule);
  window.addEventListener('hashchange',schedule);
  window.addEventListener('resize',schedule,{passive:true});
  document.addEventListener('visibilitychange',()=>{if(document.hidden && state==='running')pause();});
  window.addEventListener('blur',()=>{if(state==='running')pause();});
  statusPoll=setInterval(checkState,1700); // Native Zendesk uses client-side routing.
  window.addEventListener('pagehide',()=>{
    disposed=true;clearInterval(statusPoll);clearTimeout(statusTimer);clearTimeout(scoreSaveTimer);
    if(state==='running'||state==='paused')recordRun();
    removePanel();observer.disconnect();
  },{once:true});
  schedule();
})();
