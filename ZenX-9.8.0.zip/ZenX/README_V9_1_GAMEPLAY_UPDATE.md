# ZenX v9.1 — Arcade Gameplay and Shortcut Fix

This builds on ZenX v9.0. The Zendesk integration, theme engine, pill, ticket sync, timers, quick macros, tab controls and score storage are unchanged. The Arcade remains restricted to Zendesk Home's empty-ticket state.

## Falling Words

- Starts at **Level 2**, with an initial spawn rate near **7 words/minute** instead of roughly 3.5, and an initial downward speed of **34 pixels/second**, up from 17.
- Progression aims for **10, 20, 30, 40 incoming words/minute** at 1, 2, 3, 4 minutes, with the speed of falling words also rising slowly. These rates are approximate difficulty targets; no particular player's survival duration is guaranteed.
- No alternating uppercase/lowercase characters or artificial CamelCase. Random words are everyday lowercase English words, properly capitalized names/dates/places, familiar acronyms or short natural exclamations/questions. Exact capitalization and punctuation still count.
- **Zendesk `?` shortcut fix:** `arcade-keys.js` installs a capture listener at `document_start` before Zendesk's shortcut handlers. The listener operates **only** if a running Falling Words or Typing Test input is actually receiving the key. It stops propagation to Zendesk without preventing the browser from typing the character. In-game Enter (clear) and Escape (pause) are preserved; all normal Zendesk input/shortcut behavior outside the game remains unchanged.

## Bounce Ball

- Replaced the endless repeating flat strip with **three authored side-scrolling level layouts**, with different ground gaps, elevated brick platforms, corridors and block obstacles.
- Retro-style orange brickwork and blue background, golden hoops, spike traps, animated blue rotating enemies, springs, checkpoints and a door/exit are drawn with original canvas art (not copied Nokia assets).
- Collect **all six hoops** in a level to unlock its exit, then travel to the exit to advance to the next level. Later rounds reuse varied layouts with accelerated moving enemies.
- Arrow Left / Right control movement; Space / Up add a higher bounce. Automatic ball bouncing and lives are retained. The game gets more difficult as elapsed time increases.

## Difficulty increases over time

- **Dinosaur:** Faster running speed, shorter obstruction intervals and increasing chance of pterodactyls.
- **Snake:** Faster movement the longer the run continues, even without eating food. Edge wrap is unchanged.
- **Falling Words:** Falling velocity and incoming word rate increase gradually, levels change each minute.
- **Typing Test:** Later passages use more challenging combinations of punctuation, names, numbers and capitalization. The original 1-, 2- and 5-minute results remain comparable under the same WPM formula.
- **Flappy Bird:** Pipes move faster, appear slightly more often, and openings shrink with elapsed time as well as score.
- **Bounce Ball:** Rotating hazards speed up with time; additional layouts increase platforming difficulty.

## Unchanged

- High score and last score keys (Chrome local storage)
- Global Enable ZenX / Enable on this tab / Home arcade controls
- Home-page empty-ticket gate; draggable/resizable Arcade
- Ticket number, top-tab timer, SLA pill, quick macro insertion, themes and composer integrations

## Verification

Offline Chromium/Playwright against a mock Zendesk Home: 7/7 v9.1 game and keyboard tests, 10/10 arcade Home/visibility/score/resize tests, 11/11 Home regression tests, quick macro and ticket synchronization suites passed. No live Zendesk account integration was tested. (The older v9.0 gameplay tests make outdated assertions about Bounce's former 25-point endless gameplay and Level 1 start.)

## Installation

Extract the ZIP, use the contained `ZenX/` folder to replace your unpacked extension directory, then open `chrome://extensions`, click Reload next to ZenX and refresh Zendesk. Existing high scores are preserved.
