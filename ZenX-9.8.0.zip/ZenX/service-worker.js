/* Per-browser-tab ZenX state persists through reloads, not browser restarts.
   Tab overrides are saved in chrome.storage.session; high scores remain in local. */
const storageKey = tabId => `zenx_tab_off_${tabId}`;
chrome.runtime.onMessage.addListener((message, sender, respond) => {
  if (!message || !['ZENX_GET_TAB_STATE','ZENX_SET_TAB_STATE'].includes(message.type)) return false;
  const tabId = message.type === 'ZENX_GET_TAB_STATE' && sender.tab?.id != null ? sender.tab.id : message.tabId;
  if (!Number.isInteger(tabId) || tabId < 0) {
    respond({success:false,error:'No valid browser tab'});
    return false;
  }
  const key = storageKey(tabId);
  if (message.type === 'ZENX_GET_TAB_STATE') {
    chrome.storage.session.get(key).then(data => respond({success:true,enabled:data[key] !== true}))
      .catch(error => respond({success:false,enabled:true,error:String(error)}));
  } else {
    const enabled = message.enabled !== false;
    const save = enabled ? chrome.storage.session.remove(key) : chrome.storage.session.set({[key]:true});
    save.then(async () => {
      // The tab can be on a Zendesk SPA page, another site, or unresponsive;
      // saving its setting must not be treated as an error if the tab has no content script.
      try { await chrome.tabs.sendMessage(tabId,{type:'ZENX_APPLY_TAB_STATE',enabled}); }
      catch (_) {}
      respond({success:true,enabled});
    }).catch(error => respond({success:false,error:String(error)}));
  }
  return true;
});
chrome.tabs.onRemoved.addListener(tabId => {
  chrome.storage.session.remove(storageKey(tabId)).catch(()=>{});
});
