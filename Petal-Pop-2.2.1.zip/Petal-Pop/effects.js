(() => {
  'use strict';

  const TAU = 2 * Math.PI;
  const styles = [
    { id: 'sparkles', label: 'Sparkles' },
    { id: 'hearts', label: 'Hearts' },
    { id: 'petals', label: 'Petals' },
    { id: 'stars', label: 'Stars' },
    { id: 'bubbles', label: 'Bubbles' },
    { id: 'confetti', label: 'Confetti' },
    { id: 'bows', label: 'Bows' },
    { id: 'moons', label: 'Moons' },
    { id: 'diamonds', label: 'Diamonds' },
    { id: 'fireflies', label: 'Fireflies' },
    { id: 'paw-trails', label: 'Paw trails' },
    { id: 'whale-splash', label: 'Whale splash' },
    { id: 'cat-scratch', label: 'Cat scratch' },
    { id: 'dog-tail', label: 'Dog tail wag' },
    { id: 'shark-fin', label: 'Shark fin' },
    { id: 'rabbit-hop', label: 'Rabbit hop' },
    { id: 'butterfly', label: 'Butterflies' },
    { id: 'fox-tail', label: 'Fox tail' },
    { id: 'star-shower', label: 'Falling stars' },
    { id: 'flower-bloom', label: 'Blooming flowers' },
    { id: 'bubble-pop', label: 'Popping bubbles' },
    { id: 'surprise-mix', label: 'Surprise mix' },
    ...(globalThis.PetalReferenceEffects?.styles || []).map(({ id, label }) => ({ id, label }))
  ];
  const known = new Set(styles.map(({ id }) => id));
  const surprises = ['star-shower', 'flower-bloom', 'bubble-pop'];
  const directions = { up: -Math.PI / 2, down: Math.PI / 2, left: Math.PI, right: 0 };
  const clamp = (n, min, max) => Math.min(max, Math.max(min, n));
  const number = (value, fallback, min, max) => {
    const n = Number(value);
    return value != null && value !== '' && Number.isFinite(n) ? clamp(n, min, max) : fallback;
  };
  const color = (value, fallback) => typeof value === 'string' && /^#[\da-f]{6}$/i.test(value) ? value : fallback;
  const easeOut = t => 1 - (1 - t) ** 2;

  function create(x, y, effect = {}) {
    const selected = known.has(effect.style) ? effect.style : 'sparkles';
    const reference = globalThis.PetalReferenceEffects?.get(selected);
    const angle = Object.hasOwn(directions, effect.direction) ? directions[effect.direction] : null;
    const count = Math.round(number(effect.count, 9, 1, 50));
    const spread = number(effect.spread, 58, 6, 260);
    const seed = (Math.random() * 2 ** 32) >>> 0;
    let state = seed;
    const random = () => {
      state = (Math.imul(state, 1664525) + 1013904223) >>> 0;
      return state / 2 ** 32;
    };
    const style = selected === 'surprise-mix' ? surprises[Math.floor(random() * surprises.length)] : selected;
    const rotation = random() * TAU;
    const particles = Array.from({ length: count }, (_, index) => {
      const orbit = angle === null ? rotation + TAU * index / count : angle + (random() - .5) * 1.55;
      return {
        angle: orbit,
        distance: spread * (.45 + random() * .55),
        scale: .48 + random() * .54,
        spin: (random() - .5) * 4,
        phase: random() * TAU,
        delay: random() * .12
      };
    });
    return {
      x, y, style, angle, count, spread, seed, particles,
      primary: reference && effect.sourceColors !== false ? reference.primary : color(effect.primary, '#ee719f'),
      secondary: reference && effect.sourceColors !== false ? reference.secondary : color(effect.secondary, '#a886ec'),
      size: number(effect.size, 100, 15, 350) / 100,
      duration: reference && effect.sourceTiming !== false ?
        reference.duration : number(effect.duration, reference?.duration ?? 650, 80, 8000),
      opacity: number(effect.opacity, 100, 0, 100) / 100
    };
  }

  function ellipse(ctx, x, y, rx, ry, rotation = 0) {
    ctx.beginPath();
    ctx.ellipse(x, y, rx, ry, rotation, 0, TAU);
    ctx.fill();
  }

  function star(ctx, tips, inner) {
    ctx.beginPath();
    for (let i = 0; i < tips * 2; i++) {
      const angle = i * Math.PI / tips - Math.PI / 2;
      const radius = i % 2 ? inner : 10;
      ctx.lineTo(radius * Math.cos(angle), radius * Math.sin(angle));
    }
    ctx.closePath();
    ctx.fill();
  }

  function paw(ctx) {
    ellipse(ctx, 0, 3.5, 5.8, 4.3);
    ellipse(ctx, -6.5, -1.8, 2.1, 3.3, -.38);
    ellipse(ctx, 6.5, -1.8, 2.1, 3.3, .38);
    ellipse(ctx, -2.6, -6, 2.1, 3.2, -.13);
    ellipse(ctx, 2.6, -6, 2.1, 3.2, .13);
  }

  function heart(ctx) {
    ctx.beginPath();
    ctx.moveTo(0, 8);
    ctx.bezierCurveTo(-5, 5, -11, 0, -9, -5);
    ctx.bezierCurveTo(-7, -9, -3, -9, 0, -5);
    ctx.bezierCurveTo(3, -9, 7, -9, 9, -5);
    ctx.bezierCurveTo(11, 0, 5, 5, 0, 8);
    ctx.fill();
  }

  function petal(ctx) {
    ctx.beginPath();
    ctx.moveTo(0, 8);
    ctx.bezierCurveTo(-12, 4, -7, -9, 0, -10);
    ctx.bezierCurveTo(9, -8, 10, 4, 0, 8);
    ctx.fill();
    ctx.beginPath();
    ctx.moveTo(0, 6);
    ctx.quadraticCurveTo(-3, 0, 0, -6);
    ctx.stroke();
  }

  function butterfly(ctx, phase) {
    const flap = .35 + .65 * Math.abs(Math.sin(phase));
    for (const side of [-1, 1]) {
      ctx.save();
      ctx.scale(side * flap, 1);
      ctx.beginPath();
      ctx.moveTo(0, 1);
      ctx.bezierCurveTo(1, -12, 16, -15, 14, -4);
      ctx.quadraticCurveTo(13, 1, 6, 2);
      ctx.bezierCurveTo(17, 3, 9, 13, 4, 8);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
      ctx.restore();
    }
    ctx.beginPath();
    ctx.moveTo(0, 7);
    ctx.lineTo(0, -6);
    ctx.quadraticCurveTo(-2, -9, -4, -10);
    ctx.moveTo(0, -6);
    ctx.quadraticCurveTo(2, -9, 4, -10);
    ctx.stroke();
  }

  function motif(ctx, style, phase) {
    switch (style) {
      case 'hearts': heart(ctx); break;
      case 'petals': petal(ctx); break;
      case 'stars': star(ctx, 5, 4.7); break;
      case 'bubbles':
        ctx.beginPath();
        ctx.arc(0, 0, 8, 0, TAU);
        ctx.stroke();
        ellipse(ctx, -3, -3.5, 2, 1.2, -.7);
        break;
      case 'confetti':
        ctx.fillRect(-5, -2.5, 10, 5);
        ctx.strokeRect(-5, -2.5, 10, 5);
        break;
      case 'bows':
        ctx.beginPath();
        ctx.moveTo(0, 0);
        ctx.bezierCurveTo(-15, -14, -16, 11, 0, 1);
        ctx.bezierCurveTo(16, 11, 15, -14, 0, 0);
        ctx.fill();
        ctx.beginPath();
        ctx.moveTo(0, 1);
        ctx.quadraticCurveTo(-2, 6, -8, 9);
        ctx.moveTo(0, 1);
        ctx.quadraticCurveTo(2, 6, 8, 9);
        ctx.stroke();
        ellipse(ctx, 0, 0, 2.2, 2.4);
        break;
      case 'moons':
        ctx.beginPath();
        ctx.arc(0, 0, 8, -1, 1, true);
        ctx.quadraticCurveTo(1, 0, 4.32, -6.73);
        ctx.fill();
        break;
      case 'diamonds':
        ctx.beginPath();
        ctx.moveTo(0, -10);
        ctx.lineTo(6, 0);
        ctx.lineTo(0, 10);
        ctx.lineTo(-6, 0);
        ctx.closePath();
        ctx.fill();
        ctx.stroke();
        break;
      case 'fireflies':
        ctx.save();
        ctx.globalAlpha *= .28;
        ellipse(ctx, 0, 0, 8, 8);
        ctx.restore();
        ellipse(ctx, 0, 0, 2.8 + 1.3 * Math.sin(phase), 2.8 + Math.sin(phase));
        break;
      case 'butterfly': butterfly(ctx, phase); break;
      case 'tide':
        ctx.rotate(.2);
        ctx.beginPath();
        ctx.moveTo(0, -9);
        ctx.bezierCurveTo(2, -4, 7, 0, 5, 4);
        ctx.arc(0, 4, 5, 0, Math.PI);
        ctx.bezierCurveTo(-7, 0, -2, -4, 0, -9);
        ctx.fill();
        break;
      case 'paw-trails': paw(ctx); break;
      default: star(ctx, 4, 3); break;
    }
  }

  function drawParticles(ctx, burst, t, style) {
    burst.particles.forEach((particle, index) => {
      if (t <= particle.delay) return;
      const progress = clamp((t - particle.delay) / (1 - particle.delay), 0, 1);
      const travel = easeOut(progress) * particle.distance;
      const drift = Math.sin(progress * 5 + particle.phase) * (style === 'butterfly' ? 9 : 2);
      const lift = style === 'tide' ? Math.sin(progress * Math.PI) * 19 : style === 'fireflies' ? progress * 9 : 0;
      const scale = burst.size * particle.scale * (.45 + .55 * Math.sin(progress * Math.PI * .85));
      ctx.save();
      ctx.globalAlpha *= Math.min(progress * 12, 1) * (1 - progress ** 1.6);
      ctx.translate(Math.cos(particle.angle) * travel + drift, Math.sin(particle.angle) * travel - lift);
      ctx.rotate(particle.spin * progress + (style === 'paw-trails' ? particle.angle + Math.PI / 2 : 0));
      ctx.scale(scale, scale);
      ctx.fillStyle = index % 2 ? burst.secondary : burst.primary;
      ctx.strokeStyle = index % 2 ? burst.primary : burst.secondary;
      ctx.lineWidth = 1.1;
      motif(ctx, style, progress * 32 + particle.phase);
      ctx.restore();
    });
  }

  function drawPawTrails(ctx, burst, t) {
    const lanes = Math.min(burst.angle === null ? 4 : 3, Math.max(1, Math.ceil(burst.count / 4)));
    const steps = Math.ceil(burst.count / lanes);
    for (let index = 0; index < burst.count; index++) {
      const lane = index % lanes;
      const step = Math.floor(index / lanes);
      const age = (t - .12 - step / steps * .39 - lane * .022) / .48;
      if (age <= 0 || age >= 1) continue;
      const angle = burst.angle === null ? burst.particles[0].angle + lane * TAU / lanes :
        burst.angle + (lane - (lanes - 1) / 2) * .48;
      const distance = burst.spread * (.15 + (step + 1) * .83 / steps);
      const side = (step % 2 ? -1 : 1) * 5 * burst.size;
      ctx.save();
      ctx.globalAlpha *= Math.min(age * 7, 1) * (1 - age ** 1.35);
      ctx.translate(Math.cos(angle) * distance - Math.sin(angle) * side,
        Math.sin(angle) * distance + Math.cos(angle) * side);
      ctx.rotate(angle + Math.PI / 2);
      ctx.scale(burst.size * .8, burst.size * .8);
      ctx.fillStyle = (lane + step) % 2 ? burst.secondary : burst.primary;
      paw(ctx);
      ctx.restore();
    }
  }

  function whale(ctx, t) {
    ctx.rotate(.38 * Math.sin(t * TAU * 1.5));
    ctx.beginPath();
    ctx.moveTo(4, 21);
    ctx.quadraticCurveTo(2, 5, 1, 3);
    ctx.bezierCurveTo(0, -3, 15, -10, 22, -7);
    ctx.bezierCurveTo(15, -14, 5, -15, 0, -8);
    ctx.bezierCurveTo(-5, -15, -15, -14, -22, -7);
    ctx.bezierCurveTo(-14, -9, -2, -4, -3, 3);
    ctx.quadraticCurveTo(-3, 11, -7, 21);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
  }

  function shark(ctx, t, burst) {
    ctx.translate((t - .35) * 34, 4 * Math.sin(t * TAU));
    ctx.beginPath();
    ctx.moveTo(-16, 7);
    ctx.bezierCurveTo(-9, 1, -9, -16, 6, -18);
    ctx.quadraticCurveTo(1, -6, 17, 7);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
    ctx.strokeStyle = burst.secondary;
    for (let i = 0; i < 3; i++) {
      ctx.beginPath();
      ctx.moveTo(-25 + i * 4, 11 + 3 * i);
      ctx.quadraticCurveTo(-12, 8 + 4 * i, 9 + i * 5, 11 + 3 * i);
      ctx.stroke();
    }
  }

  function dog(ctx, t, burst) {
    ctx.rotate(.70 * Math.sin(t * TAU * 3));
    ctx.lineWidth = 11;
    ctx.strokeStyle = burst.primary;
    ctx.beginPath();
    ctx.moveTo(0, 16);
    ctx.bezierCurveTo(1, 7, 17, 8, 16, -5);
    ctx.quadraticCurveTo(16, -12, 7, -15);
    ctx.stroke();
    ctx.lineWidth = 1.45;
    ctx.strokeStyle = burst.secondary;
    for (const side of [-1, 1]) {
      ctx.beginPath();
      ctx.moveTo(side * 20, -4);
      ctx.quadraticCurveTo(side * 26, -7, side * 23, -15);
      ctx.stroke();
    }
  }

  function rabbit(ctx, t, burst) {
    ctx.translate(t * 15 - 7, -18 * Math.sin(t * Math.PI * 1.35));
    ellipse(ctx, -6, -9, 3.6, 12, -.25);
    ellipse(ctx, 5, -9, 3.5, 12, .19);
    ellipse(ctx, 0, 5, 11, 9.3);
    ctx.fillStyle = burst.secondary;
    ellipse(ctx, -6, -10, 1.6, 8, -.25);
    ellipse(ctx, 5, -10, 1.5, 8, .19);
    ellipse(ctx, -4, 4, 1.25, 1.25);
    ellipse(ctx, 4, 4, 1.25, 1.25);
    ellipse(ctx, 0, 7, 1.6, 1);
  }

  function fox(ctx, t, burst) {
    ctx.rotate(.75 * Math.sin(t * TAU * 1.9));
    ctx.beginPath();
    ctx.moveTo(-9, 18);
    ctx.bezierCurveTo(-13, -4, 9, -19, 22, -17);
    ctx.bezierCurveTo(24, -3, 15, 14, -3, 17);
    ctx.lineTo(-9, 18);
    ctx.fill();
    ctx.stroke();
    ctx.fillStyle = burst.secondary;
    ctx.beginPath();
    ctx.moveTo(22, -17);
    ctx.bezierCurveTo(23, -10, 21, -5, 18, 0);
    ctx.lineTo(14, -3);
    ctx.lineTo(13, -8);
    ctx.lineTo(8, -9);
    ctx.quadraticCurveTo(14, -16, 22, -17);
    ctx.fill();
  }

  function drawScratch(ctx, burst, t) {
    ctx.save();
    ctx.scale(burst.size, burst.size);
    ctx.rotate(burst.angle === null ? .24 : burst.angle + Math.PI / 2);
    for (let i = -1; i <= 1; i++) {
      const progress = clamp((t - (i + 1) * .045) / .42, 0, 1);
      ctx.strokeStyle = i === 0 ? burst.primary : burst.secondary;
      ctx.lineWidth = 1 + progress * 2.2;
      ctx.beginPath();
      ctx.moveTo(i * 10 - 9, -24);
      ctx.quadraticCurveTo(i * 10 - 9 + progress * 18, -24 + progress * 19,
        i * 10 - 9 + progress * 16, -24 + progress * 49);
      ctx.stroke();
    }
    ctx.restore();
  }

  function drawStarShower(ctx, burst, t) {
    if (burst.angle !== null) ctx.rotate(burst.angle - Math.PI / 2);
    burst.particles.forEach((particle, index) => {
      const start = index / burst.count * .61;
      const age = (t - start) / Math.min(.59, .99 - start);
      if (age < 0 || age >= 1) return;
      const fall = burst.spread * (.67 + particle.scale * .38) * age ** 1.75;
      const sway = Math.cos(particle.phase) * particle.distance * .46 * easeOut(age);
      const size = burst.size * particle.scale;

      ctx.save();
      ctx.globalAlpha *= Math.min(.25 + age * 6, 1) * (1 - age ** 2.5);
      ctx.translate(sway, fall);
      ctx.scale(size, size);
      ctx.strokeStyle = index % 2 ? burst.primary : burst.secondary;
      ctx.fillStyle = index % 2 ? burst.secondary : burst.primary;
      const tail = 8 + 19 * age;
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.moveTo(1, -3);
      ctx.quadraticCurveTo(-2, -tail * .55, -4, -tail);
      ctx.stroke();
      ctx.rotate(particle.spin * age);
      star(ctx, 5, 4.1);
      ctx.restore();
    });
  }

  function drawFlowerBloom(ctx, burst, t) {
    burst.particles.forEach((particle, index) => {
      const start = index / burst.count * .37;
      const age = (t - start) / Math.min(.8, .99 - start);
      if (age < 0 || age >= 1) return;
      const size = burst.size * particle.scale;
      const reach = particle.distance * .86 * easeOut(clamp(age / .5, 0, 1));
      const opening = easeOut(clamp((age - .12) / .41, .04, 1));
      const petalInk = index % 2 ? burst.secondary : burst.primary;
      const centerInk = index % 2 ? burst.primary : burst.secondary;

      ctx.save();
      ctx.globalAlpha *= Math.min(.20 + age * 5, 1) * (1 - age ** 3.9);
      ctx.rotate(particle.angle + Math.PI / 2);
      ctx.strokeStyle = centerInk;
      ctx.lineWidth = Math.max(.7, size * 1.25);
      ctx.beginPath();
      ctx.moveTo(0, -Math.min(6, reach));
      ctx.quadraticCurveTo(reach * .19, -reach * .51, 0, -reach);
      ctx.stroke();
      ctx.fillStyle = centerInk;
      if (reach > 10) ellipse(ctx, reach * .105, -reach * .57, size * 3.5, size * 1.5, -.72);
      ctx.translate(0, -reach);
      ctx.rotate(particle.spin * .5 + age * .4);
      ctx.scale(size, size);

      ctx.fillStyle = petalInk;
      const petals = index % 3 === 0 ? 6 : 5;
      for (let petalIndex = 0; petalIndex < petals; petalIndex++) {
        ctx.rotate(TAU / petals);
        const petalLength = 2.5 + opening * 5;
        ellipse(ctx, 0, -opening * 7.7, 2.1 + opening * 2.4, petalLength);
      }
      ctx.fillStyle = centerInk;
      ellipse(ctx, 0, 0, 1.7 + opening * 2.8, 1.7 + opening * 2.8);
      ctx.restore();
    });
  }

  function drawBubblePop(ctx, burst, t) {
    if (burst.angle !== null) ctx.rotate(burst.angle + Math.PI / 2);
    burst.particles.forEach((particle, index) => {
      const start = index / burst.count * .38;
      const age = (t - start) / Math.min(.81, .99 - start);
      if (age < 0 || age >= 1) return;
      const pop = .59 + particle.delay;
      const float = Math.min(age, pop);
      const drift = Math.sin(particle.phase + float * 6) - Math.sin(particle.phase);
      const rise = float * burst.spread * (.86 + particle.scale * .58);
      const radius = (7 + particle.scale * 8) * burst.size * (.32 + .68 * easeOut(Math.min(float / .4, 1)));
      const rim = index % 2 ? burst.secondary : burst.primary;
      const accent = index % 2 ? burst.primary : burst.secondary;
      ctx.save();
      ctx.translate(drift * particle.distance * .22, -rise);
      ctx.lineWidth = Math.max(.8, burst.size * 1.45);
      ctx.strokeStyle = rim;
      ctx.fillStyle = accent;
      if (age < pop) {
        ctx.globalAlpha *= Math.min(.35 + age * 8, 1);
        ctx.beginPath();
        ctx.arc(0, 0, radius, 0, TAU);
        ctx.stroke();
        ellipse(ctx, -radius * .3, -radius * .44, radius * .22, radius * .13, -.63);
      } else {
        const after = (age - pop) / (1 - pop);
        ctx.globalAlpha *= (1 - after) ** 1.25;
        for (let fleck = 0; fleck < 5; fleck++) {
          ctx.rotate(TAU / 5);
          const offset = radius + after * (radius * 1.45 + 4);
          const length = radius * (.35 - after * .13);
          ctx.beginPath();
          ctx.moveTo(0, -offset);
          ctx.lineTo(0, -offset - length);
          ctx.stroke();
          ellipse(ctx, 0, -offset - length * 1.1, Math.max(.4, burst.size * 1.1), Math.max(.4, burst.size * 1.1));
        }
      }
      ctx.restore();
    });
  }

  const pets = {
    'whale-splash': [whale, 'tide'],
    'dog-tail': [dog, 'paw-trails'],
    'shark-fin': [shark, 'tide'],
    'rabbit-hop': [rabbit, 'petals'],
    'fox-tail': [fox, 'stars']
  };

  function draw(ctx, burst, elapsedMs) {
    if (elapsedMs < 0 || elapsedMs >= burst.duration || !burst.opacity) return;
    const t = elapsedMs / burst.duration;
    ctx.save();
    ctx.globalAlpha *= burst.opacity;
    ctx.translate(burst.x, burst.y);
    ctx.lineJoin = 'round';
    ctx.lineCap = 'round';
    const reference = globalThis.PetalReferenceEffects?.get(burst.style);
    if (reference) {
      reference.draw(ctx, burst, t);
    } else if (burst.style === 'star-shower') {
      drawStarShower(ctx, burst, t);
    } else if (burst.style === 'flower-bloom') {
      drawFlowerBloom(ctx, burst, t);
    } else if (burst.style === 'bubble-pop') {
      drawBubblePop(ctx, burst, t);
    } else if (burst.style === 'paw-trails') {
      drawPawTrails(ctx, burst, t);
    } else if (burst.style === 'cat-scratch') {
      ctx.globalAlpha *= 1 - easeOut(t) * .85;
      drawScratch(ctx, burst, t);
      drawParticles(ctx, burst, t, 'sparkles');
    } else {
      const pet = pets[burst.style];
      drawParticles(ctx, burst, t, pet ? pet[1] : burst.style);
      if (pet) {
        ctx.globalAlpha *= Math.min(t * 10, 1) * (1 - t ** 1.9);
        if (burst.angle !== null) ctx.rotate(burst.angle + Math.PI / 2);
        const rise = Math.sin(Math.PI * t) * 13;
        ctx.translate(0, -rise);
        const scale = burst.size * (.64 + .40 * easeOut(t));
        ctx.scale(scale, scale);
        ctx.fillStyle = burst.primary;
        ctx.strokeStyle = burst.secondary;
        ctx.lineWidth = 1.45;
        pet[0](ctx, t, burst);
      }
    }
    ctx.restore();
  }

  globalThis.PetalEffects = {
    styles,
    create,
    draw,
    lifetime: burst => burst.duration
  };
})();
