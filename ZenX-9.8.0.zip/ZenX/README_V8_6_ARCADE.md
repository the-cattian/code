# ZenX 8.6.0 — Optional Home Arcade

This release adds two *original implementations* of classic arcade games without modifying the existing Zendesk tickets, editor, macros, SLA engine, or agent availability features.

## Games

- **Dinosaur**: Press **Start**, then **Space**, **Up**, or **W** to jump. Hold **Down** or **S** to duck.
- **Snake**: Press **Start**, then use the **arrow keys** or **WASD**. On-screen arrow buttons are also available.
- Switch games with the **‹ / ›** buttons at the top of the panel.
- Each game has a **current score**, **high score**, and **last run score**. Scores are saved in `chrome.storage.local` and persist across browser restarts.
- Pause, resume, or restart using the panel buttons. Switching away, leaving Home, minimizing the browser, or receiving tickets stops the game.

## Display and controls

- Appears only when the active ZenX Home dashboard explicitly shows its **No tickets** empty state.
- The initial position is within the empty area below **Last 30 days** in the left Home navigation.
- Drag the panel **header** to move it, or the **bottom-right grip** to resize it. The saved size and position persist.
- Use the small power icon to turn the game panel off. To turn it back on, open the ZenX popup and enable **Home arcade**.
- The master **Enable ZenX** control also hides the arcade.
- Keyboard controls apply only when the game canvas has focus and do not capture keystrokes typed in Zendesk.

## Isolation

- Dedicated content script (`arcade.js`) and Shadow DOM stylesheet (`arcade.css`).
- No edits to Zendesk content, native navigation, ticket records, or ticket handlers.
- No new permissions or external network calls. Game scores are kept in extension-local storage.
- Existing source modules remain unchanged except the manifest and popup wiring.

## Tests

From the `ZenX` folder:

```sh
python tests/arcade-browser-regressions.py
python tests/home-status-regressions.py
python tests/editor-richtext-regressions.py
python tests/timer-macro-regressions.py
node tests/verify-parity.mjs
```

These tests use a local mock page. Test a real Zendesk Home screen after installing the updated unpacked extension, as Zendesk may change its Home markup.
