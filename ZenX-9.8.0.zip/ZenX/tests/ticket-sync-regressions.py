"""Regression: stale Zendesk top-tab entity ID must not override visible ticket context.
Mock reproduces screenshot: native breadcrumb #23592985, stale tab #21240764.
"""
from pathlib import Path
from playwright.sync_api import sync_playwright
import re
ROOT=Path(__file__).resolve().parent.parent
with sync_playwright() as p:
    browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
    page=browser.new_page(viewport={'width':1792,'height':860})
    errors=[]
    page.on('pageerror',lambda err:errors.append(str(err)))
    fixture=(ROOT/'tests/fixtures/nested.html').read_text()
    fixture=re.sub(r'<script\b[^>]*>.*?</script>', '', fixture, flags=re.S|re.I)
    fixture=re.sub(r'<link\b[^>]*rel="stylesheet"[^>]*>', '', fixture, flags=re.I).replace('<base href="/tester/">','')
    page.set_content(fixture)
    for name in ['tester/mock.css','styles.css','premium.css']:
        page.add_style_tag(content=(ROOT/name).read_text())
    shim=(ROOT/'tester/mock-shim.js').read_text().replace("new URL('../'+path,location.href).href", "'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVQIHWP4////fwAJ+wP+Y+9J5wAAAABJRU5ErkJggg=='")
    page.add_script_tag(content=shim)
    # Set up real displayed ticket *before* the extension initializes.
    page.evaluate('''() => {
      const tab=document.querySelector('#active-tab');
      tab.dataset.entityId='21240764';
      tab.querySelector('span').textContent='Aliyah Mckay';
      document.querySelector('#ticket-header').textContent='Open ticket #23592985';
      const root=document.querySelector('#mock-messages');
      const agent=document.createElement('article');
      agent.dataset.testId='omni-log-comment-item'; agent.dataset.eventId='agent-1';
      const box=document.createElement('div');box.dataset.testId='omni-log-item-message';box.setAttribute('type','agent');
      const txt=document.createElement('div'); txt.dataset.testId='omni-log-message-content';
      txt.textContent='I am reviewing the account. Please allow 3-5 minutes.';
      const t=document.createElement('time');t.dataset.testId='timestamp-relative';t.textContent='just now';
      box.appendChild(txt);agent.append(t,box);root.appendChild(agent);
    }''')
    for name in ['editor-bridge.js','content.js','themes.js','theme.js','workspace.js','app-frames.js','chrome-glass.js','effects.js']:
        page.add_script_tag(content=(ROOT/name).read_text())
    page.wait_for_selector('#zd-floating-sla-timer')
    page.wait_for_selector('#active-tab > .zenx-tab-sla-badge')
    def get_state():
        return page.evaluate('() => new Promise(r=>chrome.runtime.__send({type:"GET_STATUS"},r))')['slaState']
    state=get_state()
    assert state['ticketId']=='23592985',state
    assert state['rule']=='hold',state
    assert '#23592985' in page.locator('#zd-timer-ticket').text_content(),page.locator('#zd-timer-ticket').text_content()
    assert page.locator('#active-tab').get_attribute('data-entity-id')=='21240764'
    print('PASS correct displayed ticket ID wins over stale native tab attribute')
    top=page.locator('#active-tab > .zenx-tab-sla-badge')
    first=top.inner_text()
    assert re.match(r'(?:4:[0-5]\d|5:00)$',first),first
    page.wait_for_timeout(1400)
    second=top.inner_text()
    assert int(second.split(':')[0])*60+int(second.split(':')[1]) < int(first.split(':')[0])*60+int(first.split(':')[1]),(first,second)
    print('PASS active top-tab countdown decreases each second')
    page.evaluate('''() => {
      const a=document.createElement('article');a.dataset.testId='omni-log-comment-item';a.dataset.eventId='agent-2';
      const box=document.createElement('div');box.dataset.testId='omni-log-item-message';box.setAttribute('type','agent');
      const txt=document.createElement('div');txt.dataset.testId='omni-log-message-content';txt.textContent='I am checking now';
      box.appendChild(txt);a.appendChild(box);document.querySelector('#mock-messages').appendChild(a);
    }''')
    page.wait_for_timeout(1200)
    state=get_state()
    assert state['ticketId']=='23592985' and state['rule']=='general',state
    assert re.match(r'(?:1:[0-5]\d|2:00)$',top.inner_text()),top.inner_text()
    print('PASS top tab refreshes on a new agent response; no permanent 0:00')
    # Explicit manual reset stays independent from the floating pill.
    page.wait_for_timeout(1400)
    pill_before=get_state()['remainingSec']
    top.click()
    page.wait_for_timeout(180)
    assert top.inner_text() in ('2:00','1:59'),top.inner_text()
    page.wait_for_timeout(1150)
    assert top.inner_text() in ('1:58','1:59'),top.inner_text()
    pill_after=get_state()['remainingSec']
    assert pill_after < pill_before,(pill_before,pill_after)
    print('PASS top-tab manual reset persists without resetting floating pill')
    # Switch Zendesk header to another ticket, while tab attribute remains stale.
    page.evaluate('''() => {
      document.querySelector('#ticket-header').textContent='Open ticket #23593001';
      document.querySelector('#mock-messages').replaceChildren();
    }''')
    page.wait_for_timeout(1100)
    state=get_state()
    assert state['ticketId']=='23593001',state
    assert page.locator('#zd-timer-ticket').text_content()=='#23593001'
    assert re.match(r'(?:0:[0-5]\d|1:00)$',top.inner_text()),top.inner_text()
    print('PASS switching active ticket updates pill and tab without stale ticket reuse')
    assert not errors,errors
    print('PASS no uncaught browser errors')
    browser.close()
