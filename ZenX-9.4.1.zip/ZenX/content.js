// ZenX reconstructed directly from the supplied, functional bookmarklet v1.9.
// SLA rules and message parsing have been carried across verbatim.
(() => {
const ID = 'hamza-zendesk-dark-skin-v2'; const FILTER_ATTR = 'data-zs-panel-dark'; // The saved premium theme remains selected while ZenX is disabled. Its CSS
// class is temporarily absent during re-enable, so a class-only test races.
function zenxPremiumOwnsSurfaces() {
  // Unknown means the theme script has not loaded yet; defer the classic
  // painter rather than risk staining premium surfaces on first activation.
  return globalThis.__zenxPremiumThemeSelected !== false ||
    document.documentElement?.classList.contains('zenx-premium') === true;
}
const PROCESSED_ATTR = 'data-hamza-zskin-processed'; const safeStorage = { getItem(key) { try { if (window.localStorage) { const v = window.localStorage.getItem(key); if (v !== null && v !== undefined) return v; } } catch(e) {} try { if (window.sessionStorage) { const v = window.sessionStorage.getItem(key); if (v !== null && v !== undefined) return v; } } catch(e) {} try { const m = document.cookie.match(new RegExp('(?:^|; )' + encodeURIComponent(key) + '=([^;]*)')); if (m) return decodeURIComponent(m[1]); } catch(e) {} return null; }, setItem(key, value) { try { window.localStorage && window.localStorage.setItem(key, value); } catch(e) {} try { window.sessionStorage && window.sessionStorage.setItem(key, value); } catch(e) {} try { document.cookie = encodeURIComponent(key) + '=' + encodeURIComponent(value) + '; path=/; max-age=31536000; SameSite=Lax'; } catch(e) {} } }; const docMap = new Map(); let intervalId = 0; const THEME_KEY = 'zd_theme_mode'; let darkMode = (() => { try { const saved = safeStorage.getItem(THEME_KEY); if (saved === 'light') return false; if (saved === 'dark') return true; } catch(e) {} return true; })(); const clamp = (val, min, max) => Math.min(max, Math.max(min, val)); const toRgba = (c, a) => `rgba(${Math.round(c.r)},${Math.round(c.g)},${Math.round(c.b)},${a})`; function parseColor(str) { if (!str || str === 'transparent') return null; let m = str.match(/rgba?\(([^)]+)\)/i); if (!m) return null; let parts = m[1].split(/[\s,\/]+/).map(Number); if (parts.length < 3 || parts.some(isNaN)) return null; return { r: parts[0], g: parts[1], b: parts[2], a: parts.length > 3 ? clamp(parts[3], 0, 1) : 1 }; } const sRGBToLinear = c => (c /= 255, c <= 0.03928 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4)); const getLuminance = c => 0.2126 * sRGBToLinear(c.r) + 0.7152 * sRGBToLinear(c.g) + 0.0722 * sRGBToLinear(c.b); function rgbToHsl(r, g, b) { r /= 255; g /= 255; b /= 255; let max = Math.max(r, g, b), min = Math.min(r, g, b); let h = 0, s = 0, l = (max + min) / 2; if (max !== min) { let d = max - min; s = l > 0.5 ? d / (2 - max - min) : d / (max + min); if (max === r) h = (g - b) / d + (g < b ? 6 : 0); else if (max === g) h = (b - r) / d + 2; else h = (r - g) / d + 4; h *= 60; } return { h, s, l }; } function hslToRgb(h, s, l) { h = (h % 360 + 360) % 360 / 360; let q = l < 0.5 ? l * (1 + s) : l + s - l * s; let p = 2 * l - q; let hue2rgb = t => { t = (t % 1 + 1) % 1; if (t < 1/6) return p + (q - p) * 6 * t; if (t < 1/2) return q; if (t < 2/3) return p + (q - p) * (2/3 - t) * 6; return p; }; return { r: hue2rgb(h + 1/3) * 255, g: hue2rgb(h) * 255, b: hue2rgb(h - 1/3) * 255 }; } function darkBg(rgb, depth) { let { h, s, l } = rgbToHsl(rgb.r, rgb.g, rgb.b); if (h >= 30 && h <= 65 && l > 0.6) { return hslToRgb(38, 0.15, 0.11); } if (s < 0.22) { let lightness = [0.09, 0.13, 0.17]; return hslToRgb(h, Math.min(s + 0.04, 0.08), lightness[clamp(depth - 1, 0, 2)]); } return hslToRgb(h, clamp(s * 0.45, 0.15, 0.35), clamp(0.05 + l * 0.2, 0.09, 0.2)); } function darkBorder(rgb) { let { h, s, l } = rgbToHsl(rgb.r, rgb.g, rgb.b); return hslToRgb(h, Math.min(s, 0.2), clamp(0.14 + (l - 0.5) * 0.32, 0.14, 0.34)); } function lightText(rgb) { let { h, s, l } = rgbToHsl(rgb.r, rgb.g, rgb.b); return hslToRgb(h, clamp(s, 0, 0.55), clamp(0.72 + 0.26 * l, 0.72, 0.97)); } function lightFill(rgb) { let { h, s, l } = rgbToHsl(rgb.r, rgb.g, rgb.b); return hslToRgb(h, clamp(s, 0, 0.4), clamp(0.62 + 0.3 * l, 0.62, 0.92)); } function collectDocs(rootDoc, acc) { acc.push(rootDoc); let frames = []; try { frames = rootDoc.querySelectorAll('iframe'); } catch(e) {} for (let f of frames) { let d = null; try { d = f.contentDocument; } catch(e) {} if (d && d.body) collectDocs(d, acc); } return acc; } function injectLayoutAndColorCss(doc) { try { let sheet = new doc.defaultView.CSSStyleSheet(); sheet.replaceSync(` html.zskin-active [class*="pane"], html.zskin-active [class*="Sidebar"] { padding: 12px !important; gap: 12px !important; } html.zskin-active input, html.zskin-active select, html.zskin-active textarea { border-radius: 6px !important; } html.zskin-active [class*="tag"], html.zskin-active [class*="token"], html.zskin-active [class*="pill"] { border-radius: 12px !important; padding: 3px 8px !important; margin: 2px !important; display: inline-flex !important; align-items: center !important; } html.zskin-active [data-zd-hidden-tags="true"], html.zskin-active [data-zd-hidden-also-here="true"], html.zskin-active [data-zd-hidden-divider="true"], html.zskin-active [data-zd-hidden-custom] { display: none !important; visibility: hidden !important; height: 0 !important; margin: 0 !important; padding: 0 !important; border: none !important; overflow: hidden !important; } html.zskin-active article[data-test-id="omni-log-comment-item"] { background: transparent !important; border: none !important; padding: 4px 20px !important; margin: 3px 0 !important; display: flex !important; width: 100% !important; box-sizing: border-box !important; position: relative !important; } html.zskin-active article[data-test-id="omni-log-comment-item"] [data-test-id="omni-log-comment-avatar"], html.zskin-active article[data-test-id="omni-log-comment-item"] [data-test-id="omni-log-base-avatar"], html.zskin-active article[data-test-id="omni-log-comment-item"] [data-test-id="omni-log-comment-header"], html.zskin-active article[data-test-id="omni-log-comment-item"] [data-test-id="omni-log-item-sender"], html.zskin-active article[data-test-id="omni-log-comment-item"] [data-test-id="convo-log-item-authenticated-indicator"], html.zskin-active article[data-test-id="omni-log-comment-item"] [data-test-id="omni-log-item-originated-from"], html.zskin-active article[data-test-id="omni-log-comment-item"] [data-test-id="timestamp-relative"], html.zskin-active article[data-test-id="omni-log-comment-item"] [data-test-id="timestamp-absolute"], html.zskin-active article[data-test-id="omni-log-comment-item"] h4, html.zskin-active article[data-test-id="omni-log-comment-item"] [class*="sc-71ab6acd-2"], html.zskin-active article[data-test-id="omni-log-comment-item"] [class*="sc-71ab6acd-3"], html.zskin-active article[data-test-id="omni-log-comment-item"] [class*="sc-71ab6acd-7"], html.zskin-active article[data-test-id="omni-log-comment-item"] [class*="sc-71ab6acd-8"], html.zskin-active article[data-test-id="omni-log-comment-item"] > div:not([data-test-id="omni-log-omni-to-ag-comment"]):not([class*="sc-71ab6acd-4"]) { display: none !important; width: 0 !important; height: 0 !important; margin: 0 !important; padding: 0 !important; border: none !important; visibility: hidden !important; } html.zskin-active article[data-test-id="omni-log-comment-item"] [data-test-id="omni-log-omni-to-ag-comment"], html.zskin-active article[data-test-id="omni-log-comment-item"] [class*="sc-71ab6acd-4"] { display: flex !important; flex-direction: column !important; width: 100% !important; max-width: 100% !important; background: transparent !important; border: none !important; padding: 0 !important; margin: 0 !important; } html.zskin-active article[data-test-id="omni-log-comment-item"] [data-test-id="omni-log-omni-to-ag-comment"] > div { display: flex !important; flex-direction: column !important; width: 100% !important; background: transparent !important; } html.zskin-active article[data-chat-role="customer"], html.zskin-active article[data-chat-role="bot"] { flex-direction: row !important; justify-content: flex-start !important; } html.zskin-active article[data-chat-role="customer"] [data-test-id="omni-log-omni-to-ag-comment"], html.zskin-active article[data-chat-role="bot"] [data-test-id="omni-log-omni-to-ag-comment"], html.zskin-active article[data-chat-role="customer"] [data-test-id="omni-log-omni-to-ag-comment"] > div, html.zskin-active article[data-chat-role="bot"] [data-test-id="omni-log-omni-to-ag-comment"] > div { align-items: flex-start !important; } html.zskin-active article[data-chat-role="customer"] [data-test-id="omni-log-item-message"], html.zskin-active article[data-chat-role="bot"] [data-test-id="omni-log-item-message"] { align-self: flex-start !important; margin-right: auto !important; margin-left: 0 !important; border-radius: 12px 12px 12px 4px !important; padding: 8px 12px 22px 12px !important; max-width: 78% !important; position: relative !important; display: flex !important; flex-direction: column !important; text-align: left !important; } html.zskin-active article[data-chat-role="agent"] { flex-direction: row !important; justify-content: flex-end !important; } html.zskin-active article[data-chat-role="agent"] [data-test-id="omni-log-omni-to-ag-comment"], html.zskin-active article[data-chat-role="agent"] [data-test-id="omni-log-omni-to-ag-comment"] > div { align-items: flex-end !important; } html.zskin-active article[data-chat-role="agent"] [data-test-id="omni-log-item-message"] { align-self: flex-end !important; margin-left: auto !important; margin-right: 0 !important; border-radius: 12px 12px 4px 12px !important; padding: 8px 12px 22px 12px !important; max-width: 78% !important; position: relative !important; display: flex !important; flex-direction: column !important; text-align: left !important; } html.zskin-active [data-test-id="omni-log-item-message"]::before { content: attr(data-sender-name); font-weight: 700; font-size: 11px; margin-bottom: 3px; display: block; opacity: 0.95; } html.zskin-active [data-test-id="omni-log-item-message"]:not([data-sender-name])::before, html.zskin-active [data-test-id="omni-log-item-message"][data-sender-name=""]::before { display: none !important; } html.zskin-active [data-test-id="omni-log-item-message"]::after { content: attr(data-msg-time); font-size: 10px; position: absolute; bottom: 4px; right: 10px; opacity: 0.75; font-family: inherit; } html.zskin-active [data-test-id="omni-log-item-message"]:not([data-msg-time])::after, html.zskin-active [data-test-id="omni-log-item-message"][data-msg-time=""]::after { display: none !important; } html.zskin-active [data-test-id="omni-log-message-content"] { word-break: break-word !important; overflow-wrap: break-word !important; white-space: pre-wrap !important; line-height: 1.45 !important; font-size: 13.5px !important; } html.zskin-active article[data-chat-role="internal"] { border-left: 4px solid #f59e0b !important; border-radius: 10px !important; padding: 12px 16px !important; margin: 8px 14px !important; } html.zskin-active article[data-chat-role="internal"] [data-test-id="omni-log-item-message"] { background: transparent !important; border: none !important; box-shadow: none !important; padding: 4px 0 0 0 !important; max-width: 100% !important; } html.zskin-light [data-test-id="component-type-MainConversationPane"], html.zskin-light [data-test-id="ticket-main-conversation"], html.zskin-light [data-test-id="omni-log-container"] { background: #f0f2f5 !important; } html.zskin-light article[data-chat-role="customer"] [data-test-id="omni-log-item-message"] { background: #ffffff !important; color: #111b21 !important; border: 1px solid #e2e8f0 !important; box-shadow: 0 1px 2px rgba(0, 0, 0, 0.08) !important; } html.zskin-light article[data-chat-role="customer"] [data-test-id="omni-log-item-message"] * { color: #111b21 !important; } html.zskin-light article[data-chat-role="customer"] [data-test-id="omni-log-item-message"]::before { color: #0284c7 !important; } html.zskin-light article[data-chat-role="customer"] [data-test-id="omni-log-item-message"]::after { color: #64748b !important; } html.zskin-light article[data-chat-role="agent"] [data-test-id="omni-log-item-message"] { background: linear-gradient(135deg, #d9fdd3 0%, #cbf8c1 100%) !important; color: #111b21 !important; border: 1px solid rgba(0, 128, 105, 0.22) !important; box-shadow: 0 1px 3px rgba(0, 128, 105, 0.12) !important; } html.zskin-light article[data-chat-role="agent"] [data-test-id="omni-log-item-message"] * { color: #111b21 !important; } html.zskin-light article[data-chat-role="agent"] [data-test-id="omni-log-item-message"]::before { color: #0f5132 !important; } html.zskin-light article[data-chat-role="agent"] [data-test-id="omni-log-item-message"]::after { color: #3b5a45 !important; } html.zskin-light article[data-chat-role="bot"] [data-test-id="omni-log-item-message"] { background: #f1f5f9 !important; color: #1e293b !important; border: 1px solid #cbd5e1 !important; box-shadow: 0 1px 2px rgba(0, 0, 0, 0.06) !important; } html.zskin-light article[data-chat-role="bot"] [data-test-id="omni-log-item-message"] * { color: #1e293b !important; } html.zskin-light article[data-chat-role="bot"] [data-test-id="omni-log-item-message"]::before { color: #4338ca !important; } html.zskin-light article[data-chat-role="bot"] [data-test-id="omni-log-item-message"]::after { color: #64748b !important; } html.zskin-light article[data-chat-role="internal"] { background: #fffbeb !important; border: 1px solid #fde68a !important; box-shadow: 0 2px 6px rgba(245, 158, 11, 0.1) !important; color: #1f2937 !important; } html.zskin-light article[data-chat-role="internal"] [data-test-id="omni-log-item-message"] * { color: #1f2937 !important; } html.zskin-light [data-test-id="omni-log-internal-note-tag"] { background: #fef3c7 !important; color: #b45309 !important; border: 1px solid #fcd34d !important; font-weight: 700 !important; font-size: 11px !important; border-radius: 6px !important; padding: 2px 8px !important; text-transform: uppercase !important; } html.zskin-dark { color-scheme: dark; --zs-bg: rgb(14, 17, 22); --zs-surface: rgb(21, 27, 35); --zs-surface2: rgb(29, 37, 48); --zs-border: rgb(44, 55, 69); --zs-text: rgb(230, 237, 243); --zs-muted: rgb(159, 177, 195); --zs-accent: rgb(77, 163, 255); accent-color: var(--zs-accent); --zd-agent-gradient: linear-gradient(135deg, #005c4b 0%, #008069 100%); --zd-customer-bubble: #1e293b; --zd-bot-bubble: #182033; --zd-internal-bg: #151821; --zd-internal-border: rgba(245, 158, 11, 0.32); } html.zskin-dark, html.zskin-dark body { background: var(--zs-bg) !important; color: var(--zs-text) !important; } html.zskin-dark input:not([type=checkbox]):not([type=radio]):not([type=range]):not([type=button]):not([type=submit]):not([type=reset]), html.zskin-dark textarea, html.zskin-dark select, html.zskin-dark [contenteditable="true"], html.zskin-dark [data-test-id*="input"], html.zskin-dark [data-test-id*="editor"] { background: var(--zs-surface2) !important; color: var(--zs-text) !important; border-color: var(--zs-border) !important; -webkit-text-fill-color: var(--zs-text) !important; } html.zskin-dark input::placeholder, html.zskin-dark textarea::placeholder { color: var(--zs-muted) !important; -webkit-text-fill-color: var(--zs-muted) !important; } html.zskin-dark option { background: var(--zs-surface2); color: var(--zs-text); } html.zskin-dark ::selection { background: rgb(46, 93, 142); color: rgb(255, 255, 255); } html.zskin-dark * { scrollbar-width: thin; scrollbar-color: rgb(85, 101, 125) transparent; } html.zskin-dark *::-webkit-scrollbar { width: 10px; height: 10px; } html.zskin-dark *::-webkit-scrollbar-thumb { background: rgb(85, 101, 125); border-radius: 8px; border: 2px solid transparent; background-clip: padding-box; } html.zskin-dark *::-webkit-scrollbar-track { background: transparent; } html.zskin-dark :focus-visible { outline: 2px solid var(--zs-accent) !important; outline-offset: 1px; } html.zskin-dark [data-test-id="component-type-MainConversationPane"], html.zskin-dark [data-test-id="ticket-main-conversation"], html.zskin-dark [data-test-id="omni-log-container"] { background: var(--zs-bg) !important; } html.zskin-dark article[data-chat-role="customer"] [data-test-id="omni-log-item-message"] { background: var(--zd-customer-bubble) !important; color: #f1f5f9 !important; border: 1px solid rgba(255, 255, 255, 0.08) !important; box-shadow: 0 2px 6px rgba(0, 0, 0, 0.3) !important; } html.zskin-dark article[data-chat-role="customer"] [data-test-id="omni-log-item-message"] * { color: #f1f5f9 !important; } html.zskin-dark article[data-chat-role="customer"] [data-test-id="omni-log-item-message"]::before { color: #93c5fd !important; } html.zskin-dark article[data-chat-role="customer"] [data-test-id="omni-log-item-message"]::after { color: #94a3b8 !important; } html.zskin-dark article[data-chat-role="agent"] [data-test-id="omni-log-item-message"] { background: var(--zd-agent-gradient) !important; color: #ffffff !important; border: 1px solid rgba(255, 255, 255, 0.2) !important; box-shadow: 0 4px 14px rgba(0, 128, 105, 0.35) !important; } html.zskin-dark article[data-chat-role="agent"] [data-test-id="omni-log-item-message"] * { color: #ffffff !important; } html.zskin-dark article[data-chat-role="agent"] [data-test-id="omni-log-item-message"]::before { color: #bbf7d0 !important; } html.zskin-dark article[data-chat-role="agent"] [data-test-id="omni-log-item-message"]::after { color: rgba(255, 255, 255, 0.75) !important; } html.zskin-dark article[data-chat-role="bot"] [data-test-id="omni-log-item-message"] { background: var(--zd-bot-bubble) !important; color: #e2e8f0 !important; border: 1px solid rgba(99, 102, 241, 0.28) !important; box-shadow: 0 2px 6px rgba(0, 0, 0, 0.25) !important; } html.zskin-dark article[data-chat-role="bot"] [data-test-id="omni-log-item-message"] * { color: #e2e8f0 !important; } html.zskin-dark article[data-chat-role="bot"] [data-test-id="omni-log-item-message"]::before { color: #a5b4fc !important; } html.zskin-dark article[data-chat-role="bot"] [data-test-id="omni-log-item-message"]::after { color: #94a3b8 !important; } html.zskin-dark article[data-chat-role="internal"] { background: var(--zd-internal-bg) !important; border: 1px solid var(--zd-internal-border) !important; border-left: 4px solid #f59e0b !important; color: #f1f5f9 !important; box-shadow: 0 4px 12px rgba(0, 0, 0, 0.35) !important; } html.zskin-dark article[data-chat-role="internal"] [data-test-id="omni-log-item-message"] * { color: #f1f5f9 !important; } html.zskin-dark [data-test-id="omni-log-internal-note-tag"] { background: rgba(245, 158, 11, 0.2) !important; color: #fbbf24 !important; border: 1px solid rgba(245, 158, 11, 0.45) !important; font-weight: 700 !important; font-size: 11px !important; border-radius: 6px !important; padding: 2px 8px !important; text-transform: uppercase !important; } `); let adopted = doc.adoptedStyleSheets ? Array.from(doc.adoptedStyleSheets) : []; if (!adopted.includes(sheet)) doc.adoptedStyleSheets = adopted.concat(sheet); return sheet; } catch(e) { let st = doc.createElement('style'); st.id = ID; st.textContent = ``; (doc.head || doc.documentElement).appendChild(st); return null; } } function resolveEffectiveBg(el, cache, defaultView) { let chain = [], curr = el; while (curr && curr.nodeType === 1) { let c = cache.get(curr); if (c === undefined) { c = parseColor(defaultView.getComputedStyle(curr).backgroundColor); cache.set(curr, c); } chain.push(c); if (c && c.a >= 0.999) break; curr = curr.parentElement; } let res = null; for (let i = chain.length - 1; i >= 0; i--) { let bg = chain[i]; if (!bg) continue; if (!res) { if (bg.a >= 0.999) res = { r: bg.r, g: bg.g, b: bg.b }; continue; } if (bg.a > 0) res = { r: bg.r * bg.a + res.r * (1 - bg.a), g: bg.g * bg.a + res.g * (1 - bg.a), b: bg.b * bg.a + res.b * (1 - bg.a) }; } if (!res) res = { r: 255, g: 255, b: 255 }; let lightCount = 0; for (let c of chain) if (c && getLuminance(c) > 0.5) lightCount++; return { rgb: res, lum: getLuminance(res), depth: lightCount }; } const SKIP_TAGS = new Set(["IMG","VIDEO","AUDIO","CANVAS","SOURCE","TRACK","PICTURE","IFRAME","OBJECT","EMBED","SCRIPT","STYLE","LINK","META","NOSCRIPT","TEMPLATE","BASE","TITLE","HEAD","BR","WBR","HR","MAP","AREA","DATALIST","PARAM"]); const SVG_NS = "http://www.w3.org/2000/svg"; function setZsProp(el, prop, val, storeMap) { let props = storeMap.get(el); if (!props) { props = new Map(); storeMap.set(el, props); } if (!props.has(prop)) props.set(prop, { original: el.style.getPropertyValue(prop), priority: el.style.getPropertyPriority(prop), applied: '' }); el.setAttribute(PROCESSED_ATTR, "1"); el.style.setProperty(prop, val, "important"); props.get(prop).applied = el.style.getPropertyValue(prop); }
function restoreZsStyles(storeMap) { for (const [el, props] of storeMap) for (const [name, old] of props) { try { if (el.style.getPropertyValue(name) !== old.applied || el.style.getPropertyPriority(name) !== 'important') continue; if (old.original) el.style.setProperty(name, old.original, old.priority); else el.style.removeProperty(name); } catch(e) {} } storeMap.clear(); }
function processElement(el, win, bgCache, storeMap) { // Premium themes own all of their surfaces. The legacy blanket darkener must not repaint them on toggles.
if (zenxPremiumOwnsSurfaces()) return;
if (el.hasAttribute && el.hasAttribute(PROCESSED_ATTR)) return; if (el.closest && el.closest('#zd-floating-sla-timer')) { el.setAttribute(PROCESSED_ATTR, "1"); return; } let isSvg = el.namespaceURI === SVG_NS; if (!isSvg && SKIP_TAGS.has(el.tagName)) { el.setAttribute(PROCESSED_ATTR, "1"); return; } let style = win.getComputedStyle(el); if (style.display === "none" || style.visibility === "hidden") return; if (isSvg) { for (let attr of ["fill", "stroke"]) { let c = parseColor(style[attr]); if (c && c.a > 0.2 && getLuminance(c) < 0.35) setZsProp(el, attr, toRgba(lightFill(c), 1), storeMap); } el.setAttribute(PROCESSED_ATTR, "1"); return; } if (el.closest && (el.closest('[data-chat-role]') || el.closest('[data-test-id="omni-log-item-message"]'))) { el.setAttribute(PROCESSED_ATTR, "1"); return; } let bgInfo = resolveEffectiveBg(el, bgCache, win); let hasBgImg = style.backgroundImage && style.backgroundImage !== "none"; let currentLum = bgInfo.lum; if (!hasBgImg && bgInfo.lum > 0.5) { let newRgb = darkBg(bgInfo.rgb, bgInfo.depth); setZsProp(el, "background-color", toRgba(newRgb, 1), storeMap); currentLum = getLuminance(newRgb); } for (let side of ["Top", "Right", "Bottom", "Left"]) { let bColor = parseColor(style["border" + side + "Color"]); if (bColor && bColor.a > 0.2 && getLuminance(bColor) > 0.5) { setZsProp(el, "border-" + side.toLowerCase() + "-color", toRgba(darkBorder(bColor), bColor.a), storeMap); } } let fgColor = parseColor(style.color); if (fgColor && fgColor.a > 0.2 && getLuminance(fgColor) < 0.45 && currentLum < 0.42) { setZsProp(el, "color", toRgba(lightText(fgColor), fgColor.a), storeMap); } el.setAttribute(PROCESSED_ATTR, "1"); } function batchProcess(list, doc, record) { let win = doc.defaultView, bgCache = new WeakMap(), idx = 0; record.running = true; let step = () => { if (!darkMode || zenxPremiumOwnsSurfaces()) { record.running = false; return; } let limit = Math.min(idx + 300, list.length); for (; idx < limit; idx++) { try { processElement(list[idx], win, bgCache, record.styles); } catch(e) {} } if (idx < list.length) setTimeout(step, 0); else { record.running = false; if (record.pending.size) scheduleBatch(doc); } }; step(); } function runTreeWalker(doc) { let record = docMap.get(doc); if (!record || record.running || zenxPremiumOwnsSurfaces()) return; let nodes = [], walker = doc.createTreeWalker(doc.documentElement, NodeFilter.SHOW_ELEMENT), node; while (node = walker.nextNode()) { if (!(node.hasAttribute && node.hasAttribute(PROCESSED_ATTR))) nodes.push(node); } if (nodes.length) batchProcess(nodes, doc, record); } function scheduleBatch(doc) { let record = docMap.get(doc); if (!record) return; clearTimeout(record.timer); record.timer = setTimeout(() => processPending(doc), 160); } function processPending(doc) { let record = docMap.get(doc); if (!record) return; if (!darkMode || zenxPremiumOwnsSurfaces()) { record.pending.clear(); return; } if (scanAllDocs(), record.running) { record.timer = setTimeout(() => processPending(doc), 200); return; } if (!record.pending.size) return; let list = [], visited = new Set(); for (let root of record.pending) { if (!root || root.nodeType !== 1 || visited.has(root)) continue; if (!(root.hasAttribute && root.hasAttribute(PROCESSED_ATTR))) { visited.add(root); list.push(root); } let walker = doc.createTreeWalker(root, NodeFilter.SHOW_ELEMENT), n; while (n = walker.nextNode()) { if (!visited.has(n) && !(n.hasAttribute && n.hasAttribute(PROCESSED_ATTR))) { visited.add(n); list.push(n); } } } record.pending.clear(); if (list.length) batchProcess(list, doc, record); } function attachObserver(doc) { let record = docMap.get(doc); if (!record || record.obs) return; let obs = new MutationObserver(mutations => { let rec = docMap.get(doc); if (!rec) return; let hasAdded = false; for (let m of mutations) { if (m.type === "childList") { for (let node of m.addedNodes) { if (node.nodeType === 1) { if (darkMode && !zenxPremiumOwnsSurfaces()) rec.pending.add(node); hasAdded = true; } } } } if (hasAdded) { if (rec.tagTimer) clearTimeout(rec.tagTimer); rec.tagTimer = setTimeout(() => { tagAllMessages(doc); hideLeftPanelSections(doc); }, 50); if (darkMode && !zenxPremiumOwnsSurfaces()) scheduleBatch(doc); } }); obs.observe(doc.documentElement, { childList: true, subtree: true }); record.obs = obs; } function classifyMessage(article, prevRole) { if (article.querySelector('[data-test-id="omni-log-internal-note-tag"]')) { return 'internal'; } const msgBox = article.querySelector('[data-test-id="omni-log-item-message"]'); if (msgBox) { const type = msgBox.getAttribute('type'); if (type === 'agent') return 'agent'; if (type === 'end-user') return 'customer'; if (type === 'bot') return 'bot'; if (type === 'internal') return 'internal'; } const hasAgentBadge = !!article.querySelector('[data-test-id="omni-log-avatar-badge-AgentBadge"]'); if (hasAgentBadge) return 'agent'; const senderEl = article.querySelector('[data-test-id="omni-log-item-sender"]'); const senderText = senderEl ? senderEl.textContent.trim().toLowerCase() : ''; if (senderText.includes('virtual assistant') || senderText.includes('bot') || senderText.includes('support bot')) { return 'bot'; } if (senderText.includes('arvin') || senderText.includes('hamza')) { return 'agent'; } if (senderText) { return 'customer'; } if (prevRole && prevRole !== 'internal') { return prevRole; } return 'customer'; } const SECTIONS_KEY = 'zd_hidden_sections'; let hiddenSections = (() => { try { let v = JSON.parse(safeStorage.getItem(SECTIONS_KEY)); if (Array.isArray(v)) return v.filter(x => typeof x === 'string'); } catch(e) {} return ['Tags', 'Also here']; })(); const saveHiddenSections = () => { try { safeStorage.setItem(SECTIONS_KEY, JSON.stringify(hiddenSections)); } catch(e) {} }; const normName = n => String(n || '').toLowerCase().trim(); const isHiddenName = n => hiddenSections.some(h => normName(h) === normName(n)); function findLeftPanes(doc) { const panes = []; try { const candidates = doc.querySelectorAll( '[data-test-id="component-type-TicketFieldsPane"], #ticket_sidebar, .grid-ticket-fields-panel, [data-test-id="column-1"], .ticket-panes-grid-layout > div:first-child' ); candidates.forEach(pane => { if (pane && !pane.querySelector('article[data-test-id="omni-log-comment-item"]')) { if (!panes.includes(pane)) panes.push(pane); } }); } catch(e) {} return panes; } function getSectionCols(doc) { const out = []; const panes = findLeftPanes(doc); const seenCols = new Set(); panes.forEach(pane => { let cols = []; try { cols = pane.querySelectorAll('[data-garden-id="grid.col"]'); } catch(e) {} cols.forEach(col => { try { if (seenCols.has(col)) return; if (col.closest('#' + TIMER_ID)) return; if (col.querySelector('[data-garden-id="grid.col"], [data-garden-id="grid.row"]')) return; if (col.querySelector('article, [data-test-id^="omni-log"], [contenteditable="true"]')) return; if (col.querySelector('[data-test-id="ticket-fields-tags"]')) return; let lbl = col.querySelector('label, legend, h3, h4, h5, [data-garden-id*="label"]'); let txt = lbl ? lbl.textContent.replace(/[*:]/g, '').trim() : ''; if (!txt) { const firstSpan = col.querySelector('span, div'); if (firstSpan && firstSpan.childNodes.length === 1 && firstSpan.childNodes[0].nodeType === 3) { txt = firstSpan.textContent.replace(/[*:]/g, '').trim(); } } if (txt && txt.length > 1 && txt.length < 35) { seenCols.add(col); out.push({ col, name: txt }); } } catch(e) {} }); }); return out; } function hideLeftPanelSections(doc) { if (!doc) return; try { const hideTags = isHiddenName('Tags'); const tagEls = []; doc.querySelectorAll('[data-test-id="ticket-fields-tags"]').forEach(tagField => { tagEls.push(tagField.closest('[data-garden-id="grid.col"]') || tagField.parentElement || tagField); }); doc.querySelectorAll('[data-test-id="ticket-system-field-tags-label"], [data-test-id="ticket-system-field-tags-multiselect"]').forEach(el => tagEls.push(el)); tagEls.forEach(el => { if (!el) return; if (hideTags) { el.style.setProperty('display', 'none', 'important'); el.setAttribute('data-zd-hidden-tags', 'true'); } else if (el.hasAttribute('data-zd-hidden-tags')) { el.style.removeProperty('display'); el.removeAttribute('data-zd-hidden-tags'); } }); } catch(e) {} try { const hideAlso = isHiddenName('Also here'); const leftPanes = findLeftPanes(doc); const searchRoots = leftPanes.length ? leftPanes : [doc.body]; searchRoots.forEach(leftPane => { if (!leftPane) return; const walker = doc.createTreeWalker(leftPane, NodeFilter.SHOW_TEXT, null, false); let node; const candidates = []; while ((node = walker.nextNode())) { const text = (node.textContent || '').trim().toLowerCase(); if ((text === 'also here' || text.startsWith('also here')) && node.parentElement && !node.parentElement.closest('#' + TIMER_ID)) { candidates.push(node.parentElement); } } candidates.forEach(el => { let container = el; while (container && container.parentElement) { const parent = container.parentElement; if (parent === leftPane || parent === doc.body || parent.id === 'ticket_sidebar' || (parent.className && typeof parent.className === 'string' && parent.className.includes('grid-ticket-fields-panel')) || parent.getAttribute('data-test-id') === 'component-type-TicketFieldsPane') { break; } const parentText = parent.textContent || ''; if (parentText.includes('Brand') || parentText.includes('Assignee') || parentText.includes('Followers') || parentText.includes('Ticket fields')) { break; } container = parent; } if (!container) return; const next = container.nextElementSibling; if (hideAlso) { container.style.setProperty('display', 'none', 'important'); container.setAttribute('data-zd-hidden-also-here', 'true'); if (next && (next.tagName === 'HR' || next.getAttribute('data-garden-id') === 'divider' || (next.clientHeight && next.clientHeight <= 3))) { next.style.setProperty('display', 'none', 'important'); next.setAttribute('data-zd-hidden-divider', 'true'); } } else { container.style.removeProperty('display'); container.removeAttribute('data-zd-hidden-also-here'); if (next && next.hasAttribute('data-zd-hidden-divider')) { next.style.removeProperty('display'); next.removeAttribute('data-zd-hidden-divider'); } } }); }); } catch(e) {} try { getSectionCols(doc).forEach(({ col, name }) => { if (isHiddenName(name)) { col.style.setProperty('display', 'none', 'important'); col.setAttribute('data-zd-hidden-custom', name); } else if (col.hasAttribute('data-zd-hidden-custom')) { col.style.removeProperty('display'); col.removeAttribute('data-zd-hidden-custom'); } }); } catch(e) {} } function applyAllSectionVisibility() { for (let d of collectDocs(document, [])) hideLeftPanelSections(d); } function scanAllSections() { const seen = new Map(); const add = n => { if (n && !seen.has(normName(n))) seen.set(normName(n), n); }; add('Tags'); add('Also here'); for (let d of collectDocs(document, [])) getSectionCols(d).forEach(x => add(x.name)); hiddenSections.forEach(add); return Array.from(seen.values()); } function tagAllMessages(doc) { if (!doc) return; try { const articles = doc.querySelectorAll('article[data-test-id="omni-log-comment-item"]'); let prevRole = 'customer'; articles.forEach(article => { const role = classifyMessage(article, prevRole); article.setAttribute('data-chat-role', role); const senderEl = article.querySelector('[data-test-id="omni-log-item-sender"]'); const timeEl = article.querySelector('[data-test-id="timestamp-relative"], [data-test-id="timestamp-absolute"]'); const msgBox = article.querySelector('[data-test-id="omni-log-item-message"]'); if (msgBox) { if (senderEl) msgBox.setAttribute('data-sender-name', senderEl.textContent.trim()); if (timeEl) msgBox.setAttribute('data-msg-time', timeEl.textContent.trim()); } prevRole = role; }); } catch(e) {} } function setupDoc(doc) { if (!doc || docMap.has(doc) || !doc.body || !doc.documentElement) return; try { doc.documentElement.classList.add("zskin-active"); if (darkMode) { doc.documentElement.classList.add("zskin-dark"); doc.documentElement.classList.remove("zskin-light"); } else { doc.documentElement.classList.remove("zskin-dark"); doc.documentElement.classList.add("zskin-light"); } let record = { sheet: injectLayoutAndColorCss(doc), styles: new Map(), pending: new Set(), timer: 0, running: false, obs: null }; docMap.set(doc, record); attachObserver(doc); tagAllMessages(doc); hideLeftPanelSections(doc); if (darkMode) { runTreeWalker(doc); } doc.addEventListener("load", e => { let t = e.target; if (t && t.tagName === "IFRAME") setTimeout(scanAllDocs, 200); }, true); } catch(e) {} } function scanAllDocs() { for (let d of collectDocs(document, [])) {
  if (zenxPremiumOwnsSurfaces()) {
    const previous = docMap.get(d);
    if (previous) {
      clearTimeout(previous.timer);
      previous.pending.clear();
      if (previous.styles.size) restoreZsStyles(previous.styles);
    }
    // Only the legacy painter adds this marker; premium rules never need it.
    d.querySelectorAll('[' + PROCESSED_ATTR + ']').forEach(el => el.removeAttribute(PROCESSED_ATTR));
  }
  setupDoc(d); try { d.documentElement.classList.add("zskin-active"); if (darkMode) { d.documentElement.classList.add("zskin-dark"); d.documentElement.classList.remove("zskin-light"); } else { d.documentElement.classList.remove("zskin-dark"); d.documentElement.classList.add("zskin-light"); } } catch(e) {} tagAllMessages(d); hideLeftPanelSections(d); } toggleCrossDomainSidePanels(darkMode); } function toggleCrossDomainSidePanels(turnOn) { let iframes = []; try { iframes = [...document.querySelectorAll('iframe')]; } catch(e) {} iframes.forEach(f => { try { if (zenxPremiumOwnsSurfaces()) { if (f.hasAttribute(FILTER_ATTR)) { f.style.removeProperty('filter'); f.style.removeProperty('background'); f.removeAttribute(FILTER_ATTR); } return; } if (!turnOn) { if (f.hasAttribute(FILTER_ATTR)) { f.style.removeProperty('filter'); f.style.removeProperty('background'); f.removeAttribute(FILTER_ATTR); } return; } let r = f.getBoundingClientRect(); const cs = window.getComputedStyle(f); const visible = r.width > 160 && r.height > 180 && cs.visibility !== 'hidden' && cs.display !== 'none'; const likelyToolPanel = visible && (r.left > window.innerWidth * 0.45 || r.width < window.innerWidth * 0.55 || f.closest('[data-test-id*="app"], [data-test-id*="sidebar"], [data-test-id*="panel"], aside, [role="complementary"]')); if (likelyToolPanel) { f.style.setProperty('filter', 'invert(.94) hue-rotate(180deg) brightness(.94) contrast(1.02)', 'important'); f.style.setProperty('background', darkMode ? '#0f1117' : '#ffffff', 'important'); f.setAttribute(FILTER_ATTR, ''); } else if (f.hasAttribute(FILTER_ATTR)) { f.style.removeProperty('filter'); f.style.removeProperty('background'); f.removeAttribute(FILTER_ATTR); } } catch(e) {} }); } const TIMER_ID = 'zd-floating-sla-timer'; let timerIntervalId = 0; let audioCtx = null; let hasBeeped1Min = false; let manualResetTime = 0; let manualDurationOverride = 0; let lastAgentMsgId = ''; let macroDismissedId = ''; let activeMacroText = ''; let activeMacroList = []; let macroCopiedRecently = false; function escapeHtml(str) { if (!str) return ''; return String(str) .replace(/&/g, '&amp;') .replace(/</g, '&lt;') .replace(/>/g, '&gt;') .replace(/"/g, '&quot;') .replace(/'/g, '&#39;'); } const ZENX_QUICK_MACROS = Object.freeze({
  hold: {
    title: 'Hold', caption: 'Give a clear check-in time and follow through',
    messages: [
      "Thank you for explaining the situation. I'd like to review the details carefully before giving you an answer. May I have 3–5 minutes? I'll return with an update.",
      "I understand this is important to you, and I want to make sure I give you accurate information. Please allow me about 3–5 minutes to check the available details. I'll be back shortly.",
      "I appreciate your patience. I'm looking into the information you've shared and need a few minutes to verify the next steps. I'll update you within 3–5 minutes, even if I'm still investigating.",
      "Thank you for waiting. I need a little more time to complete my review. Would you mind allowing me another 5 minutes? I'll make sure to keep you updated."
    ]
  },
  empathy: {
    title: 'Empathy', caption: "Acknowledge the person\'s experience",
    messages: [
      "I can understand why this would be frustrating, especially when you were expecting things to go differently. Thank you for taking the time to explain what happened. I'll do my best to help you understand the next steps.",
      "That sounds like a stressful situation, and I understand why you're concerned. I appreciate you bringing it to our attention. Let me review what I can do to help.",
      "I hear what you're saying, and I understand how important this is to you. You deserve a clear explanation, and I'll do my best to provide one.",
      "I can see why this experience has been disappointing. Thank you for being open about your concerns. I'll take them seriously as we look at the options available."
    ]
  },
  apology: {
    title: 'Apology', caption: 'Own the experience without promising an outcome',
    messages: [
      "I'm sorry for the frustration this situation has caused. I appreciate your patience, and I'd like to review the details so I can give you a clear and accurate response.",
      "I apologize for the inconvenience and the time you've had to spend on this. I understand why you're disappointed, and I'll do my best to clarify what happened and what can be done next.",
      "I'm sorry this experience hasn't met your expectations. Your concerns are valid, and I appreciate the opportunity to look into them with you.",
      "I apologize for any confusion in our earlier communication. Let me clarify the information and outline the options available to you."
    ]
  },
  denied: {
    title: 'Denied', caption: 'For reviewed decisions; be respectful and offer next steps',
    messages: [
      "I understand this isn't the outcome you were hoping for, and I'm sorry for the disappointment. Based on the details reviewed, we're unable to approve the request. I'm happy to explain the decision and discuss any next steps that may be available.",
      "I realize this answer may be frustrating. I've reviewed the information available, and unfortunately, we can't make the requested exception. I want to be transparent about that while helping you understand the options you still have.",
      "I appreciate you giving us the opportunity to review your request. While I understand your perspective, the decision can't be changed at this time. I can clarify the reason we're able to share and help with any available alternatives.",
      "I know this isn't the resolution you wanted. I'm sorry I can't provide a different outcome based on the current review. If it would help, I can explain the next steps or any relevant process that may still be available."
    ]
  }
});

const MUTE_KEY = 'zd_timer_muted'; const MACRO_KEY = 'zd_timer_macros_enabled'; let isMacrosEnabled = (() => { try { const value = safeStorage.getItem(MACRO_KEY); return value === null ? true : value === 'true'; } catch(e) {} return true; })(); let isMuted = (() => { try { return safeStorage.getItem(MUTE_KEY) === 'true'; } catch(e) {} return false; })(); const ticketFirstSeen = new Map();
const ticketStates = new Map();

function getTicketState(ticketKey) {
  if (!ticketStates.has(ticketKey)) {
    ticketStates.set(ticketKey, {
      ticketKey,
      ticketId: '',
      displayBadge: '',
      msgId: '',
      rawTimeText: '',
      baseElapsedSec: 0,
      anchorTime: 0,
      manualResetTime: 0,
      manualDurationOverride: 0,
      hasBeeped1Min: false,
      macroDismissedId: '',
      nativeSla: ''
    });
  }
  return ticketStates.get(ticketKey);
}

const HOLD_REGEX = /\b(?:(?:[345]|three|four|five)(?:\s*(?:-|–|—|to|or|\/|-to-)\s*(?:[345]|three|four|five))?)\s*-?\s*(?:minutes?|mins?|m)\b/i;
const ASSISTANCE_REGEX = /\b(?:further\s+(?:assistance|questions?)|(?:need|require)\s+assistance|anything\s+else|open\s+a\s+new\s+chat|end\s+(?:our|this)\s+chat|close\s+(?:our|this)\s+chat|haven['’]t\s+heard\s+(?:back|from\s+you)|hesitate\s+to\s+(?:reach\s+out|let\s+us\s+know|contact)|thank\s+you\s+(?:so\s+much\s+)?for\s+contacting)\b/i;

function getAudioContext() {
  try {
    if (!audioCtx) {
      const AudioCtx = window.AudioContext || window.webkitAudioContext;
      if (AudioCtx) audioCtx = new AudioCtx();
    }
    if (audioCtx && audioCtx.state === 'suspended') audioCtx.resume().catch(() => {});
    return audioCtx;
  } catch(e) {
    return null;
  }
}

function playTone(freq, duration, type = 'sine', volume = 0.22) {
  if (isMuted) return;
  try {
    const ctx = getAudioContext();
    if (!ctx) return;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    // ZenX theme audio: sound profile changes the tone only, never its trigger or SLA logic.
    const zenxProfile = (globalThis.__zenxSoundProfile || {}).type || 'original';
    const zenxSounds = {
      original:['',1,1], bamboo:['sine',.81,.78], bounce:['triangle',1.28,.80],
      cosmic:['sine',.62,.78], neon:['square',1.20,.46], bell:['sine',1.52,.70],
      wind:['triangle',.58,.54], tea:['triangle',.94,.65], glass:['sine',1.38,.65], sunrise:['sine',1.12,.66],
      wave:['triangle',.91,.75], latte:['sine',.77,.56], purr:['sine',.68,.54], meow:['sawtooth',.84,.35]
    };
    const [soundWave, soundPitch, soundGain] = zenxSounds[zenxProfile] || zenxSounds.original;
    const nextFreq = freq * soundPitch;
    osc.type = soundWave || type;
    osc.frequency.setValueAtTime(nextFreq, ctx.currentTime);
    if (zenxProfile === 'meow' || zenxProfile === 'purr') {
      osc.frequency.exponentialRampToValueAtTime(Math.max(80,nextFreq*(zenxProfile==='meow'?.63:.87)),ctx.currentTime+duration);
    }
    gain.gain.setValueAtTime(volume * soundGain, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + duration);
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start();
    osc.stop(ctx.currentTime + duration);
  } catch(e) {}
}

function playOneMinuteWarning() {
  playTone(880, 0.14, 'sine', 0.25);
  setTimeout(() => playTone(1174, 0.22, 'sine', 0.28), 160);
}

function playUrgentBeep() {
  playTone(740, 0.09, 'square', 0.22);
  setTimeout(() => playTone(740, 0.09, 'square', 0.22), 140);
}

// Resolve the ticket displayed by Zendesk, never by our own timer pill.  A
// workspace can keep several ticket tabs mounted and may expose stale
// aria-selected/data-entity-id values while the user switches conversations.
function zenxVisibleHeaderTicketId() {
  const pattern = /\bticket\s*#\s*(\d{4,})(?!\d)/i;
  const selectors = [
    '[data-test-id="ticket-top-bar"]',
    '[data-test-id="ticket-sub-nav-item"]',
    '[data-test-id*="ticket-sub-nav"]',
    '[data-test-id*="ticket-breadcrumb"]',
    '[data-test-id="ticket-id"]',
    '[data-test-id="ticket-header"]',
    '[data-test-id*="ticket-id-label"]'
  ];
  const valid = el => {
    if (!el || el.closest('#zd-floating-sla-timer, [data-test-id="omni-log-container"], [data-test-id="component-type-AppsPane"]')) return false;
    if (el.getAttribute('aria-hidden') === 'true') return false;
    const rect = el.getBoundingClientRect();
    return rect.width > 0 && rect.height > 0;
  };
  for (const selector of selectors) {
    for (const el of document.querySelectorAll(selector)) {
      if (!valid(el)) continue;
      const match = (el.textContent || el.getAttribute('aria-label') || '').match(pattern);
      if (match) return match[1];
    }
  }
  // Some Zendesk versions do not label the breadcrumb with a test id.
  // Read only a short text leaf in the secondary ticket toolbar (not chat,
  // notifications, background tabs, side apps, or ZenX's own floating pill).
  const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
  let node, visited = 0;
  while ((node = walker.nextNode()) && ++visited < 6000) {
    const text = node.nodeValue || '';
    if (!/ticket\s*#/i.test(text) || text.length > 120) continue;
    const el = node.parentElement;
    if (!el || !valid(el) || el.closest('[role="tab"], [data-test-id="header-tab"], [data-test-id="tabs-section-nav-item-ticket"], [data-test-id*="omni-log"], [data-test-id*="comment"], #zd-floating-sla-timer')) continue;
    const rect = el.getBoundingClientRect();
    if (rect.top < 30 || rect.top > 200) continue;
    const m = text.match(pattern);
    if (m) return m[1];
  }
  return '';
}

function zenxUrlTicketId() {
  const path = location.pathname + location.hash;
  const match = path.match(/\/tickets\/(\d{4,})(?=\/|$|[?#])/i);
  return match ? match[1] : '';
}

function getActiveTicketDetails() {
  let ticketId = '';
  let ticketKey = '';
  let displayBadge = '';
  let container = null;
  let nativeSla = '';

  try {
    const tabSelectors = [
      '[data-test-id="header-tab"][aria-selected="true"]',
      '[data-test-id="tabs-section-nav-item-ticket"][aria-selected="true"]',
      '[data-test-id="workspace-tab"][aria-selected="true"]',
      '[data-test-id="tab-item"][aria-selected="true"]',
      'div[role="tab"][aria-selected="true"]',
      'button[role="tab"][aria-selected="true"]',
      'li[role="tab"][aria-selected="true"]',
      '[role="tab"][aria-selected="true"]'
    ];

    let activeTab = null;
    for (const sel of tabSelectors) {
      const found = document.querySelector(sel);
      if (found) {
        activeTab = found;
        break;
      }
    }

    if (activeTab) {
      const controlsId = activeTab.getAttribute('aria-controls');
      if (controlsId) {
        container = document.getElementById(controlsId);
      }

      const entityId = activeTab.getAttribute('data-entity-id') || activeTab.getAttribute('data-ticket-id');
      if (entityId && /^\d+$/.test(entityId)) {
        ticketId = entityId;
      }

      if (!ticketId) {
        const testId = activeTab.getAttribute('data-test-id') || '';
        const m = testId.match(/(?:ticket-)?(\d{3,})/i);
        if (m) ticketId = m[1];
      }

      if (!ticketId) {
        const tabId = activeTab.getAttribute('id') || '';
        const m = tabId.match(/(?:ticket-)?(\d{3,})/i);
        if (m) ticketId = m[1];
      }

      if (!ticketId) {
        const title = activeTab.getAttribute('title') || activeTab.getAttribute('aria-label') || '';
        const m = title.match(/(?:ticket\s*#?|#)(\d{3,})/i);
        if (m) ticketId = m[1];
      }

      if (!ticketId) {
        const txt = activeTab.textContent || '';
        const m = txt.match(/#?(\d{4,})/);
        if (m) ticketId = m[1];
      }
    }

    if (!container) {
      const panelCandidates = Array.from(document.querySelectorAll(
        '[role="tabpanel"]:not([aria-hidden="true"]), [data-test-id="workspace-tab"]:not([aria-hidden="true"]), [data-test-id="ticket-pane"]:not([aria-hidden="true"]), [data-test-id="component-type-MainConversationPane"]'
      ));
      for (const p of panelCandidates) {
        if (p.offsetParent !== null || (p.getClientRects && p.getClientRects().length > 0)) {
          container = p.closest('[role="tabpanel"], [data-test-id="workspace-tab"]') || p;
          break;
        }
      }
    }

    if (!ticketId && container) {
      const idEl = container.querySelector('[data-test-id*="ticket-id"], [data-test-id="ticket-sub-nav-item"], a[href*="/tickets/"]');
      if (idEl) {
        const href = idEl.getAttribute('href') || '';
        const mHref = href.match(/\/tickets\/(\d+)/);
        if (mHref) {
          ticketId = mHref[1];
        } else {
          const mText = (idEl.textContent || '').match(/#?(\d{3,})/);
          if (mText) ticketId = mText[1];
        }
      }
      if (!ticketId) {
        const headerText = (container.querySelector('header, [data-test-id*="header"], [data-test-id*="title"]') || {}).textContent || '';
        const mHeader = headerText.match(/#(\d{4,})/);
        if (mHeader) ticketId = mHeader[1];
      }
    }

    if (!ticketId) {
      const mPath = (window.location.pathname + window.location.hash + window.location.search).match(/\/tickets\/(\d+)/);
      if (mPath) ticketId = mPath[1];
    }

    if (!ticketId) {
      const mTitle = (document.title || '').match(/Ticket\s*#?(\d+)|#(\d{4,})/i);
      if (mTitle) ticketId = mTitle[1] || mTitle[2];
    }

    // Active conversation header and URL outrank a tab's cached entity id.
    // In Polaris the selected tab may still describe the PREVIOUS ticket.
    const headerTicketId = zenxVisibleHeaderTicketId();
    const urlTicketId = zenxUrlTicketId();
    const authoritativeTicketId = headerTicketId || urlTicketId;
    if (authoritativeTicketId && ticketId !== authoritativeTicketId) {
      ticketId = authoritativeTicketId;
      // A panel linked by stale aria-controls must not contribute messages
      // for a different ticket. Re-resolve to the visible conversation pane.
      if (container && container !== document.body) {
        const linked = activeTab && activeTab.getAttribute('aria-controls');
        if (linked && container.id === linked) {
          const visibleConversation = Array.from(document.querySelectorAll('[data-test-id="component-type-MainConversationPane"]'))
            .find(el => el.getClientRects().length > 0 && !el.closest('[aria-hidden="true"]'));
          if (visibleConversation) container = visibleConversation.closest('[role="tabpanel"]') || visibleConversation;
        }
      }
    }

    if (!ticketId && activeTab) {
      const tabText = (activeTab.textContent || '').trim().toLowerCase();
      if (tabText.includes('new ticket') || tabText.includes('new')) {
        ticketId = 'New';
        ticketKey = 'new_' + (activeTab.id || 'tab');
        displayBadge = 'New';
      }
    }

    if (ticketId && ticketId !== 'New') {
      ticketKey = 'ticket_' + ticketId;
      displayBadge = '#' + ticketId;
    } else if (!ticketKey) {
      ticketKey = 'ticket_default';
      displayBadge = 'Ticket';
    }

    const slaScope = container || document;
    const slaEl = slaScope.querySelector('[data-test-id="ticket-sla-badge"], [data-test-id*="sla-badge"], [data-test-id*="sla-target"], [data-test-id*="sla-time"], [data-garden-id*="sla"]');
    if (slaEl) {
      const rawSla = (slaEl.textContent || slaEl.getAttribute('aria-label') || '').trim();
      if (rawSla) nativeSla = rawSla;
    }
  } catch(e) {}

  return { ticketId, ticketKey, displayBadge, container, nativeSla };
}

function isTicketOpen(container) {
  const scope = container || document;
  const hasComposer = !!scope.querySelector(
    'textarea, [contenteditable="true"], [data-test-id*="composer"], [data-test-id*="editor"], [data-test-id="omni-composer-text-input"], [data-test-id="omni-log-composer-editor"]'
  );
  if (!hasComposer) {
    const visibleComp = findZendeskComposer(container);
    if (!visibleComp) return false;
  }
  const closedBadge = scope.querySelector('[data-test-id="status-badge-closed"]');
  if (closedBadge) return false;
  const statusView = scope.querySelector('[data-test-id*="status-view"], [data-test-id*="status-badge"]');
  if (statusView) {
    const txt = (statusView.textContent || '').toLowerCase();
    if (txt.includes('solved') || txt.includes('closed')) return false;
  }
  return true;
}

function isRelativeTimeText(str) {
  if (!str || typeof str !== 'string') return false;
  const s = str.trim().toLowerCase();
  return /\b(?:less than|under)\s+(?:a|1)\s+min(?:ute)?s?\b/i.test(s) ||
         /\b(?:just now|right now|a moment ago|a few seconds? ago)\b/i.test(s) ||
         /\b\d+\s*(?:sec(?:ond)?s?|min(?:ute)?s?|hours?|hrs?)\s+ago\b/i.test(s) ||
         /\b(?:a|one)\s+(?:min(?:ute)?|second|hour)\s+ago\b/i.test(s);
}

function parseRelativeElapsedSeconds(rawStr) {
  if (!rawStr || typeof rawStr !== 'string') return null;
  const s = rawStr.trim().toLowerCase();
  if (!s) return null;
  if (/\b(?:less than|under)\s+(?:a|1)\s+min(?:ute)?s?\b/i.test(s)) return 0;
  if (/\b(?:just now|right now|a moment ago|a few seconds? ago)\b/i.test(s)) return 0;
  let m = s.match(/\b(\d+|a|one)\s*(?:seconds?|secs?)\s+ago\b/i);
  if (m) {
    return (m[1] === 'a' || m[1] === 'one') ? 1 : parseInt(m[1], 10);
  }
  m = s.match(/\b(\d+|a|one)\s*(?:minutes?|mins?)\s+ago\b/i);
  if (m) {
    const mins = (m[1] === 'a' || m[1] === 'one') ? 1 : parseInt(m[1], 10);
    return mins * 60;
  }
  m = s.match(/\b(\d+|a|one)\s*(?:hours?|hrs?)\s+ago\b/i);
  if (m) {
    const hrs = (m[1] === 'a' || m[1] === 'one') ? 1 : parseInt(m[1], 10);
    return hrs * 3600;
  }
  return null;
}

function getMessageRelativeTimeString(box) {
  if (!box) return '';
  const direct = box.getAttribute('data-msg-time');
  if (direct && isRelativeTimeText(direct)) return direct.trim();
  const article = box.closest('article[data-test-id="omni-log-comment-item"]');
  const scope = article || box.parentElement || box;
  const timeEl = scope.querySelector('[data-test-id="timestamp-relative"], [data-test-id*="timestamp"], time');
  if (timeEl) {
    const txt = (timeEl.textContent || '').trim();
    if (isRelativeTimeText(txt)) return txt;
    const aria = (timeEl.getAttribute('aria-label') || '').trim();
    if (isRelativeTimeText(aria)) return aria;
  }
  const allEls = scope.querySelectorAll('*');
  for (const el of allEls) {
    if (el.children.length === 0) {
      const txt = (el.textContent || '').trim();
      if (isRelativeTimeText(txt)) return txt;
    }
  }
  return '';
}

function getAgentMessages(container) {
  const messages = [];
  const scope = container || document;
  try {
    const boxes = Array.from(scope.querySelectorAll('[data-test-id="omni-log-item-message"]'));
    for (const box of boxes) {
      const boxType = (box.getAttribute('type') || '').toLowerCase();
      const article = box.closest('article[data-test-id="omni-log-comment-item"]');
      if (boxType === 'internal' || boxType === 'bot' || box.closest('[data-test-id="omni-log-internal-note-tag"], [type="internal"], [data-chat-role="internal"], [data-chat-role="bot"]')) continue;
      let isAgent = boxType === 'agent' || (box.getAttribute('data-sender-type') || '').toLowerCase() === 'agent' || (box.getAttribute('data-chat-role') || '').toLowerCase() === 'agent' || !!(article && (article.getAttribute('data-chat-role') || '').toLowerCase() === 'agent');
      if (!isAgent && article && article.querySelector('[data-test-id="omni-log-avatar-badge-AgentBadge"]')) {
        isAgent = true;
      }
      if (!isAgent) continue;
      const content = box.querySelector('[data-test-id="omni-log-message-content"]') || box;
      const cleanContent = content.cloneNode(true);
      cleanContent.querySelectorAll('button, svg, [data-test-id*="indicator"]').forEach(el => el.remove());
      const text = cleanContent.textContent.trim();
      const rawTime = getMessageRelativeTimeString(box);
      const id = (article && article.getAttribute('data-event-id')) || box.getAttribute('data-event-id') || box.id || (text.slice(0, 40) + '_' + messages.length);
      messages.push({ element: box, type: 'agent', rawTime, text, id });
    }
  } catch(e) {}
  return messages;
}

function evaluateAgentSLA() {
  const ticketInfo = getActiveTicketDetails();
  if (!isTicketOpen(ticketInfo.container)) {
    return {
      isOpen: false,
      ticketId: ticketInfo.ticketId,
      ticketKey: ticketInfo.ticketKey,
      displayBadge: ticketInfo.displayBadge,
      nativeSla: ticketInfo.nativeSla,
      durationSec: 0,
      remainingSec: 0,
      remainingMs: 0,
      rule: 'idle',
      label: 'Idle',
      msgId: ''
    };
  }

  const tState = getTicketState(ticketInfo.ticketKey);
  tState.ticketId = ticketInfo.ticketId;
  tState.displayBadge = ticketInfo.displayBadge;
  tState.nativeSla = ticketInfo.nativeSla;

  const agentMsgs = getAgentMessages(ticketInfo.container);
  const scope = ticketInfo.container || document;
  const allArticles = Array.from(scope.querySelectorAll('article[data-test-id="omni-log-comment-item"]'));

  if (agentMsgs.length === 0) {
    const durationSec = tState.manualDurationOverride > 0 ? tState.manualDurationOverride : 60;
    const firstReplyKey = 'first_reply_' + ticketInfo.ticketKey;
    if (tState.msgId !== firstReplyKey) {
      tState.msgId = firstReplyKey;
      tState.rawTimeText = '';
      tState.hasBeeped1Min = false;
      tState.macroDismissedId = '';
      let custElapsed = 0;
      if (allArticles.length) {
        const lastArticle = allArticles[allArticles.length - 1];
        const timeEl = lastArticle.querySelector('[data-test-id="timestamp-relative"], time');
        const relStr = timeEl ? (timeEl.textContent || '').trim() : '';
        const parsed = parseRelativeElapsedSeconds(relStr);
        if (parsed !== null) custElapsed = parsed;
      }
      tState.baseElapsedSec = (tState.manualResetTime > 0 && Date.now() - tState.manualResetTime < 30000) ? 0 : custElapsed;
      tState.anchorTime = Date.now();
      tState.manualResetTime = 0;
    }
    const localSec = Math.max(0, Math.floor((Date.now() - tState.anchorTime) / 1000));
    const totalElapsed = tState.baseElapsedSec + localSec;
    const remainingSec = Math.max(0, durationSec - totalElapsed);
    return {
      isOpen: true,
      ticketId: ticketInfo.ticketId,
      ticketKey: ticketInfo.ticketKey,
      displayBadge: ticketInfo.displayBadge,
      nativeSla: ticketInfo.nativeSla,
      durationSec,
      remainingSec,
      remainingMs: remainingSec * 1000,
      rule: 'first_reply',
      label: '1m First Reply',
      msgId: firstReplyKey
    };
  }

  const latestAgent = agentMsgs[agentMsgs.length - 1];
  // Agent-message timer: incoming customer/bot messages must never restart it.
  // Keep the last actual agent reply as the cycle anchor until another agent reply
  // arrives or the user explicitly resets the pill's duration.
  const isHold = HOLD_REGEX.test(latestAgent.text);
  const isAssistance = !isHold && ASSISTANCE_REGEX.test(latestAgent.text);
  let durationSec = isHold ? 300 : (isAssistance ? 60 : 120);
  const rule = isHold ? 'hold' : (isAssistance ? 'assistance' : 'general');
  let label = isHold ? '5m Hold' : (isAssistance ? '1m Assistance' : '2m Response');
  const msgIdentifier = (latestAgent.id || '') + '_agent_' + latestAgent.text.slice(0, 40);
  const currentRawTime = (latestAgent.rawTime || '').trim();

  if (tState.manualDurationOverride > 0) {
    durationSec = tState.manualDurationOverride;
    label = `${Math.round(durationSec / 60)}m Manual`;
  }

  const parsedElapsed = parseRelativeElapsedSeconds(currentRawTime);

  if (msgIdentifier !== tState.msgId) {
    tState.msgId = msgIdentifier;
    tState.rawTimeText = currentRawTime;
    tState.hasBeeped1Min = false;
    tState.macroDismissedId = '';
    if (tState.manualResetTime > 0 && Date.now() - tState.manualResetTime < 30000) {
      tState.baseElapsedSec = 0;
    } else if (parsedElapsed !== null) {
      tState.baseElapsedSec = parsedElapsed;
    } else {
      tState.baseElapsedSec = 0;
    }
    tState.anchorTime = Date.now();
    tState.manualResetTime = 0;
  } else {
    if (currentRawTime && currentRawTime !== tState.rawTimeText && parsedElapsed !== null) {
      tState.rawTimeText = currentRawTime;
      if (parsedElapsed > tState.baseElapsedSec) {
        tState.baseElapsedSec = parsedElapsed;
        tState.anchorTime = Date.now();
      }
    }
  }

  const localSec = Math.max(0, Math.floor((Date.now() - tState.anchorTime) / 1000));
  const totalElapsed = tState.baseElapsedSec + localSec;
  const remainingSec = Math.max(0, durationSec - totalElapsed);

  return {
    isOpen: true,
    ticketId: ticketInfo.ticketId,
    ticketKey: ticketInfo.ticketKey,
    displayBadge: ticketInfo.displayBadge,
    nativeSla: ticketInfo.nativeSla,
    durationSec,
    remainingSec,
    remainingMs: remainingSec * 1000,
    rule,
    label,
    msgId: msgIdentifier
  };
}
function findZendeskComposer(container, focused) {
  // Prefer an actual editable in the native Zendesk reply composer. A generic
  // contenteditable elsewhere in a ticket (or in an app) is not a safe target.
  const selectors = [
    // Polaris uses CKEditor 5 for the live Messaging composer. Target its
    // real textbox before legacy composer wrappers or hidden editors.
    '[data-test-id="omnicomposer-plain-text-ckeditor"][contenteditable="true"]',
    '[data-test-id="ticket-rich-text-editor"] .ck-editor__editable[contenteditable="true"]',
    '[data-test-id="omni-composer-text-input"] [contenteditable="true"]',
    '[data-test-id="omni-composer-text-input"][contenteditable="true"]',
    '[data-test-id="omni-log-composer-editor"] [contenteditable="true"]',
    '[data-test-id="omni-log-composer-editor"][contenteditable="true"]',
    '[data-test-id*="composer"] [role="textbox"][contenteditable="true"]',
    '[data-test-id*="composer"] [contenteditable="true"]',
    'div.ck-editor__editable[contenteditable="true"]',
    '.ProseMirror[contenteditable="true"]',
    '[data-test-id*="composer"] textarea',
    'textarea[data-test-id*="editor"]',
    'textarea[data-test-id*="text-input"]',
    'textarea.zendesk-editor--textarea',
    'textarea[name*="comment"]',
    '[data-test-id*="editor"] [contenteditable="true"]',
    '[role="textbox"][contenteditable="true"]',
    'div[contenteditable="true"]'
  ];
  const roots = [];
  const pushRoot = root => { if (root && !roots.includes(root)) roots.push(root); };
  if (container) pushRoot(container);
  for (const sel of [
    '[data-test-id="component-type-MainConversationPane"]',
    '[data-test-id="ticket-main-conversation"]',
    '.conversation-polaris',
    '[data-test-id="omni-log-container"]'
  ]) {
    document.querySelectorAll(sel).forEach(pushRoot);
  }
  pushRoot(document);
  const isWritable = el => {
    if (!el || el.closest('#' + TIMER_ID + ', [aria-hidden="true"], [inert]')) return false;
    if (el.closest('[data-test-id="component-type-ContextPanel"], [data-test-id*="apps-panel"], [data-test-id*="search"]')) return false;
    if (el.disabled || el.readOnly || el.getAttribute('aria-disabled') === 'true') return false;
    if (el.getAttribute('role') === 'searchbox' || el.type === 'search') return false;
    if (el.tagName !== 'TEXTAREA' && el.tagName !== 'INPUT' && el.getAttribute('contenteditable') !== 'true') return false;
    const cs = el.ownerDocument.defaultView?.getComputedStyle(el);
    return cs?.display !== 'none' && cs?.visibility !== 'hidden' && !!(el.offsetParent !== null || el.getClientRects().length);
  };
  // Prefer explicit composer matches across all roots before generic fallbacks.
  for (const selector of selectors) {
    for (const root of roots) {
      try {
        for (const el of root.querySelectorAll(selector)) {
          if ((focused && el !== focused) || !isWritable(el)) continue;
          if (focused && (selector === 'div[contenteditable="true"]' || selector.startsWith('[role="textbox"]')) &&
              !el.closest('[data-test-id*="composer"], [data-test-id="ticket-rich-text-editor"]')) continue;
          // Generic fallbacks must still belong to a native conversation pane.
          if ((selector === 'div[contenteditable="true"]' || selector.startsWith('[role="textbox"]')) &&
              !el.closest('[data-test-id*="composer"], [data-test-id="component-type-MainConversationPane"], .conversation-polaris, [data-test-id="ticket-main-conversation"]')) continue;
          return el;
        }
      } catch (_) {}
    }
  }
  return null;
}

// A click can move focus from Zendesk to our macro popup. Always resolve a
// native composer and edit through its model or native browser input pipeline.
let zenxMacroRequestCounter = 0;
function zenxWaitForEditorBridge(el, text) {
  return new Promise(resolve => {
    const id = 'zenx-macro-' + (++zenxMacroRequestCounter);
    const doc = el.ownerDocument;
    let settled = false;
    const finish = success => {
      if (settled) return;
      settled = true;
      clearTimeout(timeout);
      el.removeEventListener('zenx:editor-insert-response', onResult);
      resolve(!!success);
    };
    const onResult = event => {
      if (event.detail?.id === id) finish(event.detail.success);
    };
    const timeout = setTimeout(() => finish(false), 65);
    el.addEventListener('zenx:editor-insert-response', onResult);
    try {
      el.dispatchEvent(new (doc.defaultView || window).CustomEvent('zenx:editor-insert-request', {
        bubbles: true, detail: { id, text }
      }));
    } catch (_) { finish(false); }
  });
}

async function populateZendeskComposer(text) {
  if (typeof text !== 'string' || !text.trim()) return false;
  const info = getActiveTicketDetails();
  const el = findZendeskComposer(info.container);
  if (!el) return false;
  const doc = el.ownerDocument || document;
  const view = doc.defaultView || window;
  const expected = text.replace(/\s+/g, ' ').trim();
  const currentText = () => (el.tagName === 'TEXTAREA' || el.tagName === 'INPUT'
    ? el.value : (el.innerText || el.textContent || '')).replace(/\s+/g, ' ').trim();
  const containsText = () => currentText().includes(expected);
  // Visual DOM edits alone are not proof: managed editors can erase them on
  // their next render. Check after the framework has processed the input.
  const persists = async () => {
    await new Promise(resolve => setTimeout(resolve, 100));
    if (!containsText()) return false;
    await new Promise(resolve => setTimeout(resolve, 280));
    return containsText() && el.isConnected;
  };
  try { el.focus({ preventScroll: true }); } catch (_) { try { el.focus(); } catch (_) {} }
  if (el.tagName === 'TEXTAREA' || el.tagName === 'INPUT') {
    try {
      const proto = el.tagName === 'TEXTAREA' ? view.HTMLTextAreaElement.prototype : view.HTMLInputElement.prototype;
      const descriptor = Object.getOwnPropertyDescriptor(proto, 'value');
      if (descriptor?.set) descriptor.set.call(el, text);
      else el.value = text;
      el.dispatchEvent(new view.Event('input', { bubbles: true }));
      el.dispatchEvent(new view.Event('change', { bubbles: true }));
      return await persists();
    } catch (_) { return false; }
  }
  if (el.getAttribute('contenteditable') !== 'true') return false;
  const isManaged = !!el.matches('[data-test-id="omnicomposer-plain-text-ckeditor"], .ck-editor__editable, .ProseMirror, [data-slate-editor="true"]') ||
    !!el.closest('.ck-editor, [data-test-id="ticket-rich-text-editor"]');

  // The MAIN-world adapter can see editor instances that an isolated-world
  // extension cannot. If available, update CKEditor's model, not just its DOM.
  if (await zenxWaitForEditorBridge(el, text)) return await persists();

  const selectExistingDraft = () => {
    try {
      el.focus({ preventScroll: true });
      const selection = view.getSelection();
      const range = doc.createRange();
      range.selectNodeContents(el);
      selection.removeAllRanges();
      selection.addRange(range);
      return true;
    } catch (_) { return false; }
  };
  if (!selectExistingDraft()) return false;
  try {
    // execCommand emits the browser's native editing/input events, which
    // supported editors consume. A synthetic input event on its own doesn't.
    doc.execCommand('insertText', false, text);
  } catch (_) {}
  if (await persists()) return true;

  // Clipboard pipeline fallback for CKEditor 5. No user clipboard read/write.
  if (isManaged) {
    try {
      if (selectExistingDraft() && typeof view.DataTransfer === 'function' && typeof view.ClipboardEvent === 'function') {
        const transfer = new view.DataTransfer();
        transfer.setData('text/plain', text);
        el.dispatchEvent(new view.ClipboardEvent('paste', { bubbles: true, cancelable: true, clipboardData: transfer }));
        return await persists();
      }
    } catch (_) {}
    // Do not directly overwrite a managed editor: the next React/CKEditor
    // render could silently discard text while ZenX reports success.
    return false;
  }
  // Only unmanaged contenteditables can safely use a DOM-based fallback.
  try {
    el.replaceChildren(doc.createTextNode(text));
    try { el.dispatchEvent(new view.InputEvent('input', { bubbles: true, inputType: 'insertText', data: text })); }
    catch (_) { el.dispatchEvent(new view.Event('input', { bubbles: true })); }
    el.dispatchEvent(new view.Event('change', { bubbles: true }));
    return await persists();
  } catch (_) { return false; }
}

function setupSendResetListener() {
  function handleSendTrigger(e) {
    try {
      const ticketInfo = getActiveTicketDetails();
      const tState = getTicketState(ticketInfo.ticketKey);
      if (e.type === 'keydown' && e.key === 'Enter' && !e.shiftKey) {
        const comp = findZendeskComposer(ticketInfo.container);
        if (comp && (e.target === comp || comp.contains(e.target))) {
          tState.manualResetTime = Date.now();
          tState.msgId = '';
          tState.baseElapsedSec = 0;
          tState.anchorTime = Date.now();
          setTimeout(updateTimerDisplay, 80);
        }
      }
      if (e.type === 'click') {
        const btn = e.target.closest('[data-test-id*="send"], [data-test-id*="submit"], button[aria-label*="Send" i], [data-test-id="omni-composer-send-button"]');
        if (btn) {
          tState.manualResetTime = Date.now();
          tState.msgId = '';
          tState.baseElapsedSec = 0;
          tState.anchorTime = Date.now();
          setTimeout(updateTimerDisplay, 80);
        }
      }
    } catch(err) {}
  }
  document.addEventListener('keydown', handleSendTrigger, true);
  document.addEventListener('click', handleSendTrigger, true);
  return function cleanupSendResetListener() {
    document.removeEventListener('keydown', handleSendTrigger, true);
    document.removeEventListener('click', handleSendTrigger, true);
  };
}
let cleanupSendReset = null; function createFloatingTimerWidget() { if (document.getElementById(TIMER_ID)) return; const widget = document.createElement('div'); widget.id = TIMER_ID; widget.innerHTML = ` <div id="zd-timer-drag-handle" title="Drag to move (click logo to toggle keep-expanded)"> <button id="zd-timer-clock-btn" class="zd-timer-clock-icon-btn" type="button" title="Click logo to keep expanded"> <span id="zd-timer-icon"> <img id="zd-timer-logo" alt="ZenX" /> </span> <span id="zd-timer-collapsed-display" aria-hidden="true"></span> </button> </div> <div id="zd-timer-expandable"> <div id="zd-timer-info" title="Drag to move"> <span id="zd-timer-ticket" class="zd-timer-ticket-pill" title="Current Ticket">#--</span> <span id="zd-timer-display">--:--</span> <span id="zd-timer-badge">Auto</span> </div> <div id="zd-timer-controls"> <button id="zd-timer-sla-btn" class="zd-timer-pill zd-timer-sla-pill" type="button" style="display:none;" title="Active SLA (click to cycle 1m / 2m / 5m)">2m</button> <button id="zd-timer-btn-macro" class="zd-timer-pill" type="button" title="Toggle macro suggestions">⚡</button> <button id="zd-timer-btn-mute" class="zd-timer-pill" type="button" title="Toggle audio alert">🔔</button> <button id="zd-theme-toggle" class="zd-timer-pill" type="button" aria-pressed="true" title="Switch theme">☀️</button> </div> <div class="zd-sections-wrap"> <button id="zd-sections-toggle-btn" class="zd-timer-pill" title="Choose which left sidebar sections to show">Sidebar ▾</button> <div id="zd-sections-dropdown" style="display:none;"> <div class="zd-sections-head"> <span>Left sidebar sections</span> <button id="zd-sections-scan" class="zd-sec-mini-btn" title="Refresh section list">Scan</button> <button id="zd-sections-defaults" class="zd-sec-mini-btn" title="Hide Tags & Also here">Default</button> <button id="zd-sections-showall" class="zd-sec-mini-btn" title="Show all sections">All</button> </div> <div id="zd-sections-list"></div> </div> </div> </div> <div id="zd-timer-macro-popup" style="display:none;" title="Click to populate macro into chat"> <div class="zd-macro-popup-header"> <span id="zd-macro-popup-badge">⚡ Quick Macro</span> <button id="zd-macro-popup-close" class="zd-macro-popup-close" title="Dismiss" type="button">✕</button> </div> <div class="zd-macro-popup-body" id="zd-macro-popup-text"></div> </div> `; const styleEl = document.createElement('style'); styleEl.id = TIMER_ID + '-css'; styleEl.textContent = ` #${TIMER_ID} { position: fixed; z-index: 2147483647; display: flex; align-items: center; gap: 8px; padding: 5px 12px; height: 38px; max-width: 620px; background: rgba(15, 23, 42, 0.92); border: 1px solid rgba(255, 255, 255, 0.2); border-radius: 9999px; box-shadow: 0 4px 20px rgba(0, 0, 0, 0.45); color: #ffffff; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; font-size: 12px; user-select: none; backdrop-filter: blur(10px); -webkit-backdrop-filter: blur(10px); transition: max-width 0.42s cubic-bezier(0.16, 1, 0.3, 1), padding 0.32s cubic-bezier(0.16, 1, 0.3, 1), gap 0.32s cubic-bezier(0.16, 1, 0.3, 1), border-color 0.25s, box-shadow 0.25s, background-color 0.25s, transform 0.15s ease; box-sizing: border-box; white-space: nowrap; overflow: visible; } html.zskin-light #${TIMER_ID} { background: rgba(255, 255, 255, 0.96); border: 1px solid rgba(0, 0, 0, 0.16); box-shadow: 0 4px 18px rgba(0, 0, 0, 0.14); color: #0f172a; } #${TIMER_ID}:hover { border-color: rgba(56, 189, 248, 0.5); } html.zskin-light #${TIMER_ID}:hover { border-color: rgba(2, 132, 199, 0.45); } #${TIMER_ID} { overflow: visible !important; } #${TIMER_ID}.zd-animating { overflow: visible !important; } #${TIMER_ID}.zd-collapsed { width: 38px !important; min-width: 38px !important; max-width: 38px !important; height: 38px !important; padding: 0 !important; gap: 0 !important; justify-content: center !important; cursor: pointer; overflow: visible !important; } #${TIMER_ID}.zd-collapsed.zd-countdown-active { width: 66px !important; min-width: 66px !important; max-width: 66px !important; } #${TIMER_ID}.zd-collapsed.zd-macro-visible-collapsed { overflow: visible !important; } #zd-timer-collapsed-display { display: none; font-family: "SFMono-Regular", Consolas, "Liberation Mono", Menlo, monospace; font-size: 10px; font-weight: 700; letter-spacing: -0.2px; line-height: 1; white-space: nowrap; font-variant-numeric: tabular-nums; color: inherit; } #${TIMER_ID}.zd-collapsed.zd-countdown-active #zd-timer-icon { display: none !important; } #${TIMER_ID}.zd-collapsed.zd-countdown-active #zd-timer-collapsed-display { display: inline-flex; align-items: center; justify-content: center; } #${TIMER_ID}.zd-collapsed:hover { border-color: rgba(56, 189, 248, 0.7) !important; box-shadow: 0 4px 18px rgba(0, 0, 0, 0.6), 0 0 12px rgba(56, 189, 248, 0.45) !important; } html.zskin-light #${TIMER_ID}.zd-collapsed:hover { border-color: rgba(2, 132, 199, 0.7) !important; box-shadow: 0 4px 16px rgba(0, 0, 0, 0.22), 0 0 10px rgba(2, 132, 199, 0.35) !important; } #zd-timer-drag-handle { display: flex; align-items: center; justify-content: center; cursor: grab; flex-shrink: 0; } #zd-timer-drag-handle:active { cursor: grabbing; } #${TIMER_ID}.zd-collapsed #zd-timer-drag-handle { width: 100% !important; height: 100% !important; } .zd-timer-clock-icon-btn { background: transparent; border: 1px solid transparent; padding: 0; margin: 0; cursor: pointer; display: inline-flex; align-items: center; justify-content: center; border-radius: 9999px; outline: none; color: inherit; font-size: 16px; line-height: 1; width: 26px; height: 26px; transition: transform 0.2s, background-color 0.2s, border-color 0.2s, box-shadow 0.2s; } .zd-timer-clock-icon-btn:hover { transform: scale(1.12); } .zd-timer-clock-icon-btn.zd-clock-pinned { background: rgba(56, 189, 248, 0.24); border-color: rgba(56, 189, 248, 0.6); box-shadow: 0 0 10px rgba(56, 189, 248, 0.45); } html.zskin-light .zd-timer-clock-icon-btn.zd-clock-pinned { background: rgba(2, 132, 199, 0.16); border-color: rgba(2, 132, 199, 0.5); box-shadow: 0 0 8px rgba(2, 132, 199, 0.35); } #zd-timer-icon { display: inline-flex; align-items: center; justify-content: center; width: 20px; height: 20px; transform-origin: 50% 50%; transition: transform 0.48s cubic-bezier(0.2, 0.8, 0.25, 1), filter 0.22s ease; transform: rotate(360deg); user-select: none; } #zd-timer-logo { display: block; width: 20px; height: 20px; object-fit: contain; flex-shrink: 0; border-radius: 6px; } #${TIMER_ID}.zd-collapsed #zd-timer-icon { transform: rotate(0deg); } #${TIMER_ID}.zd-timer-warning #zd-timer-logo { filter: drop-shadow(0 0 4px rgba(251,191,36,.75)); } #${TIMER_ID}.zd-timer-urgent #zd-timer-logo { filter: drop-shadow(0 0 5px rgba(239,68,68,.85)); } #zd-timer-expandable { display: flex; align-items: center; gap: 8px; max-width: 580px; opacity: 1; transform: translateX(0); transition: max-width 0.42s cubic-bezier(0.16, 1, 0.3, 1), opacity 0.26s cubic-bezier(0.16, 1, 0.3, 1) 0.04s, transform 0.36s cubic-bezier(0.16, 1, 0.3, 1); } #${TIMER_ID}.zd-collapsed #zd-timer-expandable { max-width: 0 !important; opacity: 0 !important; transform: translateX(-14px) !important; overflow: hidden !important; pointer-events: none !important; visibility: hidden !important; margin: 0 !important; padding: 0 !important; transition: max-width 0.36s cubic-bezier(0.16, 1, 0.3, 1), opacity 0.15s ease-in, transform 0.2s ease-in, visibility 0s 0.36s; } #zd-timer-info { display: flex; align-items: center; gap: 6px; padding-right: 8px; border-right: 1px solid rgba(255, 255, 255, 0.14); cursor: grab; } html.zskin-light #zd-timer-info { border-right: 1px solid rgba(0, 0, 0, 0.12); } #zd-timer-info:active { cursor: grabbing; } #zd-timer-macro-popup { position: absolute !important; left: calc(100% + 10px) !important; right: auto !important; top: 0 !important; width: 380px !important; max-width: 420px !important; background: #0f172a !important; border: 2px solid #ef4444 !important; border-radius: 12px !important; box-shadow: 0 12px 32px rgba(0, 0, 0, 0.7), 0 0 14px rgba(239, 68, 68, 0.4) !important; padding: 10px 12px !important; display: flex; flex-direction: column; gap: 6px !important; z-index: 2147483647 !important; color: #f8fafc !important; transition: border-color 0.2s, box-shadow 0.2s !important; box-sizing: border-box !important; white-space: normal !important; pointer-events: auto !important; } /* Removed hover bridge to prevent false pill hover when approaching macro */ #zd-timer-macro-popup::before { display: none !important; pointer-events: none !important; } #zd-timer-macro-popup:hover { border-color: #f87171 !important; box-shadow: 0 14px 36px rgba(0, 0, 0, 0.75), 0 0 18px rgba(239, 68, 68, 0.55) !important; } html.zskin-light #zd-timer-macro-popup { background: #ffffff !important; border-color: #ef4444 !important; box-shadow: 0 12px 32px rgba(0, 0, 0, 0.22), 0 0 12px rgba(239, 68, 68, 0.35) !important; color: #0f172a !important; } .zd-macro-popup-header { display: flex; align-items: center; justify-content: space-between; gap: 6px; font-size: 11px; font-weight: 700; color: #f87171; text-transform: uppercase; letter-spacing: 0.5px; white-space: nowrap !important; margin-bottom: 2px; } html.zskin-light .zd-macro-popup-header { color: #dc2626; } .zd-macro-popup-subtitle { font-size: 10.5px; color: #94a3b8; margin-bottom: 4px; line-height: 1.3; } html.zskin-light .zd-macro-popup-subtitle { color: #64748b; } .zd-macro-popup-close { background: transparent; border: none; color: #94a3b8; font-size: 13px; font-weight: 700; cursor: pointer; padding: 2px 5px; border-radius: 4px; line-height: 1; } .zd-macro-popup-close:hover { color: #ffffff; background: rgba(255, 255, 255, 0.15); } html.zskin-light .zd-macro-popup-close:hover { color: #0f172a; background: rgba(0, 0, 0, 0.08); } .zd-macro-popup-body { display: flex; flex-direction: column; gap: 6px; } .zd-macro-option { font-size: 11.5px; line-height: 1.4; color: #f1f5f9 !important; background: rgba(255, 255, 255, 0.05); border: 1px solid rgba(255, 255, 255, 0.16); border-radius: 7px; padding: 7px 9px; cursor: pointer !important; transition: background 0.15s ease, border-color 0.15s ease, transform 0.1s ease; text-align: left; user-select: none; } .zd-macro-option:hover { background: rgba(56, 189, 248, 0.16) !important; border-color: #38bdf8 !important; transform: translateX(2px); } html.zskin-light .zd-macro-option { color: #0f172a !important; background: #f8fafc; border-color: #cbd5e1; } html.zskin-light .zd-macro-option:hover { background: #e0f2fe !important; border-color: #0284c7 !important; } .zd-macro-option-badge { display: block; font-size: 9px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.5px; color: #38bdf8; margin-bottom: 2px; } html.zskin-light .zd-macro-option-badge { color: #0284c7; } .zd-macro-option-text { font-size: 11.5px; line-height: 1.4; word-break: normal; overflow-wrap: break-word; } 
.zd-timer-ticket-pill {
  font-family: "SFMono-Regular", Consolas, "Liberation Mono", Menlo, monospace;
  font-size: 11px;
  font-weight: 700;
  padding: 2px 7px;
  border-radius: 9999px;
  background: rgba(56, 189, 248, 0.18);
  border: 1px solid rgba(56, 189, 248, 0.42);
  color: #38bdf8;
  letter-spacing: 0.2px;
  max-width: 110px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
}
html.zskin-light .zd-timer-ticket-pill {
  background: #e0f2fe;
  border-color: #7dd3fc;
  color: #0284c7;
}
 #zd-timer-display { font-family: "SFMono-Regular", Consolas, "Liberation Mono", Menlo, monospace; font-size: 14px; font-weight: 700; letter-spacing: 0.5px; min-width: 48px; text-align: center; color: #38bdf8; } html.zskin-light #zd-timer-display { color: #0284c7; } #zd-timer-badge { font-size: 10px; font-weight: 600; text-transform: uppercase; padding: 2px 6px; border-radius: 9999px; background: rgba(255, 255, 255, 0.12); color: #94a3b8; letter-spacing: 0.3px; } html.zskin-light #zd-timer-badge { background: #e2e8f0; color: #475569; } #zd-timer-controls { display: flex; align-items: center; gap: 4px; } .zd-timer-pill { border: none; background: rgba(255, 255, 255, 0.08); color: #cbd5e1; padding: 3px 8px; border-radius: 9999px; cursor: pointer; font-size: 11px; font-weight: 600; transition: background-color 0.18s, color 0.18s, transform 0.12s; outline: none; } html.zskin-light .zd-timer-pill { background: #f1f5f9; color: #334155; border: 1px solid #e2e8f0; } .zd-timer-pill:hover { background: rgba(255, 255, 255, 0.2); color: #ffffff; transform: translateY(-1px); } html.zskin-light .zd-timer-pill:hover { background: #e2e8f0; color: #0f172a; } .zd-pill-off { opacity: 0.52 !important; background: rgba(255, 255, 255, 0.04) !important; } html.zskin-light .zd-pill-off { opacity: 0.52 !important; background: #f1f5f9 !important; color: #94a3b8 !important; } .zd-timer-sla-pill { background: rgba(56, 189, 248, 0.16) !important; border: 1px solid rgba(56, 189, 248, 0.42) !important; color: #38bdf8 !important; font-weight: 700 !important; padding: 3px 8px !important; letter-spacing: 0.3px; } .zd-timer-sla-pill:hover { background: rgba(56, 189, 248, 0.28) !important; border-color: rgba(56, 189, 248, 0.75) !important; color: #ffffff !important; transform: translateY(-1px); } html.zskin-light .zd-timer-sla-pill { background: rgba(2, 132, 199, 0.12) !important; border: 1px solid rgba(2, 132, 199, 0.35) !important; color: #0284c7 !important; } html.zskin-light .zd-timer-sla-pill:hover { background: rgba(2, 132, 199, 0.22) !important; color: #0369a1 !important; } #${TIMER_ID}.zd-timer-warning { border-color: #f59e0b !important; box-shadow: 0 0 16px rgba(245, 158, 11, 0.45) !important; } #${TIMER_ID}.zd-timer-warning #zd-timer-display { color: #fbbf24 !important; } #${TIMER_ID}.zd-timer-urgent { background: rgba(220, 38, 38, 0.95) !important; border-color: #ef4444 !important; box-shadow: 0 0 22px rgba(239, 68, 68, 0.8) !important; animation: zd-timer-pulse 0.9s infinite alternate; } #${TIMER_ID}.zd-timer-urgent #zd-timer-display, #${TIMER_ID}.zd-timer-urgent #zd-timer-badge { color: #ffffff !important; font-weight: 800 !important; } @keyframes zd-timer-pulse { 0% { transform: scale(1); filter: brightness(1); } 100% { transform: scale(1.03); filter: brightness(1.2); } } .zd-sections-wrap { position: relative; } #zd-sections-dropdown { position: absolute; width: 260px; max-height: 340px; right: 0; background: #0f172a; border: 1px solid rgba(255, 255, 255, 0.2); border-radius: 12px; box-shadow: 0 10px 30px rgba(0,0,0,0.6); padding: 10px; flex-direction: column; gap: 8px; z-index: 1000000; color: #e2e8f0; } html.zskin-light #zd-sections-dropdown { background: #ffffff; border-color: #cbd5e1; box-shadow: 0 10px 30px rgba(0,0,0,0.18); color: #1e293b; } .zd-sections-head { display: flex; align-items: center; gap: 6px; font-size: 11px; font-weight: 700; border-bottom: 1px solid rgba(255, 255, 255, 0.12); padding-bottom: 6px; } html.zskin-light .zd-sections-head { border-bottom: 1px solid #e2e8f0; } .zd-sections-head span { flex: 1; color: #94a3b8; } html.zskin-light .zd-sections-head span { color: #64748b; } .zd-sec-mini-btn { background: rgba(255, 255, 255, 0.1); border: none; color: #cbd5e1; border-radius: 4px; padding: 2px 6px; font-size: 10px; cursor: pointer; } html.zskin-light .zd-sec-mini-btn { background: #f1f5f9; color: #334155; } .zd-sec-mini-btn:hover { background: rgba(255, 255, 255, 0.2); color: #fff; } html.zskin-light .zd-sec-mini-btn:hover { background: #e2e8f0; } #zd-sections-list { display: flex; flex-direction: column; gap: 4px; overflow-y: auto; max-height: 260px; } #zd-sections-dropdown::before { content: ""; position: absolute; top: -12px; left: 0; right: 0; height: 14px; background: transparent; } .zd-section-item { display: flex; align-items: center; gap: 8px; font-size: 11px; padding: 4px 6px; border-radius: 6px; cursor: pointer; color: #f1f5f9 !important; } .zd-section-item * { color: #f1f5f9 !important; } .zd-section-item span { color: #f1f5f9 !important; font-weight: 500 !important; font-size: 11px !important; user-select: none; } .zd-section-item:hover { background: rgba(255, 255, 255, 0.12); } html.zskin-light .zd-section-item, html.zskin-light .zd-section-item *, html.zskin-light .zd-section-item span { color: #1e293b !important; } html.zskin-light .zd-section-item:hover { background: #f8fafc; } .zd-section-item input { margin: 0; cursor: pointer; } `; styleEl.textContent += '\n #zd-timer-macro-popup.zenx-manual-macros { border-color: rgba(56,189,248,.56) !important; box-shadow:0 16px 45px rgba(0,0,0,.58) !important; max-height:min(560px, calc(100vh - 28px)) !important; overflow:auto !important; overscroll-behavior:contain !important; width:min(420px, calc(100vw - 22px)) !important; }\n #zd-timer-macro-popup .zenx-macro-categories { display:grid; grid-template-columns:repeat(2,minmax(0,1fr)); gap:9px; }\n #zd-timer-macro-popup .zenx-macro-category { text-align:left; cursor:pointer; color:#edf7f9; padding:12px 10px; background:rgba(56,189,248,.09); border:1px solid rgba(148,163,184,.27); border-radius:10px; min-height:74px; }\n #zd-timer-macro-popup .zenx-macro-category:hover, #zd-timer-macro-popup .zenx-macro-category:focus-visible { background:rgba(56,189,248,.23); border-color:#38bdf8; outline:none; }\n #zd-timer-macro-popup .zenx-macro-category strong { display:block; font-size:13px; margin-bottom:4px; }\n #zd-timer-macro-popup .zenx-macro-category small { display:block; font-size:11px; line-height:1.35; color:#b4c8d3; }\n #zd-timer-macro-popup .zenx-macro-action { width:100%; font-size:12px; padding:9px; color:#e2e8f0; background:rgba(148,163,184,.11); border:1px solid rgba(148,163,184,.3); border-radius:8px; text-align:left; cursor:pointer; }\n #zd-timer-macro-popup .zenx-macro-action:hover { border-color:#38bdf8; background:rgba(56,189,248,.12); }\n #zd-timer-macro-popup .zenx-macro-menu-note { padding:6px 2px; color:#a5b9c4; font-size:11px; line-height:1.45; }\n #zd-timer-macro-popup.zenx-manual-macros .zd-macro-option { display:block; width:100%; font-family:inherit; }\n html.zskin-light #zd-timer-macro-popup .zenx-macro-category {color:#1e293b;background:#eef6fa;border-color:#c4d4db;}\n html.zskin-light #zd-timer-macro-popup .zenx-macro-category small, html.zskin-light #zd-timer-macro-popup .zenx-macro-menu-note {color:#556774;}\n html.zskin-light #zd-timer-macro-popup .zenx-macro-action {color:#233748;background:#edf3f6;border-color:#c4d4db;}\n';
 document.head.appendChild(styleEl); let savedPos = safeStorage.getItem('zd_timer_pos'); let posX = Math.max(16, window.innerWidth - 760); let posY = 12; if (savedPos) { try { const p = JSON.parse(savedPos); const sx = typeof p.left === 'number' ? p.left : (typeof p.x === 'number' ? p.x : null); const sy = typeof p.top === 'number' ? p.top : (typeof p.y === 'number' ? p.y : null); if (sx !== null && sy !== null) { posX = Math.min(Math.max(10, sx), Math.max(10, window.innerWidth - 140)); posY = Math.min(Math.max(5, sy), Math.max(5, window.innerHeight - 50)); } } catch(e) {} } widget.style.left = posX + 'px'; widget.style.top = posY + 'px'; widget.style.right = 'auto'; widget.style.bottom = 'auto'; (document.body || document.documentElement).appendChild(widget); const PIN_KEY = 'zd_timer_pinned'; let isPinned = (() => { try { const val = safeStorage.getItem(PIN_KEY); if (val !== null) return val === 'true'; const oldCol = safeStorage.getItem('zd_timer_collapsed'); if (oldCol === 'false') return true; } catch(e) {} return false; })(); let isPillHovered = false; let isMacroHovered = false; let suppressHover = false; let animTimeout = null; let hoverCollapseTimer = null; const dragHandle = widget.querySelector('#zd-timer-drag-handle'); const timerInfo = widget.querySelector('#zd-timer-info'); const clockBtn = widget.querySelector('#zd-timer-clock-btn'); const timerLogo = widget.querySelector('#zd-timer-logo'); if (timerLogo) { try { timerLogo.src = chrome.runtime.getURL('Icons/icon32.png'); } catch(e) {} } const slaBtn = widget.querySelector('#zd-timer-sla-btn'); const setSlaButtonVisible = visible => { if (slaBtn) slaBtn.style.setProperty('display', visible ? 'inline-flex' : 'none', 'important'); }; setSlaButtonVisible(false); const macroPopup = widget.querySelector('#zd-timer-macro-popup');
let zenxMacroChooser = 'closed'; // closed | categories | category
let zenxManualMacroCategory = ''; function isEventOverMacro(e) { if (!macroPopup || macroPopup.style.display === 'none') return false; if (e && e.target && (e.target === macroPopup || macroPopup.contains(e.target))) return true; if (e && typeof e.clientX === 'number' && typeof e.clientY === 'number') { const el = document.elementFromPoint(e.clientX, e.clientY); if (el && (el === macroPopup || macroPopup.contains(el))) return true; } return false; } if (macroPopup) { macroPopup.addEventListener('mouseenter', () => { isMacroHovered = true; if (hoverCollapseTimer) { clearTimeout(hoverCollapseTimer); hoverCollapseTimer = null; } }); macroPopup.addEventListener('mouseleave', (e) => { isMacroHovered = false; if (e.relatedTarget && widget.contains(e.relatedTarget) && !macroPopup.contains(e.relatedTarget)) { isPillHovered = true; if (hoverCollapseTimer) { clearTimeout(hoverCollapseTimer); hoverCollapseTimer = null; } if (!isDragging && !suppressHover) { renderExpansion(true); } return; } if (isDragging || isPinned || isDropdownActive() || isPillHovered) return; if (hoverCollapseTimer) clearTimeout(hoverCollapseTimer); hoverCollapseTimer = setTimeout(() => { if (!isPillHovered && !isMacroHovered && !isPinned && !isDragging && !isDropdownActive()) { renderExpansion(true); } }, 300); }); } const dropdownMenu = widget.querySelector('#zd-sections-dropdown'); if (dropdownMenu) { dropdownMenu.addEventListener('mouseenter', () => { isPillHovered = true; if (hoverCollapseTimer) { clearTimeout(hoverCollapseTimer); hoverCollapseTimer = null; } }); } const macroBody = widget.querySelector('#zd-macro-popup-text'); function isMacroAlertActive() { return !!(macroPopup && macroPopup.style.display !== 'none'); } function isDropdownActive() { const dd = widget.querySelector('#zd-sections-dropdown'); return !!(dd && dd.style.display !== 'none'); } function shouldBeExpanded() { if (isPinned) return true; if (isDropdownActive()) return true; if (isPillHovered && !suppressHover) return true; return false; } function updateWidgetMetadata(isExp) { const displayEl = widget.querySelector('#zd-timer-display'); const badgeEl = widget.querySelector('#zd-timer-badge'); const ticketEl = widget.querySelector('#zd-timer-ticket'); const ticketText = (ticketEl && ticketEl.textContent && ticketEl.textContent !== 'Idle') ? `[${ticketEl.textContent}] ` : ''; const timeText = displayEl ? displayEl.textContent : ''; const badgeText = badgeEl ? badgeEl.textContent : ''; if (isPinned) { widget.classList.add('zd-pinned'); if (clockBtn) { clockBtn.classList.add('zd-clock-pinned'); clockBtn.title = 'Pinned open — Click logo to collapse into hover mode'; } } else { widget.classList.remove('zd-pinned'); if (clockBtn) { clockBtn.classList.remove('zd-clock-pinned'); clockBtn.title = isExp ? 'Click logo to keep expanded (drag to move)' : `SLA Timer: ${ticketText}${timeText} (${badgeText}) — Hover to peek, click logo to pin open`; } } if (!isExp) { widget.title = `SLA Timer: ${ticketText}${timeText} (${badgeText}) — Hover to peek, click to pin open (drag to move)`; } else { widget.removeAttribute('title'); } } function renderExpansion(animate = true) { const wantExpanded = shouldBeExpanded(); if (animate) { widget.classList.add('zd-animating'); if (animTimeout) clearTimeout(animTimeout); animTimeout = setTimeout(() => { if (widget && widget.classList) { widget.classList.remove('zd-animating'); } }, 450); } if (wantExpanded) { widget.classList.remove('zd-collapsed'); } else { widget.classList.add('zd-collapsed'); const dd = widget.querySelector('#zd-sections-dropdown'); if (dd) dd.style.display = 'none'; } widget.classList.toggle('zd-macro-visible-collapsed', !wantExpanded && isMacroAlertActive()); updateWidgetMetadata(wantExpanded); } function togglePin(forceState) { if (typeof forceState === 'boolean') { isPinned = forceState; } else { isPinned = !isPinned; } try { safeStorage.setItem(PIN_KEY, String(isPinned)); } catch(e) {} if (!isPinned) { suppressHover = true; } else { suppressHover = false; } renderExpansion(true); } widget.addEventListener('mouseenter', (e) => { if (isEventOverMacro(e)) { return; } isPillHovered = true; if (hoverCollapseTimer) { clearTimeout(hoverCollapseTimer); hoverCollapseTimer = null; } if (!isDragging && !suppressHover) { renderExpansion(true); } }); widget.addEventListener('mouseover', (e) => { if (isEventOverMacro(e)) { return; } if (!isPillHovered && !isDragging && !suppressHover) { isPillHovered = true; if (hoverCollapseTimer) { clearTimeout(hoverCollapseTimer); hoverCollapseTimer = null; } renderExpansion(true); } }); widget.addEventListener('mouseleave', (e) => { if (e.relatedTarget && widget.contains(e.relatedTarget)) { return; } isPillHovered = false; suppressHover = false; if (isDragging || isPinned || isDropdownActive() || isMacroHovered) return; if (hoverCollapseTimer) clearTimeout(hoverCollapseTimer); hoverCollapseTimer = setTimeout(() => { if (!isPillHovered && !isMacroHovered && !isPinned && !isDragging && !isDropdownActive()) { renderExpansion(true); } }, 300); }); let isDragging = false; let hasDragged = false; let dragStartX = 0; let dragStartY = 0; let widgetStartX = 0; let widgetStartY = 0; function onDragStart(e) { if (shouldBeExpanded() && e.target.closest('button') && !e.target.closest('#zd-timer-drag-handle')) { return; } isDragging = true; hasDragged = false; dragStartX = e.clientX; dragStartY = e.clientY; const rect = widget.getBoundingClientRect(); widgetStartX = rect.left; widgetStartY = rect.top; if (!e.target.closest('button')) { e.preventDefault(); } } if (dragHandle) dragHandle.addEventListener('mousedown', onDragStart); if (timerInfo) timerInfo.addEventListener('mousedown', onDragStart); window.addEventListener('mousemove', e => { if (!isDragging) return; const dx = e.clientX - dragStartX; const dy = e.clientY - dragStartY; if (Math.hypot(dx, dy) > 4) { hasDragged = true; } if (hasDragged) { const newX = Math.min(Math.max(10, widgetStartX + dx), window.innerWidth - widget.offsetWidth - 10); const newY = Math.min(Math.max(5, widgetStartY + dy), window.innerHeight - widget.offsetHeight - 10); widget.style.left = newX + 'px'; widget.style.top = newY + 'px'; } }); window.addEventListener('mouseup', () => { if (isDragging) { isDragging = false; if (hasDragged) { const rect = widget.getBoundingClientRect(); safeStorage.setItem('zd_timer_pos', JSON.stringify({ x: rect.left, y: rect.top })); } } }); if (clockBtn) { clockBtn.addEventListener('click', (e) => { e.stopPropagation(); if (hasDragged) { hasDragged = false; return; } togglePin(); }); } renderExpansion(false); if (slaBtn) { slaBtn.addEventListener('click', (e) => { e.stopPropagation(); getAudioContext(); const ticketInfo = getActiveTicketDetails(); const tState = getTicketState(ticketInfo.ticketKey); const state = evaluateAgentSLA(); const curSec = tState.manualDurationOverride || state.durationSec || 120; let nextSec = 120; if (curSec === 60) nextSec = 120; else if (curSec === 120) nextSec = 300; else if (curSec === 300) nextSec = 60; else nextSec = 120; tState.manualDurationOverride = nextSec; tState.hasBeeped1Min = false; tState.baseElapsedSec = 0; tState.anchorTime = Date.now(); zenxResetTabCountdown(ticketInfo.ticketId, nextSec); updateTimerDisplay(); }); } const btnMute = widget.querySelector('#zd-timer-btn-mute'); const btnTheme = widget.querySelector('#zd-theme-toggle'); if (btnTheme) { btnTheme.textContent = darkMode ? '☀️' : '🌙'; btnTheme.title = darkMode ? 'Switch to light theme' : 'Switch to dark theme'; btnTheme.setAttribute('aria-pressed', String(darkMode)); } if (btnMute) { btnMute.textContent = isMuted ? '🔇' : '🔔'; btnMute.title = isMuted ? 'Audio muted (click to unmute)' : 'Audio active (click to mute)'; } btnMute.addEventListener('click', () => { isMuted = !isMuted; try { safeStorage.setItem(MUTE_KEY, String(isMuted)); } catch(e) {} btnMute.textContent = isMuted ? '🔇' : '🔔'; btnMute.title = isMuted ? 'Alerts muted (click to unmute)' : 'Alerts active (click to mute)'; updateTimerDisplay(); }); function positionMacroPopup() {
 const popup=widget.querySelector('#zd-timer-macro-popup');
 if (!popup) return;
 const rect=widget.getBoundingClientRect();
 const width=Math.min(420,Math.max(250,window.innerWidth-24));
 const rightSpace=window.innerWidth-rect.right-12;
 const leftSpace=rect.left-12;
 if (rightSpace>=width) {
   popup.style.setProperty('left','calc(100% + 10px)','important');
   popup.style.setProperty('right','auto','important');
 } else if (leftSpace>=width) {
   popup.style.setProperty('left','auto','important');
   popup.style.setProperty('right','calc(100% + 10px)','important');
 } else {
   popup.style.setProperty('left',`${Math.max(8, Math.min(window.innerWidth-width-8,rect.left))-rect.left}px`,'important');
   popup.style.setProperty('right','auto','important');
 }
 const expected=Math.min(560,Math.max(280,popup.scrollHeight));
 if (rect.top+expected>window.innerHeight-12 && rect.bottom-expected>=12) {
   popup.style.setProperty('top','auto','important');
   popup.style.setProperty('bottom','0','important');
 } else {
   popup.style.setProperty('top',`${Math.max(8-rect.top,0)}px`,'important');
   popup.style.setProperty('bottom','auto','important');
 }
}
function zenxShowMacroCategories() {
 zenxMacroChooser='categories';
 zenxManualMacroCategory='';
 macroPopup.dataset.zenxManual='true';
 macroPopup.classList.add('zenx-manual-macros');
 const badge=widget.querySelector('#zd-macro-popup-badge');
 if (badge) badge.textContent='⚡ Quick replies';
 if (!isMacrosEnabled) {
   macroBody.innerHTML='<div class="zenx-macro-menu-note">Quick replies are turned off.</div>'+
     '<button class="zenx-macro-action" type="button" data-zenx-action="enable">Enable macros</button>';
 } else {
   macroBody.innerHTML='<div class="zenx-macro-menu-note">Choose a message category. Selecting a message fills the reply draft; it will not send automatically.</div>'+
     '<div class="zenx-macro-categories">'+Object.entries(ZENX_QUICK_MACROS).map(([key,item])=>
       `<button type="button" class="zenx-macro-category" data-zenx-category="${key}"><strong>${escapeHtml(item.title)}</strong><small>${escapeHtml(item.caption)}</small></button>`).join('')+'</div>'+
     '<button class="zenx-macro-action" type="button" data-zenx-action="disable">Turn off macros</button>';
 }
 if (globalThis.zenxCustomMacros) {
   macroBody.insertAdjacentHTML('beforeend', '<button class="zenx-macro-action" type="button" data-zenx-action="custom">Custom Macros</button>');
 }
 macroPopup.style.setProperty('display','flex','important');
 positionMacroPopup();
}
function zenxShowMacroCategory(category) {
 const item=ZENX_QUICK_MACROS[category];
 if (!item || !isMacrosEnabled) return;
 zenxMacroChooser='category';
 zenxManualMacroCategory=category;
 activeMacroList=item.messages.slice();
 activeMacroText=activeMacroList[0];
 const badge=widget.querySelector('#zd-macro-popup-badge');
 if (badge) badge.textContent='⚡ '+item.title+' messages';
 macroBody.innerHTML='<button class="zenx-macro-action" type="button" data-zenx-action="back">← All categories</button>'+
   `<div class="zenx-macro-menu-note">${escapeHtml(item.caption)}. Review and personalize the message before sending.</div>`+
   activeMacroList.map((t,idx)=>`<button class="zd-macro-option" type="button" data-macro-idx="${idx}"><span class="zd-macro-option-badge">Option ${idx+1}</span><span class="zd-macro-option-text">${escapeHtml(t)}</span></button>`).join('');
 macroPopup.style.setProperty('display','flex','important');
 positionMacroPopup();
}
function zenxDismissMacroChooser() {
 zenxMacroChooser='closed';
 zenxManualMacroCategory='';
 macroPopup.dataset.zenxManual='false';
 macroPopup.classList.remove('zenx-manual-macros');
 macroPopup.style.setProperty('display','none','important');
 const current=evaluateAgentSLA();
 const d=current.durationSec||120;
 macroDismissedId=(current.msgId||'')+'_'+d;
}
 if (macroPopup) { macroPopup.addEventListener('click', async (e) => { e.stopPropagation(); if (e.target.closest('#zd-macro-popup-close')) { e.stopPropagation();
if (zenxMacroChooser!=='closed') { zenxDismissMacroChooser(); renderExpansion(true); return; } const state = evaluateAgentSLA(); const curDuration = manualDurationOverride || state.durationSec || 120; macroDismissedId = (state.msgId || '') + '_' + curDuration; macroPopup.style.setProperty('display', 'none', 'important'); renderExpansion(true); return;  }
 const categoryBtn=e.target.closest('[data-zenx-category]');
 if (categoryBtn) { zenxShowMacroCategory(categoryBtn.getAttribute('data-zenx-category')); return; }
 const actionBtn=e.target.closest('[data-zenx-action]');
 if (actionBtn) {
   const action=actionBtn.getAttribute('data-zenx-action');
   if (action==='custom') {
     zenxDismissMacroChooser();
     renderExpansion(true);
     globalThis.zenxCustomMacros?.open();
     return;
   }
   if (action==='back') {zenxShowMacroCategories();return;}
   if (action==='disable'||action==='enable') {
     isMacrosEnabled=action==='enable';
     try {safeStorage.setItem(MACRO_KEY,String(isMacrosEnabled));} catch (_) {}
     refreshMacroButton();zenxShowMacroCategories();return;
   }
 }
 const optionEl = e.target.closest('.zd-macro-option');
 if (!optionEl) return; const idx = parseInt(optionEl.getAttribute('data-macro-idx'), 10); const textToInsert = (activeMacroList && activeMacroList[idx]) ? activeMacroList[idx] : activeMacroText; if (!textToInsert) return; if (macroPopup.dataset.insertPending === 'true') return; macroPopup.dataset.insertPending = 'true'; optionEl.style.opacity = '0.65'; const backupCopy = (() => { try { return navigator.clipboard?.writeText(textToInsert).then(() => true, () => false) || Promise.resolve(false); } catch (_) { return Promise.resolve(false); } })(); const inserted = await populateZendeskComposer(textToInsert); delete macroPopup.dataset.insertPending; optionEl.style.opacity = ''; if (!inserted) { const copied = await backupCopy; if (macroBody) { macroBody.innerHTML = '<div style="color:#f87171; font-weight:700; padding:6px; text-align:center;">Could not verify the macro in the Zendesk reply box.' + (copied ? ' The text was copied to your clipboard; paste it with Ctrl+V.' : ' Click the reply box and try again.') + '</div>'; } return; } macroCopiedRecently = true; optionEl.style.setProperty('border-color', '#22c55e', 'important'); optionEl.style.setProperty('background', 'rgba(34, 197, 94, 0.22)', 'important'); if (macroBody) { macroBody.innerHTML = `<div style="color:#22c55e; font-weight:700; padding:10px 6px; text-align:center; font-size:12px;">✓ Added Format ${idx + 1} to the reply draft. Review before sending.</div>`; } setTimeout(() => { const state = evaluateAgentSLA(); const curDuration = manualDurationOverride || state.durationSec || 120; macroDismissedId = (state.msgId || '') + '_' + curDuration; zenxDismissMacroChooser(); macroCopiedRecently = false; renderExpansion(true); }, 1100); }); } const btnMacro = widget.querySelector('#zd-timer-btn-macro'); function refreshMacroButton() {
 if (!btnMacro) return;
 btnMacro.textContent=isMacrosEnabled?'⚡':'⚡ Off';
 btnMacro.title=isMacrosEnabled?'Open quick reply categories':'Open macro settings (currently off)';
 btnMacro.classList.toggle('zd-pill-off',!isMacrosEnabled);
}
if (btnMacro) {
 refreshMacroButton();
 btnMacro.addEventListener('click', e=>{
   e.stopPropagation();
   if (zenxMacroChooser!=='closed' && macroPopup.style.display!=='none') {
     zenxDismissMacroChooser();
   } else {
     zenxShowMacroCategories();
   }
 });
}
 btnTheme.addEventListener('click', () => { setThemeMode(!darkMode); }); const btnSections = widget.querySelector('#zd-sections-toggle-btn'); const dropdown = widget.querySelector('#zd-sections-dropdown'); const listEl = widget.querySelector('#zd-sections-list'); function renderSectionsList() { listEl.innerHTML = ''; scanAllSections().forEach(name => { const row = document.createElement('label'); row.className = 'zd-section-item'; const chk = document.createElement('input'); chk.type = 'checkbox'; chk.checked = !isHiddenName(name); chk.addEventListener('change', () => { hiddenSections = hiddenSections.filter(h => normName(h) !== normName(name)); if (!chk.checked) hiddenSections.push(name); saveHiddenSections(); applyAllSectionVisibility(); }); const txt = document.createElement('span'); txt.textContent = name; row.appendChild(chk); row.appendChild(txt); listEl.appendChild(row); }); } btnSections.addEventListener('click', e => { e.stopPropagation(); if (dropdown.style.display !== 'none') { dropdown.style.display = 'none'; return; } renderSectionsList(); const rect = widget.getBoundingClientRect(); if (rect.top > window.innerHeight - 380) { dropdown.style.top = 'auto'; dropdown.style.bottom = 'calc(100% + 10px)'; } else { dropdown.style.bottom = 'auto'; dropdown.style.top = 'calc(100% + 10px)'; } dropdown.style.display = 'flex'; renderExpansion(true); }); widget.querySelector('#zd-sections-scan').addEventListener('click', e => { e.stopPropagation(); renderSectionsList(); }); widget.querySelector('#zd-sections-defaults').addEventListener('click', e => { e.stopPropagation(); hiddenSections = ['Tags', 'Also here']; saveHiddenSections(); renderSectionsList(); applyAllSectionVisibility(); }); widget.querySelector('#zd-sections-showall').addEventListener('click', e => { e.stopPropagation(); hiddenSections = []; saveHiddenSections(); renderSectionsList(); applyAllSectionVisibility(); }); window.addEventListener('click', e => { if (widget.isConnected && !widget.contains(e.target)) { if (dropdown.style.display !== 'none') { dropdown.style.display = 'none'; if (!shouldBeExpanded()) { renderExpansion(true); } } } }); function updateTimerDisplay() { const displayEl = widget.querySelector('#zd-timer-display'); const badgeEl = widget.querySelector('#zd-timer-badge'); const ticketEl = widget.querySelector('#zd-timer-ticket'); if (!displayEl) return; const state = evaluateAgentSLA(); try { zenxUpdateTabBadges(state); } catch(e) {} if (!state.isOpen) { if (ticketEl) { ticketEl.textContent = 'Idle'; ticketEl.title = 'No active ticket open'; ticketEl.style.opacity = '0.55'; } if (macroPopup && zenxMacroChooser==='closed') macroPopup.style.setProperty('display', 'none', 'important'); if (zenxMacroChooser==='closed') activeMacroText = ''; widget.classList.remove('zd-timer-warning', 'zd-timer-urgent'); displayEl.textContent = '⏸️ Idle'; const collapsedTimerEl = widget.querySelector('#zd-timer-collapsed-display'); if (collapsedTimerEl) collapsedTimerEl.textContent = ''; widget.classList.remove('zd-countdown-active'); if (badgeEl) badgeEl.textContent = 'Closed/Idle'; setSlaButtonVisible(false); updateWidgetMetadata(shouldBeExpanded()); return; } const activeDuration = state.durationSec || 120; const durMin = Math.round(activeDuration / 60); if (ticketEl) { ticketEl.style.opacity = '1'; ticketEl.textContent = state.displayBadge || ('#' + (state.ticketId || 'Ticket')); let tip = `Active Ticket: ${state.displayBadge || state.ticketId}`; if (state.nativeSla) tip += ` | Zendesk SLA: ${state.nativeSla}`; ticketEl.title = tip; } if (slaBtn) { setSlaButtonVisible(true); slaBtn.textContent = `${durMin}m`; slaBtn.title = `Active SLA for ${state.displayBadge}: ${durMin}m (click to cycle 1m / 2m / 5m)`; } const remainingSec = state.remainingSec; const remainingMs = state.remainingMs; if (isMuted) { widget.classList.remove('zd-timer-warning', 'zd-timer-urgent'); if (badgeEl) badgeEl.textContent = state.label; } else { if (remainingSec > 60) { widget.classList.remove('zd-timer-warning', 'zd-timer-urgent'); if (badgeEl) badgeEl.textContent = state.label; } else if (remainingSec > 10) { widget.classList.add('zd-timer-warning'); widget.classList.remove('zd-timer-urgent'); if (badgeEl) badgeEl.textContent = '⚠️ ' + state.label; const tState = getTicketState(state.ticketKey); if (!tState.hasBeeped1Min) { playOneMinuteWarning(); tState.hasBeeped1Min = true; } } else { widget.classList.remove('zd-timer-warning'); widget.classList.add('zd-timer-urgent'); if (badgeEl) badgeEl.textContent = '🚨 Urgent'; playUrgentBeep(); } } if (remainingSec > 0) { const m = Math.floor(remainingSec / 60); const s = remainingSec % 60; displayEl.textContent = `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`; } else { displayEl.textContent = '00:00'; } const collapsedTimerEl = widget.querySelector('#zd-timer-collapsed-display'); if (collapsedTimerEl) collapsedTimerEl.textContent = displayEl.textContent; widget.classList.add('zd-countdown-active'); let targetMacroList = []; let targetMacroLabel = ''; if (state.isOpen) { if (state.rule === 'hold' || activeDuration === 300) { targetMacroLabel = "5m Extended Hold"; targetMacroList = [ "I am still looking into your account and can see that [] please allow me another 5 minutes. I will be back soon.", "Thank you for bearing with me. I'm still reviewing the details and need another 5 minutes. I'll update you shortly!", "I'm continuing to investigate this for you. Could you please allow me 5 more minutes? Appreciate your patience." ]; } else if (state.rule === 'general' || activeDuration === 120) { targetMacroLabel = "Hold Suggestion (3-5m)"; targetMacroList = [ "I need a few minutes to review your account. I’ll be back with an update in 3-5 minutes. Thanks for your patience!", "Allow me about 3 to 5 minutes to look into the details for you. I'll follow up shortly with an update.", "I'm checking into this for you right now. Please allow me 3-5 minutes and I'll be right back with more information." ]; } else { targetMacroList = []; targetMacroLabel = ''; } } const cycleKey = (state.msgId || '') + '_' + activeDuration; updateWidgetMetadata(shouldBeExpanded()); if (macroPopup && zenxMacroChooser==='closed') { if (!isMacrosEnabled || targetMacroList.length === 0) { macroPopup.style.setProperty('display', 'none', 'important'); } else if (targetMacroList.length > 0 && remainingMs <= 10000 && macroDismissedId !== cycleKey) { if (macroPopup.style.display === 'none' && !macroCopiedRecently) { activeMacroList = targetMacroList; activeMacroText = targetMacroList[0]; if (macroBody) { macroBody.innerHTML = ` <div class="zd-macro-popup-subtitle">Click any format to insert into reply:</div> ${targetMacroList.map((text, idx) => ` <div class="zd-macro-option" data-macro-idx="${idx}" title="Click to insert Format ${idx + 1}"> <span class="zd-macro-option-badge">Format ${idx + 1}</span> <div class="zd-macro-option-text">${escapeHtml(text)}</div> </div> `).join('')} `; } const badge = widget.querySelector('#zd-macro-popup-badge'); if (badge && badge.textContent !== `⚡ ${targetMacroLabel}`) { badge.textContent = `⚡ ${targetMacroLabel}`; } positionMacroPopup(); macroPopup.style.setProperty('display', 'flex', 'important'); } } else { if (macroPopup.style.display !== 'none' && !macroCopiedRecently) { macroPopup.style.setProperty('display', 'none', 'important'); if (!shouldBeExpanded()) { renderExpansion(true); } } } } } zenxImmediateRefresh = updateTimerDisplay; timerIntervalId = setInterval(updateTimerDisplay, 1000); cleanupSendReset = setupSendResetListener(); updateTimerDisplay(); } function setThemeMode(useDark) { darkMode = !!useDark; try { safeStorage.setItem(THEME_KEY, darkMode ? 'dark' : 'light'); } catch(e) {} for (const doc of collectDocs(document, [])) { try { let record = docMap.get(doc); doc.documentElement.classList.add("zskin-active"); if (darkMode) { doc.documentElement.classList.add("zskin-dark"); doc.documentElement.classList.remove("zskin-light"); if (!record) setupDoc(doc); else runTreeWalker(doc); } else { doc.documentElement.classList.remove("zskin-dark"); doc.documentElement.classList.add("zskin-light"); if (record) { clearTimeout(record.timer); record.pending.clear(); restoreZsStyles(record.styles); } doc.querySelectorAll('[' + PROCESSED_ATTR + ']').forEach(el => { el.removeAttribute(PROCESSED_ATTR); try { if (el.style.backgroundColor && (el.style.backgroundColor.includes('rgb(24, 22, 22)') || el.style.backgroundColor.includes('rgb(14, 17, 22)'))) { el.style.removeProperty('background-color'); } } catch(e) {} }); } } catch(e) {} } toggleCrossDomainSidePanels(darkMode); const button = document.getElementById('zd-theme-toggle'); if (button) { button.textContent = darkMode ? '☀️' : '🌙'; button.title = darkMode ? 'Switch to light theme' : 'Switch to dark theme'; button.setAttribute('aria-pressed', String(darkMode)); } scanAllDocs(); console.info('[Zendesk Skin] ' + (darkMode ? 'Dark' : 'Light') + ' theme active.'); } function teardownTimerWidget() { if (timerIntervalId) clearInterval(timerIntervalId); if (typeof cleanupSendReset === 'function') { try { cleanupSendReset(); } catch(e) {} cleanupSendReset = null; } ticketStates.clear(); const widget = document.getElementById(TIMER_ID); if (widget) widget.remove(); const styleEl = document.getElementById(TIMER_ID + '-css'); if (styleEl) styleEl.remove(); } function showDeactivateToast() { try { const toast = document.createElement('div'); toast.id = 'zd-skin-deactivate-toast'; toast.textContent = '✓ Zendesk restored to original appearance'; toast.style.cssText = 'position:fixed;bottom:24px;left:50%;transform:translateX(-50%);background:#0f172a;color:#f8fafc;padding:10px 18px;border-radius:9999px;font-family:-apple-system,BlinkMacSystemFont,sans-serif;font-size:12px;font-weight:600;box-shadow:0 10px 25px rgba(0,0,0,0.4);z-index:2147483647;pointer-events:none;transition:opacity 0.3s;'; document.body.appendChild(toast); setTimeout(() => { toast.style.opacity = '0'; setTimeout(() => toast.remove(), 350); }, 2000); } catch(e) {} } function teardown() { window.__zd_skin_teardown__ = null; teardownTimerWidget(); clearInterval(intervalId); toggleCrossDomainSidePanels(false); let allDocs = new Set(collectDocs(document, [])); for (let d of docMap.keys()) allDocs.add(d); for (let doc of allDocs) { let rec = docMap.get(doc); if (rec) { try { if (rec.obs) rec.obs.disconnect(); } catch(e) {} try { if (rec.sheet && doc.adoptedStyleSheets) { doc.adoptedStyleSheets = Array.from(doc.adoptedStyleSheets).filter(s => s !== rec.sheet); } } catch(e) {} clearTimeout(rec.timer); restoreZsStyles(rec.styles); } try { doc.querySelectorAll("[data-zd-hidden-tags]").forEach(el => { el.style.removeProperty('display'); el.removeAttribute('data-zd-hidden-tags'); }); doc.querySelectorAll("[data-zd-hidden-also-here]").forEach(el => { el.style.removeProperty('display'); el.removeAttribute('data-zd-hidden-also-here'); }); doc.querySelectorAll("[data-zd-hidden-divider]").forEach(el => { el.style.removeProperty('display'); el.removeAttribute('data-zd-hidden-divider'); }); doc.querySelectorAll("[data-zd-hidden-custom]").forEach(el => { el.style.removeProperty('display'); el.removeAttribute('data-zd-hidden-custom'); }); doc.documentElement.classList.remove("zskin-dark"); doc.documentElement.classList.remove("zskin-light"); doc.documentElement.classList.remove("zskin-active"); doc.querySelectorAll("article[data-chat-role]").forEach(a => a.removeAttribute("data-chat-role")); doc.querySelectorAll("[data-sender-name]").forEach(el => { el.removeAttribute("data-sender-name"); el.removeAttribute("data-msg-time"); }); doc.querySelectorAll('[' + PROCESSED_ATTR + ']').forEach(el => el.removeAttribute(PROCESSED_ATTR)); let fallbackStyle = doc.getElementById(ID); if (fallbackStyle) fallbackStyle.remove(); } catch(e) {} docMap.delete(doc); } showDeactivateToast(); console.info("[Zendesk Skin] Original appearance restored."); } 

// ========== ZenX extension adapter ==========
// The original bookmarklet's getTicketState, message readers, SLA rules, reset
// handling, quick macros, sound alerts, side-panel handling and HUD above are
// kept intact. Nothing in this bridge re-calculates or substitutes an SLA.
const zenxTabSnapshots = new Map();
let zenxImmediateRefresh = null;
let zenxEnabled = true;
let zenxGlobalEnabled = true;
let zenxRunning = false;
let zenxFocus = false;
let zenxAudioListenersAdded = false;
let zenxFrameListenerAdded = false;

function zenxActiveWorkspaceTab(tabs, activeId) {
  const items = Array.from(tabs).filter(tab => !tab.closest('#' + TIMER_ID));
  const selected = items.filter(tab =>
    tab.getAttribute('aria-selected') === 'true' ||
    tab.getAttribute('aria-current') === 'page' ||
    tab.getAttribute('data-state') === 'active' ||
    tab.getAttribute('data-selected') === 'true');
  if (selected.length === 1) return selected[0];
  if (activeId) {
    const matching = items.filter(tab => zenxTabTicketId(tab) === activeId);
    if (matching.length === 1) return matching[0];
  }
  // A lone ticket tab is unambiguous even when Zendesk omits aria-selected.
  return items.length === 1 ? items[0] : null;
}

function zenxTabTicketId(tab) {
  const entity = tab.getAttribute('data-entity-id') || tab.getAttribute('data-ticket-id');
  if (entity && /^\d+$/.test(entity)) return entity;
  for (const value of [tab.getAttribute('aria-label'), tab.getAttribute('title'), tab.id, tab.getAttribute('data-test-id')]) {
    const m = (value || '').match(/(?:ticket[\s_-]*#?|#)(\d{3,})/i);
    if (m) return m[1];
  }
  const href = tab.querySelector('a[href*="/tickets/"]');
  const mHref = href && (href.getAttribute('href') || '').match(/\/tickets\/(\d+)/);
  if (mHref) return mHref[1];
  const mText = (tab.textContent || '').match(/(?:ticket\s*#?|#)(\d{3,})/i);
  return mText ? mText[1] : '';
}

function zenxResetTabCountdown(ticketId, durationSec) {
  if (!ticketId || !/^\d+$/.test(ticketId)) return;
  const old = zenxTabSnapshots.get(ticketId);
  const duration = [60,120,300].includes(durationSec) ? durationSec : (old?.durationSec || 120);
  zenxTabSnapshots.set(ticketId, {
    durationSec: duration, deadlineAt: Date.now() + duration * 1000,
    rule: 'manual', label: 'Manual tab reset',
    msgId: old?.msgId || '', manuallyReset: true
  });
  zenxUpdateTabBadges(null);
}

function zenxUpdateTabBadges(state) {
  if (!zenxEnabled || !zenxRunning) return;
  const now = Date.now();
  const tabs = document.querySelectorAll(
    '[data-test-id="header-tab"], [data-test-id="tabs-section-nav-item-ticket"], '
    + '[data-test-id="workspace-tab"][role="tab"], [role="tab"][data-entity-id], '
    + '[role="tab"][data-ticket-id], [role="tab"][data-test-id*="ticket"]'
  );
  const activeId = state && state.isOpen && /^\d+$/.test(state.ticketId || '') ? state.ticketId : '';
  const activeTab = zenxActiveWorkspaceTab(tabs, activeId);
  if (state && /^\d+$/.test(state.ticketId || '')) {
    if (state.isOpen) {
      const old = zenxTabSnapshots.get(state.ticketId);
      // New agent replies, SLA changes, and ticket switches must refresh the
      // active tab's clock. Previously the snapshot was initialized once and
      // remained stuck at 0:00 after the first countdown expired.
      const cycleChanged = !old || old.msgId !== state.msgId || old.durationSec !== state.durationSec;
      if (cycleChanged) {
        // Anchor once per message/SLA cycle. Zendesk sometimes reports the
        // relative timestamp as "just now" for over a minute; constantly
        // reanchoring from that text freezes the tab clock at 5:00/2:00.
        zenxTabSnapshots.set(state.ticketId, {
          durationSec: state.durationSec || 120,
          deadlineAt: now + Math.max(0, state.remainingMs ?? state.remainingSec * 1000),
          rule: state.rule, label: state.label, msgId: state.msgId,
          manuallyReset: false
        });
      }
    } else {
      zenxTabSnapshots.delete(state.ticketId);
    }
  }
  tabs.forEach(tab => {
    if (tab.closest('#' + TIMER_ID)) return;
    // The visible conversation's ID wins over stale data-entity-id on the
    // active native tab; other ticket tabs retain their own independent ID.
    const id = activeId && tab === activeTab ? activeId : zenxTabTicketId(tab);
    const snap = id ? zenxTabSnapshots.get(id) : null;
    let badge = tab.querySelector(':scope > .zenx-tab-sla-badge');
    if (!snap) {
      if (badge) badge.remove();
      tab.removeAttribute('data-zenx-sla-level');
      return;
    }
    const left = Math.max(0, Math.round((snap.deadlineAt - now) / 1000));
    const label = `${Math.floor(left / 60)}:${String(left % 60).padStart(2, '0')}`;
    const level = left <= 0 ? 'overdue' : left <= 10 ? 'critical' : left <= 60 ? 'warning' : 'normal';
    if (!badge) {
      badge = document.createElement('span');
      badge.className = 'zenx-tab-sla-badge';
      badge.setAttribute('role', 'button');
      badge.tabIndex = 0;
      badge.setAttribute('aria-label', 'Reset this ticket tab countdown');
      // Keep the previous independent manual tab-reset behavior.
      const reset = event => {
        event.preventDefault(); event.stopPropagation();
        const currentState = evaluateAgentSLA();
        const active = zenxActiveWorkspaceTab(document.querySelectorAll(
          '[data-test-id="header-tab"], [data-test-id="tabs-section-nav-item-ticket"], '
          + '[data-test-id="workspace-tab"][role="tab"], [role="tab"][data-entity-id], '
          + '[role="tab"][data-ticket-id], [role="tab"][data-test-id*="ticket"]'
        ), currentState.isOpen ? currentState.ticketId : '');
        const current = tab === active && currentState.isOpen && /^\d+$/.test(currentState.ticketId || '')
          ? currentState.ticketId : zenxTabTicketId(tab);
        const currentSnap = current && zenxTabSnapshots.get(current);
        if (currentSnap) zenxResetTabCountdown(current, currentSnap.durationSec);
      };
      badge.addEventListener('click', reset);
      badge.addEventListener('keydown', event => {
        if (event.key === 'Enter' || event.key === ' ') reset(event);
      });
      tab.appendChild(badge);
    }
    if (badge.textContent !== label) badge.textContent = label;
    badge.title = `${snap.label} • ${label} remaining • Click to reset tab timer`;
    tab.setAttribute('data-zenx-sla-level', level);
  });
}


// Focus mode must remove entire SIDE PANE columns, not just inner fields.
// Attribute-based changes are reversible and do not affect SLA/message parsing.
const zenxFocusMarked = new Map();
function zenxFocusMark(plan, el, attr) {
  if (!el || el === document.body || el === document.documentElement) return;
  if (!plan.has(el)) plan.set(el, new Set());
  plan.get(el).add(attr);
}
function zenxFocusClear() {
  for (const [el, attrs] of zenxFocusMarked) {
    try { for (const a of attrs) el.removeAttribute(a); } catch (_) {}
  }
  zenxFocusMarked.clear();
}
function zenxApplyFocus() {
  const plan = new Map();
  for (const doc of collectDocs(document, [])) {
    try {doc.documentElement.classList.toggle('zskin-focus-mode',zenxFocus && zenxRunning);} catch (_) {}
  }
  if (!zenxFocus || !zenxRunning) { zenxFocusClear(); return; }
  for (const doc of collectDocs(document, [])) {
    try {
      const main = doc.querySelector('[data-test-id="component-type-MainConversationPane"], [data-test-id="ticket-main-conversation"], [data-test-id="omni-log-container"]');
      if (!main) continue;
      const explicit = Array.from(doc.querySelectorAll(
        '[data-test-id="component-type-TicketFieldsPane"], #ticket_sidebar, .grid-ticket-fields-panel, ' +
        '[data-test-id="component-type-AppsPane"], [data-test-id="ticket-apps-pane"], #apps_sidebar, ' +
        '[data-test-id="component-type-AppsSidebar"], [data-test-id="apps-tray"], ' +
        '[data-test-id="component-type-ContextPanel"], [data-test-id="ticket-apps-dock"]'
      ));
      const mainBounds = main.getBoundingClientRect();
      let branch = main;
      // Walk from conversation to the ticket workspace, without ever touching the global header.
      for (let depth=0; depth<6 && branch.parentElement && branch.parentElement!==doc.body; depth++) {
        const parent=branch.parentElement;
        const siblingNodes=Array.from(parent.children).filter(n=>n!==branch && n.nodeType===1);
        let didHide=false;
        for (const sibling of siblingNodes) {
          const containsExplicit = explicit.some(p=>p===sibling||sibling.contains(p));
          const bounds=sibling.getBoundingClientRect();
          const asideOrApps=sibling.matches('aside,[role="complementary"],[data-test-id*="AppsPane"]') ||
            !!sibling.querySelector('[data-test-id*="AppsPane"], [data-test-id="component-type-TicketFieldsPane"], #ticket_sidebar, #apps_sidebar');
          // Some Zendesk versions do not label the app sidebar. Its sibling is to the right
          // of the conversation and contains an iframe plus an app toolbar.
          const wasHidden = zenxFocusMarked.get(sibling)?.has('data-zenx-focus-hidden');
          const likelyApp=!!sibling.querySelector('iframe') &&
            (wasHidden || (bounds.width>=150 && bounds.left >= Math.min(mainBounds.right-26,doc.defaultView.innerWidth*.52)));
          if (containsExplicit || asideOrApps || likelyApp) {
            zenxFocusMark(plan,sibling,'data-zenx-focus-hidden');didHide=true;
          }
        }
        if (didHide) {
          for (const sibling of siblingNodes) {
            if (sibling.matches('[role="separator"]:not([aria-orientation="horizontal"]), [data-test-id*="splitter"], [data-test-id*="resize-handle"]')) {
              zenxFocusMark(plan,sibling,'data-zenx-focus-hidden');
            }
          }
          zenxFocusMark(plan,branch,'data-zenx-focus-grow');
          zenxFocusMark(plan,parent,'data-zenx-focus-grid');
        }
        branch=parent;
      }
      // Independent app panes can live outside the conversation's immediate branch.
      for (const pane of explicit) {
        if (!pane.contains(main) && !main.contains(pane)) {
          zenxFocusMark(plan,pane,'data-zenx-focus-hidden');
          if (pane.parentElement) zenxFocusMark(plan,pane.parentElement,'data-zenx-focus-grid');
        }
      }
    } catch (e) { console.warn('[ZenX] Focus layout skipped for a pane',e); }
  }
  for (const [el, attrs] of zenxFocusMarked) {
    for (const attr of attrs) if (!plan.get(el)?.has(attr)) el.removeAttribute(attr);
  }
  zenxFocusMarked.clear();
  for (const [el, attrs] of plan) {
    for (const attr of attrs) if (el.getAttribute(attr) !== '1') el.setAttribute(attr,'1');
    zenxFocusMarked.set(el, attrs);
  }
}

function zenxBegin() {
  if (!zenxEnabled || zenxRunning || !document.documentElement || !document.body) return;
  zenxRunning = true;
  window.__zd_skin_teardown__ = teardown;
  scanAllDocs();
  toggleCrossDomainSidePanels(darkMode);
  createFloatingTimerWidget();
  if (!zenxAudioListenersAdded) {
    zenxAudioListenersAdded = true;
    window.addEventListener('click', () => getAudioContext(), { once: true, capture: true });
    window.addEventListener('keydown', () => getAudioContext(), { once: true, capture: true });
  }
  if (!zenxFrameListenerAdded) {
    zenxFrameListenerAdded = true;
    document.addEventListener('load', e => {
      if (e.target && e.target.tagName === 'IFRAME' && zenxRunning) setTimeout(scanAllDocs, 200);
    }, true);
  }
  intervalId = setInterval(() => {
    if (!zenxRunning) return;
    scanAllDocs();
    toggleCrossDomainSidePanels(darkMode);
    if (!document.getElementById(TIMER_ID)) createFloatingTimerWidget();
    if (zenxFocus) zenxApplyFocus();
  }, 2500);
  document.documentElement.classList.toggle('zskin-focus-mode', zenxFocus);
  zenxApplyFocus();
  console.info('[ZenX] Bookmarklet v1.9 engine started.');
}

window.addEventListener('keydown', event => {
  if (!zenxRunning || !isMacrosEnabled) return;
  globalThis.zenxCustomMacros?.expand(event, focused => findZendeskComposer(getActiveTicketDetails().container, focused));
}, true);

function zenxEnd() {
  if (!zenxRunning) return;
  zenxRunning = false;
  globalThis.zenxCustomMacros?.close();
  try { teardown(); } catch (e) { console.warn('[ZenX] Cleanup error', e); }
  zenxTabSnapshots.clear();
  zenxImmediateRefresh = null;
  document.querySelectorAll('.zenx-tab-sla-badge').forEach(el => el.remove());
  document.querySelectorAll('[data-zenx-sla-level]').forEach(el => el.removeAttribute('data-zenx-sla-level'));
  document.documentElement.classList.remove('zskin-focus-mode');
  zenxFocusClear();
}
function zenxSetEnabled(value) {
  const next = !!value && window.__zenxTabEnabled !== false;
  if (zenxEnabled === next) return;
  zenxEnabled = next;
  if (next) zenxBegin(); else zenxEnd();
}
function zenxSyncWidgetControls() {
  const mute = document.getElementById('zd-timer-btn-mute');
  if (mute) {
    mute.textContent = isMuted ? '🔇' : '🔔';
    mute.title = isMuted ? 'Alerts muted (click to unmute)' : 'Alerts active (click to mute)';
  }
  const macros = document.getElementById('zd-timer-btn-macro');
  if (macros) {
    macros.textContent = isMacrosEnabled ? '⚡' : '⚡ Off';
    macros.title = isMacrosEnabled ? 'Open Hold, Empathy, Apology or Denied macros' : 'Macros off (click to enable or configure)';
    macros.classList.toggle('zd-pill-off', !isMacrosEnabled);
  }
}
function zenxGetStatus() {
  const slaState = zenxRunning ? evaluateAgentSLA() : null;
  return {
    enabled: zenxEnabled, globalEnabled: zenxGlobalEnabled, tabEnabled: window.__zenxTabEnabled !== false, connected: true, source: 'bookmarklet-v1.9',
    darkMode, isMuted, isMacrosEnabled, focusMode: zenxFocus,
    slaState,
    activeTicket: slaState ? slaState.displayBadge : '',
    nativeSla: slaState ? slaState.nativeSla : '',
    activeDuration: slaState ? slaState.durationSec : 0,
    hiddenSections: hiddenSections.slice(),
    sections: zenxRunning ? scanAllSections() : ['Tags', 'Also here']
  };
}

chrome.runtime.onMessage.addListener((request, _sender, sendResponse) => {
  if (!request || typeof request.type !== 'string') return false;
  try {
    switch (request.type) {
      case 'GET_STATUS':
        sendResponse(zenxGetStatus()); return false;
      case 'TOGGLE_ENABLED':
        zenxGlobalEnabled = !!request.enabled;
        zenxSetEnabled(zenxGlobalEnabled);
        chrome.storage.local.set({ zenx_enabled: zenxGlobalEnabled });
        sendResponse({ success: true, enabled: zenxEnabled, globalEnabled: zenxGlobalEnabled }); return false;
      case 'REFRESH':
        if (zenxRunning) { scanAllDocs(); zenxUpdateTabBadges(evaluateAgentSLA()); }
        sendResponse({ success: true }); return false;
      case 'SET_THEME':
        if (zenxRunning) setThemeMode(!!request.darkMode);
        else { darkMode = !!request.darkMode; safeStorage.setItem(THEME_KEY, darkMode ? 'dark' : 'light'); }
        sendResponse({ success: true, darkMode }); return false;
      case 'PREVIEW_THEME_SOUND': {
        if (!zenxRunning) {sendResponse({success:false,error:'ZenX disabled'});return false;}
        playOneMinuteWarning();
        sendResponse({success:true}); return false;
      }
      case 'SET_MUTE':
        isMuted = !!request.isMuted;
        safeStorage.setItem(MUTE_KEY, String(isMuted));
        zenxSyncWidgetControls();
        if (zenxImmediateRefresh) zenxImmediateRefresh();
        sendResponse({ success: true, isMuted }); return false;
      case 'SET_MACROS':
        isMacrosEnabled = !!request.isMacrosEnabled;
        safeStorage.setItem(MACRO_KEY, String(isMacrosEnabled));
        zenxSyncWidgetControls();
        if (zenxImmediateRefresh) zenxImmediateRefresh();
        sendResponse({ success: true, isMacrosEnabled }); return false;
      case 'SET_FOCUS_MODE':
        zenxFocus = !!request.enabled;
        document.documentElement.classList.toggle('zskin-focus-mode', zenxFocus && zenxRunning);
        zenxApplyFocus();
        sendResponse({ success: true, focusMode: zenxFocus }); return false;
      case 'SET_DEFAULT_SECTIONS':
        hiddenSections = ['Tags', 'Also here'];
        saveHiddenSections(); applyAllSectionVisibility();
        sendResponse({ success: true, hiddenSections: hiddenSections.slice() }); return false;
      case 'SHOW_ALL_SECTIONS':
        hiddenSections = [];
        saveHiddenSections(); applyAllSectionVisibility();
        sendResponse({ success: true, hiddenSections: [] }); return false;
      case 'SET_SECTION_VISIBILITY': {
        const name = String(request.name || '').trim();
        if (!name || name.length > 80) { sendResponse({ success: false }); return false; }
        hiddenSections = hiddenSections.filter(x => normName(x) !== normName(name));
        if (request.hidden) hiddenSections.push(name);
        saveHiddenSections(); applyAllSectionVisibility();
        sendResponse({ success: true, hiddenSections: hiddenSections.slice() }); return false;
      }
      case 'CYCLE_SLA':
      case 'SET_MANUAL_DURATION': {
        if (!zenxRunning) { sendResponse({ success: false, error: 'ZenX is disabled' }); return false; }
        const seconds = Number(request.durationSec);
        if (![0, 60, 120, 300].includes(seconds)) { sendResponse({ success: false, error: 'Unsupported duration' }); return false; }
        const info = getActiveTicketDetails();
        const ticketState = getTicketState(info.ticketKey);
        ticketState.manualDurationOverride = seconds;
        ticketState.hasBeeped1Min = false;
        if (seconds > 0) {
          // This is identical to the bookmarklet's manual duration button.
          ticketState.baseElapsedSec = 0;
          ticketState.anchorTime = Date.now();
        }
        if (seconds > 0) zenxResetTabCountdown(info.ticketId, seconds);
        if (zenxImmediateRefresh) zenxImmediateRefresh();
        sendResponse({ success: true, slaState: evaluateAgentSLA() }); return false;
      }
      case 'INSERT_MACRO': {
        // Optional popup action reuses the bookmarklet's exact composer writer.
        const text = typeof request.text === 'string' ? request.text : '';
        if (!text || text.length > 2000) { sendResponse({ success: false }); return false; }
        populateZendeskComposer(text).then(success => sendResponse({ success }),
          error => sendResponse({ success: false, error: String(error) }));
        return true;
      }
      default: return false; // theme.js handles visual-only messages
    }
  } catch(e) {
    sendResponse({ success: false, error: String(e) });
    return false;
  }
});

chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== 'local') return;
  if (changes.zenx_enabled) {zenxGlobalEnabled = changes.zenx_enabled.newValue !== false;zenxSetEnabled(zenxGlobalEnabled);}
  if (changes.zenx_active_theme) {
    const selected = changes.zenx_active_theme.newValue;
    globalThis.__zenxPremiumThemeSelected = selected?.id !== 'classic';
    if (selected && ['light','dark'].includes(selected.mode) && darkMode !== (selected.mode === 'dark')) {
      if (zenxRunning) setThemeMode(selected.mode === 'dark');
      else {darkMode=selected.mode === 'dark';safeStorage.setItem(THEME_KEY,selected.mode);}
    }
  }
});
// Theme initialization and enable/disable are separate async storage flows.
// If Classic is selected, begin its painter only after that selection is known.
window.addEventListener('zenx-visual-owner-ready', () => {
  if (!zenxRunning) return;
  scanAllDocs();
  if (!zenxPremiumOwnsSurfaces() && darkMode)
    for (const doc of collectDocs(document, [])) runTreeWalker(doc);
});
window.addEventListener('zenx-tab-state-change', () => zenxSetEnabled(zenxGlobalEnabled));
chrome.storage.local.get({ zenx_enabled: true }, values => {
  zenxGlobalEnabled = values.zenx_enabled !== false;
  Promise.resolve(window.__zenxTabReady).then(() => {
  zenxSetEnabled(zenxGlobalEnabled);
  if (zenxEnabled) zenxBegin();
  chrome.storage.local.get({zenx_active_theme:null},v=>{
    const a=v.zenx_active_theme;
    if(a && ['light','dark'].includes(a.mode) && darkMode !== (a.mode==='dark')) setThemeMode(a.mode==='dark');
  });
  });
});
})();

/* v8: refresh derived SLA state on browser tab return; never restart the countdown. */
window.addEventListener('focus', () => { try { if (zenxImmediateRefresh) zenxImmediateRefresh(); } catch (_) {} });
document.addEventListener('visibilitychange', () => { try { if (!document.hidden && zenxImmediateRefresh) zenxImmediateRefresh(); } catch (_) {} });
