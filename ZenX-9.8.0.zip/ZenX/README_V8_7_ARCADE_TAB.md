# ZenX v8.7 — Home Arcade + per-tab ZenX control

## Improvements
- Corrected an overly restrictive left-column size check that hid Arcade on the Home screen even when "No tickets" was present.
- The Dinosaur / Snake panel anchors beneath **Last 30 days** and remains limited to the left empty area, without moving any Zendesk elements.
- Supports Classic as well as premium themes while ZenX is on.
- New **Enable on this tab** switch in the extension popup. Turning it off restores the original Zendesk experience **only in that browser tab**. Other tabs and the main ZenX setting remain unchanged.
- Per-tab off/on preference persists across page reloads and routing in that tab, but resets at the end of the Chrome session. Closes are cleaned up.
- Score and personal best for both games continue to use `chrome.storage.local` independently.

## Installation
1. Extract the **ZenX** folder from the ZIP and replace your existing ZenX extension files.
2. Open `chrome://extensions` and click **Reload** for ZenX.
3. Refresh the Zendesk tab; on Home with "No tickets", the panel appears below **Last 30 days**.
4. Click the ZenX icon to turn the games or the current tab on/off.

Note: For game keyboard controls, click on the game screen first. Input on Zendesk remains unaffected.
