# ZenX 8.5.0 — Agent Status + Agent Home

This update adds visual improvements without changing Zendesk's ticket state, agent routing, macro rules, composer, or SLA calculations.

## Profile / status area

- Displays a compact availability chip next to Zendesk's native top-right profile control.
- Colors: green Online, amber Away, cyan Transfers only, grey Offline, purple custom status, neutral when not detected.
- Clicking the chip calls the original Zendesk profile button. The original status selection menu is unchanged.
- Updates the display from currently visible Zendesk status labels or selected menu entries; never calls an API or sends a status update itself.
- If Zendesk does **not** expose status in the page markup until the menu opens, the chip says **Check status** instead of falsely claiming Online. Open the native status menu once to let the extension read the selection.
- Handles reactive rerenders, window resizing, SPA navigation and extension on/off.

## Home dashboard

- Scoped to `/agent/home/*` and legacy `/agent/dashboard/*`.
- Transparent themed background, glass metric tiles/cards, headings, filters, tabs, ticket tables, and accessible keyboard focus.
- Keeps all native ticket lists, selectors, sorting, navigation, links, and data from Zendesk. No fake counts or data requests.
- Restores native surfaces when ZenX is switched off or navigation leaves Home.

## Safety and compatibility

- No extra browser permissions.
- No cross-origin reads, no additional network requests, no Zendesk API calls.
- All pre-existing rich-text macro fixes and SLA/ticket parity logic are retained unchanged.
- Verified in a browser-based *offline mock* for Home/profile plus regression scripts. Real Zendesk uses various markup versions; use the native profile menu once if the chip cannot identify status.

## Testing

```sh
python tests/home-status-regressions.py
python tests/editor-richtext-regressions.py
python tests/timer-macro-regressions.py
node tests/verify-parity.mjs
```

Home/profile browser tests use Playwright with Chromium, via an offline page to avoid touching production Zendesk.
