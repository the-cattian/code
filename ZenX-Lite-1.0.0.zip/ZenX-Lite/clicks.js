(() => {
  'use strict';

  const settingsKey = 'zenx_clicks_enabled';
  const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)');
  let enabled = false;

  chrome.storage.local.get({ [settingsKey]: true }, values => {
    enabled = values[settingsKey] !== false;
  });
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== 'local' || !changes[settingsKey]) return;
    enabled = changes[settingsKey].newValue !== false;
    if (!enabled) document.querySelectorAll('.zenx-lite-click').forEach(effect => effect.remove());
  });

  document.addEventListener('click', event => {
    if (!enabled || reducedMotion.matches || !event.detail || !document.body) return;

    const effect = document.createElement('span');
    effect.className = 'zenx-lite-click';
    effect.setAttribute('aria-hidden', 'true');
    effect.style.left = event.clientX + 'px';
    effect.style.top = event.clientY + 'px';

    const ring = document.createElement('span');
    ring.className = 'zenx-lite-click-ring';
    effect.append(ring);

    const count = 7;
    for (let index = 0; index < count; index++) {
      const angle = index * 2 * Math.PI / count;
      const particle = document.createElement('span');
      particle.className = 'zenx-lite-click-particle';
      particle.textContent = '◆';
      particle.style.setProperty('--dx', Math.round(Math.cos(angle) * 48) + 'px');
      particle.style.setProperty('--dy', Math.round(Math.sin(angle) * 48) + 'px');
      particle.style.setProperty('--rotation', Math.round(angle * 180 / Math.PI) + 'deg');
      effect.append(particle);
    }
    document.body.append(effect);
    setTimeout(() => effect.remove(), 750);
  }, { capture: true, passive: true });
})();
