(() => {
  'use strict';

  const defaults = {
    zenx_clicks_enabled: true,
    zenx_click_style: 'sparkle',
    zenx_cursor_style: 'aqua'
  };
  const effects = {
    sparkle: { marks: ['✦', '◆'], count: 7, radius: 48 },
    petals: { marks: ['✿', '❀'], count: 6, radius: 49 },
    hearts: { marks: ['♥', '♡'], count: 7, radius: 46 },
    stars: { marks: ['★', '✧'], count: 8, radius: 54 },
    bubbles: { marks: ['○', '◌'], count: 7, radius: 45, lift: 21 },
    daisies: { marks: ['✼', '✽'], count: 6, radius: 47, lift: 9 },
    butterflies: { marks: ['🦋', '✧'], count: 6, radius: 43, lift: 18 },
    moons: { marks: ['☾', '⋆'], count: 6, radius: 47, lift: 12 },
    confetti: { marks: ['▪', '▰', '●'], count: 11, radius: 55, lift: -15 },
    diamonds: { marks: ['♦', '◇'], count: 8, radius: 53 },
    bows: { marks: ['🎀', '♡'], count: 6, radius: 43, lift: 10 },
    fireflies: { marks: ['●', '✶'], count: 8, radius: 51, lift: 24 }
  };
  const palettes = new Set(['aqua', 'rose', 'lilac', 'mint', 'peach', 'lemon', 'sky', 'cherry',
    'orchid', 'moonlight', 'cocoa', 'noir', 'system']);
  const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)');
  const editableSelector = 'input, textarea, [contenteditable]:not([contenteditable="false"])';
  const clickableSelector = 'a[href], area[href], button, summary, [role="button"], [role="link"]';
  const settings = { ...defaults };
  let enabled = false;
  let clickStyle = defaults.zenx_click_style;
  let cursorStyle = defaults.zenx_cursor_style;
  let hovered = null;
  let cursorOverride = null;

  function restoreCursor() {
    hovered = null;
    if (!cursorOverride) return;
    const { style, value, priority, applied } = cursorOverride;
    if (style.getPropertyValue('cursor') === applied && style.getPropertyPriority('cursor') === 'important') {
      if (value) style.setProperty('cursor', value, priority);
      else style.removeProperty('cursor');
    }
    cursorOverride = null;
  }

  function applyCursor(element) {
    if (element === hovered) return;
    restoreCursor();
    if (!element) return;
    hovered = element;
    if (cursorStyle === 'system' || element.localName.includes('-')) return;

    const native = getComputedStyle(element).cursor;
    if (native !== 'auto' && native !== 'default' && native !== 'pointer') return;
    if (native !== 'pointer' && element.closest(editableSelector)) return;
    if (element.closest(':disabled,[aria-disabled="true"]')) return;
    const useHand = native === 'pointer' || (native === 'auto' && element.closest(clickableSelector));
    const style = element.style;
    const value = style.getPropertyValue('cursor');
    const priority = style.getPropertyPriority('cursor');
    const file = useHand ? 'hand' : 'arrow';
    const fallback = useHand ? '11 3, pointer' : '3 2, default';
    const url = chrome.runtime.getURL('cursor-' + cursorStyle + '-' + file + '.png');
    style.setProperty('cursor', 'url("' + url + '") ' + fallback, 'important');
    cursorOverride = { style, value, priority, applied: style.getPropertyValue('cursor') };
  }

  function updateCursor(event) {
    if (!enabled || event.pointerType === 'touch') return;
    applyCursor(event.composedPath().find(node => node instanceof Element && node.style));
  }

  function applySettings() {
    const nextCursor = palettes.has(settings.zenx_cursor_style) ? settings.zenx_cursor_style : defaults.zenx_cursor_style;
    enabled = settings.zenx_clicks_enabled !== false;
    clickStyle = Object.hasOwn(effects, settings.zenx_click_style) ? settings.zenx_click_style : defaults.zenx_click_style;
    if (!enabled) {
      restoreCursor();
      document.querySelectorAll('.zenx-lite-click').forEach(effect => effect.remove());
    } else if (nextCursor !== cursorStyle) {
      const element = hovered;
      restoreCursor();
      cursorStyle = nextCursor;
      if (element?.isConnected) applyCursor(element);
    }
    cursorStyle = nextCursor;
  }

  chrome.storage.local.get(defaults, values => {
    Object.assign(settings, values);
    applySettings();
  });
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== 'local') return;
    for (const key of Object.keys(defaults)) {
      if (Object.hasOwn(changes, key)) settings[key] = changes[key].newValue ?? defaults[key];
    }
    applySettings();
  });

  const listen = { capture: true, passive: true };
  document.addEventListener('pointerover', updateCursor, listen);
  document.addEventListener('pointermove', updateCursor, listen);
  document.addEventListener('pointerdown', updateCursor, listen);
  document.addEventListener('pointerup', updateCursor, listen);
  document.addEventListener('pointercancel', restoreCursor, listen);
  document.addEventListener('pointerout', event => {
    if (!event.relatedTarget) restoreCursor();
  }, listen);
  window.addEventListener('blur', restoreCursor);
  window.addEventListener('pagehide', restoreCursor);

  document.addEventListener('click', event => {
    if (!enabled || reducedMotion.matches || !event.detail || !document.body) return;

    const effect = document.createElement('span');
    effect.className = 'zenx-lite-click';
    effect.setAttribute('aria-hidden', 'true');
    effect.dataset.style = clickStyle;
    effect.style.left = event.clientX + 'px';
    effect.style.top = event.clientY + 'px';

    const ring = document.createElement('span');
    ring.className = 'zenx-lite-click-ring';
    effect.append(ring);

    const { marks, count, radius, lift = 0 } = effects[clickStyle];
    for (let index = 0; index < count; index++) {
      const angle = index * 2 * Math.PI / count - Math.PI / 2;
      const particle = document.createElement('span');
      particle.className = 'zenx-lite-click-particle';
      particle.textContent = marks[index % marks.length];
      particle.style.setProperty('--dx', Math.round(Math.cos(angle) * radius) + 'px');
      particle.style.setProperty('--dy', Math.round(Math.sin(angle) * radius - lift) + 'px');
      particle.style.setProperty('--rotation', Math.round(Math.cos(angle) * 60) + 'deg');
      effect.append(particle);
    }
    document.body.append(effect);
    setTimeout(() => effect.remove(), 920);
  }, listen);
})();
