#!/usr/bin/env python3
"""Home Arcade isolated browser regression tests (no access to production Zendesk)."""
import asyncio, json
from pathlib import Path
from playwright.async_api import async_playwright
ROOT=Path(__file__).resolve().parents[1]
HTML='''<!doctype html><html class="zskin-active zenx-premium zskin-dark"><head><title>Mock Zendesk Home</title>
<style>*{box-sizing:border-box}body{margin:0;background:#1c2329;color:#e8edf1;font-family:Arial,sans-serif}
.top{height:40px;background:#15191e;color:white;padding:9px 18px}
.row{display:flex;height:calc(100vh - 40px)}.rail{width:52px;background:#171d22;flex-shrink:0}
.sidebar{width:570px;display:flex;flex-direction:column;padding:24px 20px;background:#1c2429;border-right:1px solid #4a5459}
.sidebar h2{margin:0 0 30px;font-size:18px}.sidebar .group{margin:0 0 25px}.sidebar p{margin:7px 0;padding:5px 0;font-size:13px}
.sidebar h4{color:#aeb8c1;font-size:12px;margin:0 0 7px}.sidebar a{display:block;width:200px;padding:7px 10px;color:#e8eff6;text-decoration:none;font-size:13px}
main{margin:0;min-width:440px;flex:1;border:0;padding:32px;background:#1a2026}.card{height:calc(100vh - 100px);border-radius:18px;border:1px solid #625743;background:#1c2023;padding:32px;display:grid;place-content:center;text-align:center}
#empty-label{font-size:20px;margin:14px}#ticket-count{position:absolute;top:116px;left:700px;color:white}
</style></head><body>
<div class="top">Zendesk Support</div><div class="row"><nav class="rail"></nav>
<aside class="sidebar"><h2>Home</h2><div class="group"><h4>Your work</h4><a>Tickets</a></div>
<div class="group"><h4>Shared work</h4><a>CC'd</a><a>Following</a></div>
<div class="group"><h4>Completed work</h4><a id="last-30">Last 30 days</a></div></aside>
<main role="main"><div class="card"><div id="ticket-count">0 tickets</div><strong id="empty-label">No tickets</strong><p id="empty-extra">Work you're assigned will appear here.</p></div></main></div>
</body></html>'''

async def main():
 results=[]; errors=[]
 async with async_playwright() as p:
  browser=await p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
  page=await browser.new_page(viewport={'width':1792,'height':861})
  page.on('pageerror',lambda e: errors.append(str(e)))
  await page.set_content(HTML)
  await page.add_script_tag(content=(ROOT/'tester/mock-shim.js').read_text())
  await page.evaluate('''(css)=>chrome.runtime.getURL=(path)=>'data:text/css,'+encodeURIComponent(css)''',(ROOT/'arcade.css').read_text())
  await page.evaluate("window.__zenxTestLocationPath='/agent/home/tickets'")
  source=(ROOT/'arcade.js').read_text().replace('location.pathname','(window.__zenxTestLocationPath || location.pathname)')
  await page.add_script_tag(content=source)
  await page.wait_for_timeout(350)
  await page.evaluate("""(css) => {
    const root=document.getElementById('zenx-arcade-root')?.shadowRoot;
    if(root){const style=document.createElement('style');style.textContent=css;root.append(style);}
  }""",(ROOT/'arcade.css').read_text())
  await page.wait_for_timeout(750)
  game=page.locator('#zenx-arcade-root')
  async def check(label,fn):
   try:
    out=await fn();print('PASS',label,out);results.append({'test':label,'pass':True,'detail':out})
   except Exception as e:
    print('FAIL',label,str(e));results.append({'test':label,'pass':False,'error':str(e)})
  async def initial():
   assert await game.count()==1
   rect=await game.bounding_box()
   assert rect['x']>=50 and rect['x']+rect['width']<=625,rect
   assert rect['y']>=320 and rect['y']+rect['height']<=850,rect
   assert await page.locator('#empty-label').inner_text()=='No tickets'
   assert await page.locator('.sidebar').count()==1
   return {k:round(v) for k,v in rect.items()}
  await check('Loads only within marked Home sidebar space',initial)
  async def score_run():
   await game.locator('button#start').click()
   await page.wait_for_timeout(2600)
   score=int(await game.locator('#score').inner_text())
   assert score>=5,score
   best=int(await game.locator('#best').inner_text())
   assert best>=score,(best,score)
   await game.locator('#start').click()
   assert await game.locator('#overlay-title').inner_text()=='Paused'
   await page.wait_for_timeout(1900)
   stored=await page.evaluate('new Promise(r=>chrome.storage.local.get({zenx_games_dino_best:0},r))')
   assert stored['zenx_games_dino_best']>=score,stored
   return {'score':score,'saved_high_score':stored['zenx_games_dino_best']}
  await check('Dino runs, scores, saves best, pauses',score_run)
  async def switch_snake():
   await game.locator('#next').click()
   assert await game.locator('#mode-title').inner_text()=='Snake'
   assert await game.locator('#score').inner_text()=='0'
   assert await game.locator('#touch-controls').is_visible()
   await game.locator('#start').click()
   await page.wait_for_timeout(250)
   assert await game.locator('#overlay').is_hidden()
   await game.locator('#start').click()
   assert await game.locator('#overlay-title').inner_text()=='Paused'
   await game.locator('#previous').click()
   assert await game.locator('#mode-title').inner_text()=='Dinosaur'
   assert int(await game.locator('#best').inner_text())>=5
   return 'Both modes switch without losing individual scores'
  await check('Snake starts and game arrows switch modes',switch_snake)
  async def snake_wrap():
   await game.locator('#next').click()
   assert await game.locator('#mode-title').inner_text()=='Snake'
   await game.locator('#start').click()
   await page.wait_for_timeout(3300)
   assert await game.locator('#overlay').is_hidden(),'Snake died at the right edge'
   scan="(c)=>{const ctx=c.getContext('2d');for(let x=0;x<33;x++){const p=ctx.getImageData(30+x*20+7,20+7*20+7,1,1).data;if(p[0]===151&&p[1]===239&&p[2]===206)return x;}return -1;}"
   wrapped_x=await game.locator('#screen').evaluate(scan)
   assert 0<=wrapped_x<14,wrapped_x
   await game.locator('#restart').click()
   await game.locator('#screen').focus()
   await page.keyboard.press('ArrowUp')
   await page.wait_for_timeout(1950)
   assert await game.locator('#overlay').is_hidden(),'Snake died at the top edge'
   await game.locator('#previous').click()
   return {'right_edge_wrapped_to_column':wrapped_x,'top_edge_wrap':'alive'}
  await check('Snake wraps right and top edges instead of dying',snake_wrap)

  async def resize():
   before=await game.bounding_box()
   grip=await game.locator('#resize-grip').bounding_box()
   x=grip['x']+10;y=grip['y']+10
   await page.mouse.move(x,y);await page.mouse.down();await page.mouse.move(x-90,y-80,steps=4);await page.mouse.up()
   after=await game.bounding_box()
   assert after['width']<before['width'] and after['height']<before['height'],(before,after)
   saved=await page.evaluate('new Promise(r=>chrome.storage.local.get({zenx_games_layout:{}},r))')
   assert saved['zenx_games_layout']['width']==round(after['width']),saved
   return {'before':round(before['width']),'after':round(after['width'])}
  await check('Resize persists locally',resize)
  async def move():
   before=await game.bounding_box()
   drag=await game.locator('#drag-handle').bounding_box()
   x=drag['x']+190;y=drag['y']+22
   await page.mouse.move(x,y);await page.mouse.down();await page.mouse.move(x+32,y+20,steps=4);await page.mouse.up()
   after=await game.bounding_box()
   assert after['x']>before['x']+20 and after['y']>before['y']+10,(before,after)
   return f"Dragged from ({round(before['x'])}, {round(before['y'])}) to ({round(after['x'])}, {round(after['y'])})"
  await check('Window drag handle moves arcade',move)
  async def no_tickets_gate():
   await page.locator('#empty-label').evaluate('(el)=>el.textContent="Assigned tickets"')
   await game.wait_for(state='detached',timeout=4000)
   await page.locator('#empty-label').evaluate('(el)=>el.textContent="No tickets"')
   await game.wait_for(state='attached',timeout=4000)
   assert await game.count()==1
   assert int(await game.locator('#best').inner_text())>=5, {'mode':await game.locator('#mode-title').inner_text(),'best':await game.locator('#best').inner_text(),'score':await game.locator('#score').inner_text()}
   return 'Hides as soon as ticket list stops being empty, restores saved high score'
  await check('Real empty-state detection gates arcade',no_tickets_gate)
  async def disabled():
   await game.locator('#power-off').click()
   await page.wait_for_timeout(430)
   assert await game.count()==0
   await page.evaluate('chrome.storage.local.set({zenx_games_enabled:true})')
   await page.wait_for_timeout(450)
   assert await game.count()==1
   await page.evaluate('chrome.storage.local.set({zenx_enabled:false})')
   await page.wait_for_timeout(440)
   assert await game.count()==0
   await page.evaluate('chrome.storage.local.set({zenx_enabled:true})')
   await page.wait_for_timeout(470)
   assert await game.count()==1
   return 'Independent games toggle, respects master ZenX switch'
  await check('Games on/off toggle and master toggle',disabled)
  async def navigates():
   await page.evaluate("window.__zenxTestLocationPath='/agent/tickets/123'")
   await page.wait_for_timeout(1900)
   assert await game.count()==0
   await page.evaluate("window.__zenxTestLocationPath='/agent/home/tickets'")
   await page.wait_for_timeout(1900)
   assert await game.count()==1
   await page.evaluate("""(css) => { const root=document.getElementById('zenx-arcade-root').shadowRoot;
     const style=document.createElement('style');style.textContent=css;root.append(style); }""",(ROOT/'arcade.css').read_text())
   return 'SPA navigation hides and restores without DOM rewriting' 
  await check('Navigation between Home and ticket',navigates)
  async def keyboard():
   await game.locator('#next').click()
   await game.locator('#start').click()
   await game.locator('#screen').focus()
   await page.keyboard.press('ArrowUp')
   await page.wait_for_timeout(70)
   assert await game.locator('#overlay').is_hidden()
   await page.keyboard.press('Escape')
   assert await game.locator('#overlay-title').inner_text()=='Paused'
   return 'Canvas-focus keyboard controls; Escape pauses'
  await check('Snake keyboard input and pause',keyboard)
  if len(errors): print('PAGE_ERRORS',errors)
  result={'passed':sum(r['pass'] for r in results),'failed':sum(not r['pass'] for r in results),'results':results,'page_errors':errors}
  (ROOT/'tests/arcade-validation.json').write_text(json.dumps(result,indent=2))
  await page.screenshot(path='/mnt/data/zenx_arcade_preview.png',full_page=True)
  await browser.close()
  assert result['failed']==0 and not errors,result
  print('SUMMARY',result['passed'],'/',len(results))
if __name__=='__main__':asyncio.run(main())
