"""Offline UI regression for ZenX quick macro categories + composer safety."""
from pathlib import Path
from playwright.sync_api import sync_playwright
import re
ROOT=Path(__file__).resolve().parents[1]
with sync_playwright() as p:
    browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
    page=browser.new_page(viewport={'width':1792,'height':861})
    errors=[]
    page.on('pageerror',lambda e: errors.append(str(e)))
    html=(ROOT/'tests/fixtures/nested.html').read_text()
    html=re.sub(r'<script\b[^>]*>.*?</script>', '', html, flags=re.S|re.I)
    html=re.sub(r'<link\b[^>]*rel="stylesheet"[^>]*>', '', html, flags=re.I).replace('<base href="/tester/">','')
    page.set_content(html)
    for file in ['tester/mock.css','styles.css','premium.css']:
        page.add_style_tag(content=(ROOT/file).read_text())
    shim=(ROOT/'tester/mock-shim.js').read_text().replace("new URL('../'+path,location.href).href", "'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVQIHWP4////fwAJ+wP+Y+9J5wAAAABJRU5ErkJggg=='")
    for file in ['tester/mock-shim.js','editor-bridge.js','content.js']:
        page.add_script_tag(content=shim if file=='tester/mock-shim.js' else (ROOT/file).read_text())
    page.wait_for_selector('#zd-floating-sla-timer')
    # User's workflow should not call Zendesk Send; only editor draft may change.
    page.evaluate('''() => {
      const el=document.querySelector('#ticket-header');
      if(el)el.textContent='Open ticket #23592985';
    }''')
    page.locator('#zd-floating-sla-timer').hover(); page.wait_for_timeout(420); page.locator('#zd-timer-btn-macro').click()
    categories=page.locator('#zd-timer-macro-popup [data-zenx-category]')
    assert categories.count()==4, categories.count()
    assert [categories.nth(i).inner_text().split('\n')[0] for i in range(4)]==['Hold','Empathy','Apology','Denied']
    print('PASS pill opens four quick-reply categories')
    for cat in ['hold','empathy','apology','denied']:
        page.locator(f'#zd-timer-macro-popup [data-zenx-category="{cat}"]').click(force=True)
        options=page.locator('#zd-timer-macro-popup .zd-macro-option')
        assert options.count()>=3,(cat,options.count())
        texts=options.all_text_contents()
        assert all(len(t)>75 for t in texts),(cat,texts)
        assert all('sorry' in t.lower() or 'understand' in t.lower() or 'appreciate' in t.lower() or 'thank' in t.lower() or 'apologize' in t.lower() or 'realize' in t.lower() for t in texts),cat
        page.locator('#zd-timer-macro-popup [data-zenx-action="back"]').click(force=True)
    print('PASS every category provides four substantial customer-support replies and Back navigation')
    page.locator('#zd-timer-macro-popup [data-zenx-action="disable"]').click(force=True)
    assert page.locator('#zd-timer-macro-popup [data-zenx-action="enable"]').count()==1
    assert page.locator('#zd-timer-btn-macro').text_content()=='⚡ Off'
    page.locator('#zd-timer-macro-popup [data-zenx-action="enable"]').click(force=True)
    assert page.locator('#zd-timer-macro-popup [data-zenx-category="hold"]').count()==1
    print('PASS macros can be disabled and re-enabled using pill popup')
    page.locator('#zd-timer-macro-popup [data-zenx-category="apology"]').click(force=True)
    count=page.locator('article[data-test-id="omni-log-comment-item"]').count()
    page.locator('#zd-timer-macro-popup .zd-macro-option').first.click(force=True)
    page.wait_for_timeout(450)
    editor=page.locator('[data-test-id="omni-composer-text-input"]')
    text=editor.inner_text()
    assert "I'm sorry for the frustration" in text,text
    assert page.locator('article[data-test-id="omni-log-comment-item"]').count()==count
    print('PASS apology adds draft to Zendesk composer without auto sending')
    page.wait_for_timeout(1300)
    page.evaluate('document.getElementById("zd-timer-btn-macro").click()')
    assert page.locator('#zd-timer-macro-popup [data-zenx-category]').count()==4
    page.screenshot(path='/mnt/data/zenx_quick_macros_preview.png')
    assert not errors,errors
    print('PASS no JS errors')
    browser.close()
