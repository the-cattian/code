# ZenX 8.6.0 — Home schedule candidate

Changes:
- Recognizes Zendesk's toolbar-profile-menu-button, fixing the missing presence chip.
- Reads accessible labels and retains a detected selected status after the menu closes.
- Targets the supplied nah-container home markup, reserves a 400px schedule column, and places statistics below the ticket area. At narrow widths the schedule stacks below.
- Discovers Assembled's current iframe URL through the native launcher, closes the modal to release its focus trap, and embeds an independently loaded frame. No account-specific URL or app GUID is saved in the extension.
- Clears the schedule on navigation away from home and on extension deactivation.

Installation: extract ZenX, replace the existing unpacked extension directory (or load this directory using Chrome Extensions > Developer mode > Load unpacked), reload the extension, then refresh Zendesk. Open the profile menu once to detect the selected status.

Validation: JavaScript syntax checks and headless Chromium fixture tests using the supplied home markup passed for presence-chip creation, selected status remaining visible after menu close, schedule creation, modal closure, narrow layout, and ticket-route cleanup. This is not a signed-in Zendesk test.

Live verification required:
- Assembled may require an app-framework handshake tied to its original iframe. If the independent frame is blank or fails, use the native toolbar app and report the result. The native launcher remains available. This candidate has not established that the iframe works with a live account.
- Presence is the last selected status detected from Zendesk's exposed DOM. If Zendesk does not expose a later change, reopen the native profile menu. No status is inferred from email/messaging channel labels or avatar colors.
- Assign a test ticket while on Home to verify existing automatic opening. Native ticket controls and assignment handling are unchanged, but live assignment behavior has not been tested.
