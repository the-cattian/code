# ZenX v9.0 — Home Arcade Expansion

This release builds directly on ZenX v8.9. The existing quick macros, ticket ID and timer synchronization, per-tab/global on/off switches, theme logic, SLA pill, agent Home appearance, Dinosaur and wraparound Snake are retained. The **game module and its scoped Shadow DOM CSS** provide the new functionality; no permissions, Zendesk routes or ticket workflows were added.

## New games

- **Falling Words:** Case-sensitive falling words with occasional unusual capitalization and punctuation. Type a word exactly to destroy it; multiple words may fall at once. Three missed words end a run. Score increases for every cleared word, and Level increments every 60 seconds. The rate builds slowly from ~4 words per minute at the start to about 12, 20, 29 and 37 words per minute after minutes 1–4, respectively; reaching a particular survival time is an approximate skill target, not a guarantee. The header shows current level, remaining lives and incoming WPM. Enter clears a mistaken input; Backspace allows normal correction.
- **Typing Test:** Choose 1, 2, or 5 minutes. Original sample sentences include uppercase/lowercase letters, spaces, punctuation and numbers. Incorrect characters highlight in red; correct characters highlight in green. Measures WPM (five characters per word) and keystroke accuracy. Last and best WPM are stored **separately for each duration**. A partial test does not inflate the best completed-test score.
- **Flappy Bird:** Original canvas art with tap/Space/Up controls, random pipe openings, one point per cleared pipe, ground and pipe collision, and a high score.
- **Bounce Ball:** A red bouncing-ball platform game inspired by classic feature-phone bouncing games. Left/Right move, Space/Up jumps higher, rings award points, and gaps and spikes cost lives. Each six rings advances a level.

## Existing games

- **Dinosaur:** Jump with Space/Up and duck with Down; cacti and animated flying obstacles remain.
- **Snake:** Move with Arrow keys or WASD; edges wrap, but colliding with your body ends the game.

## User interface and controls

Use the **‹ and ›** buttons to navigate six modes. The typing games automatically expand the console while keeping its bottom within the viewport. The arcade remains draggable and resizable. Start/Pause/Resume/Restart work per mode, and changing modes stops the current run.

The Arcade appears only on the Zendesk Home page when the *native* empty-ticket message is visible and ZenX and Games are enabled. The extension popup's **Home arcade** on/off, **Enable on this tab**, and global ZenX switch continue to work. The arcade pauses on tab blur and hides on ticket pages.

High scores and last scores use `chrome.storage.local`; previous Dinosaur and Snake records are retained. No game input is sent to Zendesk or to a network service.

## Install

Unzip into your existing unpacked extension directory (or load the contained `ZenX/` folder through `chrome://extensions`). Click Reload on the ZenX extension and refresh the Zendesk page.

## Validation

Verified against a mock Zendesk Home screen using the existing arcade, ticket sync, timer, Home, and quick macro regressions plus new v9 gameplay tests. Live production Zendesk behavior was not directly tested. The game art is original canvas rendering; it does not include original Chrome, Nokia, or Flappy Bird game assets.
