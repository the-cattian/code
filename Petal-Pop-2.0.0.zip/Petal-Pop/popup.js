'use strict';

const { key, defaults, normalize, motions, directions, read } = globalThis.PetalSettings;
const art = globalThis.PetalArt;
const effects = globalThis.PetalEffects;
const canvas = document.querySelector('#preview');
const context = canvas.getContext('2d');
const status = document.querySelector('#status');
const reset = document.querySelector('#reset');
const resetDialog = document.querySelector('#reset-dialog');
const controls = [...document.querySelectorAll('[data-setting]')];
const tabs = [...document.querySelectorAll('[role="tab"]')];
const reducedMotion = matchMedia('(prefers-reduced-motion: reduce)');
let settings = normalize(defaults);
let lastSaved = '';
let inFlight = false;
let saveRequested = false;
let saveTimer = 0;
let ready = false;
let width = 0;
let height = 0;
let frame = 0;
let lastFrame = 0;
let trackedPoint = null;
let position = null;
let bursts = [];
let trail = [];

function fillSelect(property, options) {
  const select = document.querySelector(`[data-setting="${property}"]`);
  select.replaceChildren(...options.map(({ id, label }) => new Option(label, id)));
}

fillSelect('cursor.shape', art.shapes);
fillSelect('cursor.motion', motions);
fillSelect('effect.style', effects.styles);
fillSelect('effect.direction', directions);

function setStatus(message, error = false) {
  status.textContent = message;
  status.toggleAttribute('data-error', error);
}

function saveSettings() {
  clearTimeout(saveTimer);
  saveTimer = 0;
  if (!ready) return;
  if (inFlight) {
    saveRequested = true;
    return;
  }
  const serialized = JSON.stringify(settings);
  if (serialized === lastSaved) return;
  inFlight = true;
  const value = JSON.parse(serialized);
  chrome.storage.local.set({ [key]: value }, () => {
    inFlight = false;
    if (chrome.runtime.lastError) {
      setStatus('Could not save settings. Try changing a control again.', true);
    } else {
      lastSaved = serialized;
      setStatus('Saved');
    }
    if (saveRequested) {
      saveRequested = false;
      saveSettings();
    }
  });
}

function updateControl(control) {
  const [category, property] = control.dataset.setting.split('.');
  const value = property ? settings[category][property] : settings[category];
  if (control.type === 'checkbox') {
    control.checked = value;
  } else {
    control.value = value;
    const output = control.parentElement.querySelector('output');
    if (output) output.value = value + control.dataset.unit;
  }
}

function refreshControls() {
  for (const control of controls) {
    updateControl(control);
    control.disabled = !ready;
  }
  reset.disabled = !ready;
  canvas.classList.toggle('has-preview-cursor', Boolean(context) && settings.cursor.enabled);
  document.querySelector('[data-setting="cursor.strength"]').disabled = !ready || settings.cursor.motion === 'direct';
  requestFrame();
}

function changeSetting(control, flush) {
  const [group, property] = control.dataset.setting.split('.');
  const value = control.type === 'checkbox' ? control.checked :
    control.type === 'range' ? control.valueAsNumber : control.value;
  const previous = property ? settings[group][property] : settings[group];
  if (value !== previous) {
    const edited = property ? { ...settings, [group]: { ...settings[group], [property]: value } } :
      { ...settings, [group]: value };
    settings = normalize(edited);
    updateControl(control);
    canvas.classList.toggle('has-preview-cursor', Boolean(context) && settings.cursor.enabled);
    document.querySelector('[data-setting="cursor.strength"]').disabled = settings.cursor.motion === 'direct';
    setStatus('Saving…');
    requestFrame();
  }
  if (flush) {
    saveSettings();
    if (control.dataset.setting === 'effect.style') previewClick(samplePoint());
  } else {
    clearTimeout(saveTimer);
    saveTimer = setTimeout(saveSettings, 100);
  }
}

for (const control of controls) {
  control.addEventListener('input', () => changeSetting(control, false));
  control.addEventListener('change', () => changeSetting(control, true));
}

function showTab(index, focus = false) {
  tabs.forEach((tab, i) => {
    const selected = i === index;
    tab.setAttribute('aria-selected', selected);
    tab.tabIndex = selected ? 0 : -1;
    document.getElementById(tab.getAttribute('aria-controls')).hidden = !selected;
  });
  if (focus) tabs[index].focus();
}

tabs.forEach((tab, index) => {
  tab.addEventListener('click', () => showTab(index));
  tab.addEventListener('keydown', event => {
    if (!['ArrowLeft', 'ArrowRight', 'Home', 'End'].includes(event.key)) return;
    event.preventDefault();
    showTab(event.key === 'Home' ? 0 : event.key === 'End' ? tabs.length - 1 : 1 - index, true);
  });
});

reset.addEventListener('click', () => {
  resetDialog.returnValue = 'cancel';
  resetDialog.showModal();
});
resetDialog.addEventListener('close', () => {
  if (resetDialog.returnValue !== 'reset') return;
  settings = normalize(defaults);
  trail = [];
  bursts = [];
  refreshControls();
  setStatus('Settings reset');
  saveSettings();
});
document.addEventListener('visibilitychange', () => {
  if (document.hidden) saveSettings();
});
window.addEventListener('pagehide', saveSettings);

function samplePoint() {
  return { x: width * .5, y: height * .45 };
}

function localPoint(event) {
  const bounds = canvas.getBoundingClientRect();
  return { x: event.clientX - bounds.left, y: event.clientY - bounds.top };
}

function previewClick(point) {
  if (!settings.effect.enabled) return;
  const now = performance.now();
  bursts = bursts.filter(({ burst, start }) => now - start < effects.lifetime(burst)).slice(-5);
  bursts.push({ burst: effects.create(point.x, point.y, settings.effect), start: now });
  requestFrame();
}

canvas.addEventListener('pointermove', event => {
  trackedPoint = localPoint(event);
  requestFrame();
});
canvas.addEventListener('pointerleave', () => {
  trackedPoint = null;
  position = null;
  trail = [];
  requestFrame();
});
canvas.addEventListener('click', event => previewClick(event.detail ? localPoint(event) : samplePoint()));
canvas.addEventListener('keydown', event => {
  if (event.key !== 'Enter' && event.key !== ' ') return;
  event.preventDefault();
  previewClick(samplePoint());
});

function drawCursor(point, alpha = 1) {
  const { shape, size, primary, secondary, outline, stroke, tilt, opacity } = settings.cursor;
  const { x, y } = art.hotspot(shape);
  context.save();
  context.globalAlpha = opacity / 100 * alpha;
  context.translate(point.x, point.y);
  context.rotate(tilt * Math.PI / 180);
  context.translate(-size * x, -size * y);
  art.draw(context, shape, size, primary, secondary, outline, stroke);
  context.restore();
}

function render(now) {
  frame = 0;
  if (!context || !width || !height) return;
  const elapsed = lastFrame ? Math.min(24, now - lastFrame) : 16;
  lastFrame = now;
  context.clearRect(0, 0, width, height);
  bursts = bursts.filter(({ burst, start }) => now - start < effects.lifetime(burst));
  for (const { burst, start } of bursts) effects.draw(context, burst, now - start);

  let animating = bursts.length > 0;
  if (settings.cursor.enabled) {
    const motion = reducedMotion.matches ? 'direct' : settings.cursor.motion;
    const target = trackedPoint || samplePoint();
    if (!position) position = { ...target, vx: 0, vy: 0 };
    const point = globalThis.PetalMotion.step(position, target, settings.cursor, elapsed, now, reducedMotion.matches);
    if (motion === 'trail' && trackedPoint && settings.cursor.strength > 0) {
      const duration = 85 + 2 * settings.cursor.strength;
      const last = trail.at(-1);
      if (!last || Math.hypot(point.x - last.x, point.y - last.y) > 5) {
        trail.push({ x: point.x, y: point.y, time: now });
      }
      trail = trail.filter(each => now - each.time < duration).slice(-9);
      for (const each of trail.slice(0, -1)) drawCursor(each, .26 * (1 - (now - each.time) / duration));
      animating ||= trail.length > 1;
    } else {
      trail = [];
    }
    drawCursor(point);
    animating ||= point.moving;
  }
  if (animating) requestFrame();
  else lastFrame = 0;
}

function requestFrame() {
  if (!frame) frame = requestAnimationFrame(render);
}

function resizePreview() {
  width = canvas.clientWidth;
  height = canvas.clientHeight;
  const scale = Math.min(devicePixelRatio || 1, 2);
  canvas.width = Math.round(width * scale);
  canvas.height = Math.round(height * scale);
  context?.setTransform(scale, 0, 0, scale, 0, 0);
  position = null;
  requestFrame();
}

new ResizeObserver(resizePreview).observe(canvas);
reducedMotion.addEventListener('change', requestFrame);
refreshControls();
read((value, error) => {
  if (error) {
    setStatus('Could not load settings. Reopen the popup to try again.', true);
    return;
  }
  settings = normalize(value);
  lastSaved = JSON.stringify(settings);
  ready = true;
  refreshControls();
});
