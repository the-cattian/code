/* ZenX per-browser-tab switch. Runs before feature scripts in the top frame. */
(() => {
  'use strict';
  if (window.__zenxTabReady) return;
  // While the service worker checks the session override, defer feature startup.
  window.__zenxTabEnabled = false;
  const root = document.documentElement;
  let settled = false;
  function apply(enabled) {
    const value = enabled !== false;
    const changed = window.__zenxTabEnabled !== value;
    window.__zenxTabEnabled = value;
    root.classList.toggle('zenx-tab-disabled', !value);
    if (changed || !settled) {
      window.dispatchEvent(new CustomEvent('zenx-tab-state-change', {detail: {enabled: value}}));
    }
    settled = true;
  }
  let resolveReady;
  window.__zenxTabReady = new Promise(resolve => { resolveReady = resolve; });
  chrome.runtime.onMessage.addListener((request, sender, respond) => {
    if (request?.type !== 'ZENX_APPLY_TAB_STATE') return false;
    apply(request.enabled);
    respond({success:true,enabled:window.__zenxTabEnabled});
    return false;
  });
  chrome.runtime.sendMessage({type:'ZENX_GET_TAB_STATE'}, (reply) => {
    // If unavailable, default enabled instead of breaking ZenX.
    const enabled = chrome.runtime.lastError || !reply ? true : reply.enabled !== false;
    apply(enabled);
    resolveReady();
  });
})();
