/*
 * ZenX editor adapter (MAIN world).
 * Only touches the active Zendesk composer when asked by the isolated content
 * script. An editor's own data API must be used where available so its internal
 * draft stays in sync with the text displayed on screen.
 */
(() => {
  'use strict';
  if (window.__zenxEditorBridgeReady) return;
  window.__zenxEditorBridgeReady = true;

  const REQUEST = 'zenx:editor-insert-request';
  const RESPONSE = 'zenx:editor-insert-response';
  const composerSelector = '[data-test-id*="composer"], [data-test-id="ticket-rich-text-editor"], .conversation-polaris, [data-test-id="component-type-MainConversationPane"]';
  const escapeHTML = s => s.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
  const normalize = s => String(s || '').replace(/\s+/g, ' ').trim();

  function editorFor(el) {
    const host = el.closest('.ck-editor, [data-test-id="ticket-rich-text-editor"]');
    const candidates = [
      el.ckeditorInstance, el.editorInstance, el.__ckeditorInstance,
      host?.ckeditorInstance, host?.editorInstance, host?.__ckeditorInstance,
      window.CKEDITOR?.instances && Object.values(window.CKEDITOR.instances).find(instance =>
        instance?.element?.$ === el || instance?.container?.$?.contains(el))
    ];
    return candidates.find(editor => editor && typeof editor.setData === 'function') || null;
  }

  document.addEventListener('zenx:editor-replace-shortcut', event => {
    const el = event.target;
    const { shortcut, text } = event.detail || {};
    if (!(el instanceof HTMLElement) || document.activeElement !== el ||
        !el.isContentEditable || !el.closest(composerSelector) ||
        typeof shortcut !== 'string' || !/^[a-zA-Z0-9_-]{1,40}$/.test(shortcut) ||
        typeof text !== 'string' || !text.trim() || text.length > 4000) return;

    const selection = document.getSelection();
    if (!selection?.rangeCount || selection.toString() !== shortcut) return;
    const range = selection.getRangeAt(0);
    if (!el.contains(range.commonAncestorContainer)) return;

    const editor = editorFor(el);
    if (!editor?.model || !editor.editing?.view || !editor.data?.processor) return;
    try {
      const viewRange = editor.editing.view.domConverter.domRangeToView(range);
      if (!viewRange) return;
      const modelRange = editor.editing.mapper.toModelRange(viewRange);
      if (modelRange.isCollapsed || [...modelRange.getItems()].map(item => item.data || '').join('') !== shortcut) return;

      const html = '<p>' + escapeHTML(text).replace(/\r\n?|\n/g, '<br>') + '</p>';
      const content = editor.data.toModel(editor.data.processor.toView(html), '$clipboardHolder');
      if (content.childCount === 0) return;

      // A synthetic paste can use CKEditor's stale model caret and append
      // beside the shortcut. Replace the mapped range in one model change.
      editor.model.change(writer => {
        writer.setSelection(modelRange);
        editor.model.insertContent(content);
      });
      event.preventDefault();
    } catch (err) {
      console.warn('[ZenX] Shortcut replacement in the editor model failed', err);
    }
  }, true);

  document.addEventListener(REQUEST, event => {
    const { id, text } = event.detail || {};
    const el = event.target;
    if (typeof id !== 'string' || id.length > 100 || typeof text !== 'string' || !text.trim() || text.length > 4000 ||
        !(el instanceof HTMLElement) || el.getAttribute('contenteditable') !== 'true' || !el.closest(composerSelector)) return;
    const editor = editorFor(el);
    if (!editor) return; // The content script tries native editing next.
    let success = false;
    try {
      const html = '<p>' + escapeHTML(text).replace(/\r\n?|\n/g, '<br>') + '</p>';
      editor.setData(html);
      // Prefer reading editor data; verifying only el.innerText can produce a
      // false positive when the editor rejects the DOM edit.
      const data = typeof editor.getData === 'function' ? editor.getData() : '';
      if (data) {
        const probe = document.createElement('div');
        probe.innerHTML = data;
        success = normalize(probe.textContent).includes(normalize(text));
      }
    } catch (err) {
      console.warn('[ZenX] Editor data insertion failed', err);
    }
    el.dispatchEvent(new CustomEvent(RESPONSE, { detail: { id, success }, bubbles: false }));
  }, true);
})();
