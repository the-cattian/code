(() => {
  'use strict';

  function step(state, target, cursor, elapsedMs, now, reduced) {
    const strength = cursor.strength / 100;
    if (reduced || strength === 0 || cursor.motion === 'direct' || cursor.motion === 'trail') {
      Object.assign(state, target, { vx: 0, vy: 0 });
      return { ...target, moving: false };
    }

    const time = Math.min(Math.max(elapsedMs, 0), 32) / 16.67;
    const dx = target.x - state.x;
    const dy = target.y - state.y;
    const gap = Math.hypot(dx, dy);
    const maxLag = 18 + 55 * strength;
    if (gap > maxLag) {
      state.x = target.x - dx * maxLag / gap;
      state.y = target.y - dy * maxLag / gap;
    }

    if (cursor.motion === 'spring') {
      const spring = .31 - strength * .12;
      const friction = Math.pow(.64 + strength * .12, time);
      state.vx = (state.vx + (target.x - state.x) * spring * time) * friction;
      state.vy = (state.vy + (target.y - state.y) * spring * time) * friction;
      state.x += state.vx * time;
      state.y += state.vy * time;
    } else {
      const follow = 1 - Math.pow(.25 + strength * .55, time);
      state.x += (target.x - state.x) * follow;
      state.y += (target.y - state.y) * follow;
      state.vx = state.vy = 0;
    }

    const moving = Math.hypot(target.x - state.x, target.y - state.y, state.vx, state.vy) > .22;
    if (!moving) Object.assign(state, target, { vx: 0, vy: 0 });
    if (cursor.motion === 'float') {
      return {
        x: state.x + Math.sin(now / 350) * strength * 2.2,
        y: state.y + Math.sin(now / 240) * strength * 4.4,
        moving: true
      };
    }
    return { x: state.x, y: state.y, moving };
  }

  globalThis.PetalMotion = { step };
})();
