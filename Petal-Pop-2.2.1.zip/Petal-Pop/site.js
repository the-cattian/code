(() => {
  'use strict';

  const { key, normalize, read } = PetalSettings;
  const reduced = matchMedia('(prefers-reduced-motion: reduce)');
  const editable = 'textarea, input:not([type="button"]):not([type="submit"]):not([type="reset"]), [contenteditable]:not([contenteditable="false"])';
  const ordinaryCursors = new Set(['auto', 'default', 'pointer']);
  const pointer = { x: 0, y: 0 };
  const position = { x: 0, y: 0, vx: 0, vy: 0 };
  const trail = [];
  const bursts = [];
  const ghosts = [];
  let settings = normalize();
  let ready = false;
  let target = null;
  let editableTarget = false;
  let hiddenCursor = null;
  let active = false;
  let host, layer, sprite, spriteCtx, effects, effectsCtx;
  let spriteKey = '';
  let frame = 0;
  let lastTick = 0;

  function style(element, styles) {
    for (const [property, value] of Object.entries(styles)) element.style.setProperty(property, value);
  }

  function createLayer() {
    if (host) return;
    host = document.createElement('div');
    host.setAttribute('data-petal-pop-studio', '');
    host.setAttribute('aria-hidden', 'true');
    for (const [property, value] of Object.entries({
      all: 'initial', display: 'block', position: 'fixed', inset: '0 auto auto 0', width: '0',
      height: '0', overflow: 'visible', 'pointer-events': 'none', 'z-index': '2147483647'
    })) host.style.setProperty(property, value, 'important');
    layer = host.attachShadow({ mode: 'open' });
    effects = document.createElement('canvas');
    style(effects, {
      position: 'absolute', left: '0', top: '0', width: '100vw', height: '100vh',
      'pointer-events': 'none', display: 'none', 'z-index': '0'
    });
    effectsCtx = effects.getContext('2d');
    layer.append(effects);
    sprite = createSprite(2);
    spriteCtx = sprite.getContext('2d');
  }

  function createSprite(z) {
    const canvas = document.createElement('canvas');
    style(canvas, {
      position: 'absolute', left: '0', top: '0', display: 'none', 'pointer-events': 'none',
      'z-index': String(z), 'will-change': 'transform'
    });
    layer.append(canvas);
    return canvas;
  }

  function enterSurface(element) {
    const topLayer = element?.closest('dialog[open], :popover-open') || document.fullscreenElement || document.documentElement;
    // A fullscreen video or other replaced element has no rendered DOM children.
    if (!topLayer || topLayer.matches('video, canvas, iframe, img')) return false;
    createLayer();
    if (host.parentNode !== topLayer) topLayer.append(host);
    return true;
  }

  function ensureArtwork(cursor) {
    const pixelRatio = Math.min(2, devicePixelRatio || 1);
    const signature = [cursor.shape, cursor.size, cursor.primary, cursor.secondary, cursor.outline, cursor.stroke, pixelRatio].join('|');
    if (signature === spriteKey) return;
    spriteKey = signature;
    sprite.width = sprite.height = Math.round(cursor.size * pixelRatio);
    sprite.style.width = sprite.style.height = cursor.size + 'px';
    spriteCtx.setTransform(pixelRatio, 0, 0, pixelRatio, 0, 0);
    PetalArt.draw(spriteCtx, cursor.shape, cursor.size, cursor.primary, cursor.secondary, cursor.outline, cursor.stroke);
    sprite.style.transformOrigin = origin(cursor).css;
    for (const ghost of ghosts) copyArtwork(ghost);
  }

  function copyArtwork(canvas) {
    canvas.width = sprite.width;
    canvas.height = sprite.height;
    canvas.style.width = sprite.style.width;
    canvas.style.height = sprite.style.height;
    canvas.style.transformOrigin = sprite.style.transformOrigin;
    canvas.getContext('2d').drawImage(sprite, 0, 0);
  }

  function origin(cursor) {
    const { x, y } = PetalArt.hotspot(cursor.shape);
    return { x: x * cursor.size, y: y * cursor.size, css: (x * 100) + '% ' + (y * 100) + '%' };
  }

  function place(canvas, point, hotspot, tilt, opacity) {
    canvas.style.transform = 'translate3d(' + (point.x - hotspot.x) + 'px,' + (point.y - hotspot.y) + 'px,0) rotate(' + tilt + 'deg)';
    canvas.style.opacity = String(opacity);
    canvas.style.display = 'block';
  }

  function restoreNative() {
    if (!hiddenCursor) return;
    const { element, value, priority } = hiddenCursor;
    if (element.style.getPropertyValue('cursor') === 'none' && element.style.getPropertyPriority('cursor') === 'important') {
      if (value) element.style.setProperty('cursor', value, priority);
      else element.style.removeProperty('cursor');
    }
    hiddenCursor = null;
  }

  function hideCursor() {
    restoreNative();
    active = false;
    trail.length = 0;
    if (sprite) sprite.style.display = 'none';
    for (const ghost of ghosts) ghost.style.display = 'none';
  }

  function forgetPointer() {
    target = null;
    hideCursor();
  }

  function useTarget() {
    const cursor = settings.cursor;
    if (!ready || !settings.enabled || !cursor.enabled || !target?.isConnected || editableTarget ||
        target.matches('iframe, frame, embed, object') ||
        target.closest(':disabled,[aria-disabled="true"]')) {
      hideCursor();
      return;
    }

    if (target !== hiddenCursor?.element) {
      restoreNative();
      if (!ordinaryCursors.has(getComputedStyle(target).cursor) || !enterSurface(target) || !spriteCtx) {
        hideCursor();
        return;
      }
      const value = target.style.getPropertyValue('cursor');
      const priority = target.style.getPropertyPriority('cursor');
      target.style.setProperty('cursor', 'none', 'important');
      hiddenCursor = { element: target, value, priority };
    }
    if (!active) {
      Object.assign(position, pointer, { vx: 0, vy: 0 });
      active = true;
    }
    ensureArtwork(cursor);
    const point = PetalMotion.step(position, pointer, cursor, 0, performance.now(), reduced.matches);
    place(sprite, point, origin(cursor), cursor.tilt, cursor.opacity / 100);
    requestFrame();
  }

  function onPointer(event) {
    if (event.pointerType === 'touch') return;
    const path = event.composedPath();
    const element = path.find(node => node instanceof Element && node.style);
    const changed = target !== element;
    target = element;
    editableTarget = path.some(node => node instanceof Element && node.matches(editable));
    pointer.x = event.clientX;
    pointer.y = event.clientY;
    if (changed || !active) useTarget();
    if (!active) return;
    if (event.type === 'pointerdown') {
      // Keep the visible hotspot aligned with the actual press even for glide or spring.
      Object.assign(position, pointer, { vx: 0, vy: 0 });
      place(sprite, pointer, origin(settings.cursor), settings.cursor.tilt, settings.cursor.opacity / 100);
    } else if (settings.cursor.motion === 'trail' && !reduced.matches) {
      sampleTrail();
    }
    requestFrame();
  }

  function sampleTrail() {
    const last = trail.at(-1);
    if (last && Math.hypot(pointer.x - last.x, pointer.y - last.y) < 5) return;
    trail.push({ ...pointer, time: performance.now() });
    if (trail.length > 8) trail.shift();
  }

  function renderCursor(now, elapsed) {
    if (!target?.isConnected) hideCursor();
    if (hiddenCursor && (hiddenCursor.element.style.getPropertyValue('cursor') !== 'none' ||
        hiddenCursor.element.style.getPropertyPriority('cursor') !== 'important')) {
      restoreNative();
      useTarget();
    }
    if (!active) return false;
    const cursor = settings.cursor;
    const hotspot = origin(cursor);
    const point = PetalMotion.step(position, pointer, cursor, elapsed, now, reduced.matches);
    place(sprite, point, hotspot, cursor.tilt, cursor.opacity / 100);
    const trailDuration = 90 + cursor.strength * 2.2;
    while (trail.length && now - trail[0].time >= trailDuration) trail.shift();
    const count = !reduced.matches && cursor.motion === 'trail' && cursor.strength ? Math.max(0, trail.length - 1) : 0;
    for (let index = 0; index < count; index++) {
      if (!ghosts[index]) {
        ghosts[index] = createSprite(1);
        copyArtwork(ghosts[index]);
      }
      const sample = trail[index];
      const fade = Math.max(0, 1 - (now - sample.time) / trailDuration);
      place(ghosts[index], sample, hotspot, cursor.tilt, fade * cursor.opacity * .0042);
    }
    for (let index = count; index < ghosts.length; index++) ghosts[index].style.display = 'none';
    return point.moving || count > 0;
  }

  function renderEffects(now) {
    if (!bursts.length || !effectsCtx) return false;
    const scale = Math.min(2, devicePixelRatio || 1);
    const width = Math.round(innerWidth * scale);
    const height = Math.round(innerHeight * scale);
    if (effects.width !== width || effects.height !== height) {
      effects.width = width;
      effects.height = height;
    }
    effects.style.display = 'block';
    effectsCtx.setTransform(scale, 0, 0, scale, 0, 0);
    effectsCtx.clearRect(0, 0, innerWidth, innerHeight);
    for (let index = bursts.length - 1; index >= 0; index--) {
      const item = bursts[index];
      const elapsed = now - item.start;
      if (elapsed >= PetalEffects.lifetime(item.burst)) bursts.splice(index, 1);
      else PetalEffects.draw(effectsCtx, item.burst, Math.max(0, elapsed));
    }
    if (!bursts.length) effects.style.display = 'none';
    return bursts.length > 0;
  }

  function tick(now) {
    frame = 0;
    const elapsed = lastTick ? now - lastTick : 16.67;
    lastTick = now;
    const moving = renderCursor(now, elapsed);
    const animating = renderEffects(now);
    if (moving || animating) requestFrame();
    else lastTick = 0;
  }

  function requestFrame() {
    if (!frame) frame = requestAnimationFrame(tick);
  }

  function apply(newSettings) {
    settings = newSettings;
    ready = true;
    trail.length = 0;
    if (!settings.enabled || !settings.effect.enabled || reduced.matches) {
      bursts.length = 0;
      if (effects) effects.style.display = 'none';
    }
    useTarget();
  }

  read(apply);
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'local' && Object.hasOwn(changes, key)) apply(normalize(changes[key].newValue));
  });
  reduced.addEventListener('change', () => apply(settings));

  const listen = { capture: true, passive: true };
  for (const type of ['pointerover', 'pointermove', 'pointerdown', 'pointerup']) {
    document.addEventListener(type, onPointer, listen);
  }
  document.addEventListener('pointerout', event => {
    if (!event.relatedTarget) forgetPointer();
  }, listen);
  document.addEventListener('pointercancel', forgetPointer, listen);
  document.addEventListener('dragstart', forgetPointer, listen);
  document.addEventListener('fullscreenchange', () => {
    restoreNative();
    useTarget();
  });
  window.addEventListener('blur', forgetPointer);
  window.addEventListener('pagehide', forgetPointer);

  window.addEventListener('click', event => {
    if (!ready || !settings.enabled || !settings.effect.enabled || reduced.matches || !event.isTrusted || !event.detail) return;
    const element = event.composedPath().find(node => node instanceof Element);
    if (!enterSurface(element) || !effectsCtx) return;
    const burst = PetalEffects.create(event.clientX, event.clientY, settings.effect);
    if (bursts.length >= 14) bursts.shift();
    bursts.push({ burst, start: performance.now() });
    requestFrame();
  }, listen);
})();
